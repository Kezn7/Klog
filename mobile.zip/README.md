# Klog 手机 App（Capacitor 原生壳）

把站内已有的工作台直接跑进 Android App：**数据存手机本机、提醒进系统闹钟、重要操作给震动反馈**。
不含任何后端依赖——打包产物是纯静态离线包（`LOGIN_AUTHED = false` → `CLOUD_ENABLED = false` → 全站零接口请求）。

## 目录

| 路径 | 作用 |
| --- | --- |
| `../assets/klog-native.js` | 原生能力桥：震动分档、四类提醒规划器、系统排程、权限、设置分区、离线导出 |
| `scripts/build-web.cjs` | 把 `index.php` 模板按「本地模式」固定求值成 `www/index.html`，残留 PHP 即构建失败 |
| `scripts/make-icons.cjs` | 用站内 `favicon.svg` 直接产出 Android 全套图标与通知小图标（不依赖 `@capacitor/assets`） |
| `scripts/apply-native.cjs` | 幂等地把图标覆盖进 Android 工程、改自适应图标底色、补权限、回填版本号 |
| `scripts/cdp-app-shell-check.cjs` | 无真机自检：注入假 Capacitor 桥，验证规划器/排程/震动/设置折叠/备份往返（55 项） |
| `native-res/` | 生成物，会被 `apply-native` 覆盖进 `android/app/src/main/res` |
| `android/` | `cap add android` 生成，不入库（CI 每次重建） |

## 出包

```bash
cd mobile
npm ci                 # 本机若卡在 sharp 下载，加 --ignore-scripts（预编译包走 npm registry）
npm run build:debug    # 静态化 → 图标 → cap sync → 覆盖原生资源 → gradle assembleDebug
```

产物：`android/app/build/outputs/apk/debug/app-debug.apk`，传到手机直接安装。
没装 JDK/Android SDK 就走 CI：见 `.github/workflows/android.yml`，跑完在 Actions 里下载 artifact。

## 提醒行为（v1 的确定语义）

- **待办到期**：按到期日 + 设定时间逐条排；有重复规则的交给系统周期（日/周/月/年），逾期条数写进正文而不是单独轰炸。
- **纪念日 / 生日**：发生日沿用数据层的 `nextOccur()`（含农历周年）。公历周年挂 `every:'year'`；**农历周年的公历日期逐年漂移，只排最近一次**，靠 App 打开与每 6 小时的滚动重排续上下一年。
- **习惯打卡**：只排一条，正文取「当前仍未打卡」的习惯名；每次打卡都触发重排，全部打完后这条自动被撤销。
- **每日摘要**：固定时间一条，正文是进行中 / 今日到期 / 逾期 / 7 天内纪念的实时统计。
- 排程窗口 30 天、上限 55 条（Android 侧对未决通知数有硬限制）。
- 总开关关掉 → 撤销系统里全部已排通知。

## 震动分档（保持站内「克制」的既有约定）

完成待办 / 打卡成功 → 成功音；取消完成、撤销打卡 → **静默**；删除、移入回收站 → 警告音；
归档 → 中档冲击；左滑越过删除阈值的那一刻 → 先给一次锁定触感；数据层抛错 → 错误音。
浏览器里自动降级成 `navigator.vibrate` 图案，桌面浏览器无感。

## 装机与搬运数据

1. 电脑上的 Klog → 个人中心 → **导出备份**（JSON）。
2. 把 JSON 传到手机（微信文件、网盘、数据线都行）。
3. 打开 App → 走完昵称建档 → 个人中心 → **导入备份** → 选择该文件。
   App 与浏览器是两份独立存储，导入即整体覆盖，之后各写各的。

App 内的**导出备份**走系统分享（WebView 没有下载管理器，`<a download>` 会静默失败），
不支持分享时退回复制到剪贴板。

## 真机还需确认的三件事

1. **通知权限**：Android 13+ 首次排程会弹询问；拒绝后到「提醒与手感 → 系统权限」里开。
2. **精确闹钟**：Android 12+ 若被系统收回，到点可能有数分钟偏差（设置行会明确写出来）。
3. **省电策略**：华为 / 小米 / OPPO 等会把后台闹钟杀掉。把 Klog 移出电池优化名单，
   并在系统设置里允许自启动——这一步没有 API 可代劳，只能引导用户手动开。

## 已知边界

- 只做 Android。iOS 需要 macOS + Xcode + 开发者账号，Windows 上无法出包。
- 通知点击暂不深链到具体页面（插件只回传 `extra`，UI 层还没接）。
- App 与服务器不互通（本次选择纯本地离线）。要跨端同步得先把 API 配成手机可达地址，
  并把 PHP session cookie 登录换成 token。
