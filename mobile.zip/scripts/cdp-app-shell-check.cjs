/* ============================================================
   cdp-app-shell-check.cjs · 手机 App 离线壳与提醒链路自检
   ------------------------------------------------------------
   不需要真机：用 CDP 起 headless Chrome，先按「浏览器」跑一遍，
   再用 addScriptToEvaluateOnNewDocument 注入一个假 Capacitor 桥，
   让页面以为自己在 App 里，从而验证：
     A 浏览器模式：零接口请求、云端总开关关闭、原生桥不误触发
     B App 模式  ：壳探测、四类提醒排程、通道创建、震动分档、
                   设置面板原地折叠、App 内隐藏登录/云端入口
   用法：node mobile/scripts/cdp-app-shell-check.cjs
   ============================================================ */
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');

const WWW = path.resolve(__dirname, '..', 'www');
const PORT = 8799;
const BASE = 'http://127.0.0.1:' + PORT + '/';
const CDP = 9388;
const sleep = ms => new Promise(r => setTimeout(r, ms));

let pass = 0, fail = 0;
function ok(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓ ' + name); }
  else { fail++; console.log('  ✗ ' + name + (extra ? '  → ' + extra : '')); }
}
function head(t) { console.log('\n=== ' + t + ' ==='); }

/* ---------- 极简静态服务器（模拟 WebView 的本地源） ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.json': 'application/json', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const u = (req.url || '/').split('?')[0];
  if (/^\/api\//.test(u)) { res.writeHead(500).end('{}'); return; }   /* 离线包不该碰它 */
  const f = path.join(WWW, u === '/' ? 'index.html' : u);
  if (!f.startsWith(WWW) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404).end('nf'); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});

/* ---------- 假 Capacitor 桥：记录所有原生调用 ---------- */
const MOCK = `
(function(){
  var L = window.__LOG = { scheduled: [], cancelled: [], channels: [], haptic: [], pending: [], perms: 'granted' };
  function P(o){ return Promise.resolve(o); }
  window.Capacitor = {
    isNativePlatform: function(){ return true; },
    getPlatform: function(){ return 'android'; },
    Plugins: {
      LocalNotifications: {
        register: function(){ return P({}); },
        requestPermission: function(){ return P({ display: L.perms, schedule: L.perms }); },
        checkPermissions: function(){ return P({ display: L.perms }); },
        canScheduleExactNotifications: function(){ return P({ result: true }); },
        createChannel: function(c){ L.channels.push(c); return P({}); },
        pending: function(){ return P({ pendingNotifications: L.pending.slice() }); },
        cancel: function(o){
          (o.notifications || []).forEach(function(n){
            L.cancelled.push(n.id);
            L.pending = L.pending.filter(function(p){ return p.id !== n.id; });
          });
          return P({});
        },
        schedule: function(o){
          (o.notifications || []).forEach(function(n){
            L.scheduled.push(n);
            L.pending.push({ id: n.id, title: n.title });
          });
          return P({});
        },
        addListener: function(){ return P({ remove: function(){} }); },
        openSettings: function(){ return P({}); }
      },
      Haptics: {
        impactOccurred: function(o){ L.haptic.push('impact-' + o.style); return P({}); },
        notificationSuccess: function(){ L.haptic.push('success'); return P({}); },
        notificationWarning: function(){ L.haptic.push('warning'); return P({}); },
        notificationError: function(){ L.haptic.push('error'); return P({}); },
        selectionChanged: function(){ L.haptic.push('selection'); return P({}); }
      },
      App: {
        addListener: function(){ return P({ remove: function(){} }); },
        openAppSettings: function(){ return P({}); }
      }
    }
  };
})();
`;

async function main() {
  if (!fs.existsSync(path.join(WWW, 'index.html'))) {
    console.error('✗ 缺少 mobile/www，请先跑 npm --prefix mobile run web');
    process.exit(1);
  }
  await new Promise(r => server.listen(PORT, r));
  const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--no-sandbox',
    '--remote-debugging-port=' + CDP, '--window-size=420,900', 'about:blank'], { stdio: 'ignore' });

  let list;
  for (let i = 0; i < 60; i++) {
    try { list = await (await fetch('http://127.0.0.1:' + CDP + '/json/list')).json(); if (list.length) break; } catch (e) {}
    await sleep(250);
  }
  if (!list || !list.length) { console.error('✗ Chrome 未起来'); chrome.kill(); server.close(); process.exit(1); }

  const ws = new WebSocket(list.find(t => t.type === 'page').webSocketDebuggerUrl);
  await new Promise(r => ws.addEventListener('open', r));
  let id = 0; const pend = new Map(); const errs = []; const reqs = [];
  ws.addEventListener('message', ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); }
    if (m.method === 'Runtime.exceptionThrown') {
      const d = ((m.params.exceptionDetails.exception || {}).description || m.params.exceptionDetails.text || '').split('\n')[0].slice(0, 200);
      errs.push(d); console.log('  !! 页面异常: ' + d);
    }
    if (m.method === 'Network.requestWillBeSent') reqs.push(m.params.request.url);
  });
  const send = (method, params = {}) => new Promise(r => { const n = ++id; pend.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
  const evl = async e => {
    var src = String(e).trim();
    var expr = /^function\b/.test(src) ? '(' + src + ')()' : '(' + src + ')';
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
    if (r.result && r.result.exceptionDetails) return { __err: r.result.exceptionDetails.exception };
    return r.result && r.result.result ? r.result.result.value : undefined;
  };

  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 420, height: 900, deviceScaleFactor: 2, mobile: true });

  /* ============ A. 浏览器模式 ============ */
  head('A 浏览器模式（无原生桥）');
  await send('Page.navigate', { url: BASE });
  await sleep(1800);
  ok('页面加载无 JS 异常', errs.length === 0, errs[0]);
  ok('WorkbenchDB 就绪', await evl(`!!window.WorkbenchDB`));
  ok('云端总开关关闭（CLOUD_ENABLED=false）', await evl(`window.WorkbenchDB.CLOUD_ENABLED === false`));
  ok('原生桥存在但判定为非 App', await evl(`!!window.KlogNative && window.KlogNative.isApp === false`));
  ok('壳标记为 web', await evl(`document.documentElement.getAttribute('data-shell') === 'web'`));
  ok('未发起任何 /api/ 请求', reqs.filter(u => u.indexOf('/api/') >= 0).length === 0,
      reqs.filter(u => u.indexOf('/api/') >= 0).join(','));

  /* 走完首访引导 */
  await evl(`function(){var b=document.getElementById('obStart');if(b)b.click();return 1}`);
  await sleep(400);
  await evl(`function(){var i=document.getElementById('obNick');if(!i)return 0;i.value='自检君';
             var e=new Event('input',{bubbles:true});i.dispatchEvent(e);
             var c=document.getElementById('obCreate');if(c)c.click();return 1}`);
  await sleep(1200);
  ok('引导完成后数据层已落盘', await evl(`!!window.WorkbenchDB._data`));

  /* ============ B. App 模式 ============ */
  head('B App 模式（注入假 Capacitor 桥）');
  errs.length = 0; reqs.length = 0;
  await send('Page.addScriptToEvaluateOnNewDocument', { source: MOCK });
  await send('Page.navigate', { url: BASE });
  await sleep(2000);
  ok('启动无 JS 异常', errs.length === 0, errs[0]);
  ok('判定为 App', await evl(`window.KlogNative.isApp === true`));
  ok('壳标记为 app', await evl(`document.documentElement.getAttribute('data-shell') === 'app'`));
  ok('仍保持本地模式（零接口）', await evl(`window.WorkbenchDB.CLOUD_ENABLED === false`));

  /* 引导 + 造数据（必须等首访引导真正结束，否则会被启动期的异步 load 覆盖） */
  await evl(`function(){var b=document.getElementById('obStart');if(b)b.click();return 1}`);
  await sleep(400);
  await evl(`function(){var i=document.getElementById('obNick');if(!i)return 0;i.value='自检君';
             var e=new Event('input',{bubbles:true});i.dispatchEvent(e);
             var c=document.getElementById('obCreate');if(c)c.click();return 1}`);
  for (let i = 0; i < 40; i++) {
    const ready = await evl(`function(){ return !document.querySelector('.ob-mask') && !!window.WorkbenchDB && !!window.WorkbenchDB._data }`);
    if (ready) break;
    await sleep(250);
  }
  /* 建档后数据层会异步改读新键并整体替换 _data；探针直接调 DB 方法会绕过 UI 门控，
     必须等引用连续稳定，否则先写入的那条会被这次替换冲掉 */
  const settle = await evl(`function(){ return new Promise(function(res){
      var DB = window.WorkbenchDB, a = DB._data, n = 0;
      var iv = setInterval(function () {
        n++;
        if (DB._data !== a) { a = DB._data; n = 0; }
        if (n >= 3) { clearInterval(iv); res('stable'); }
        if (n > 40) { clearInterval(iv); res('timeout'); }
      }, 200);
    }) }`);
  ok('数据层引用已稳定（' + settle + '）', settle === 'stable', String(settle));

  const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const seed = await evl(`function(){
    var DB=window.WorkbenchDB;
    DB.addTodo({title:'写周报', due:${JSON.stringify(tomorrow)}});
    DB.addTodo({title:'买猫粮'});                       /* 无到期日：不应产生通知 */
    DB.addSpecial({name:'妈妈生日', date:'1990-05-20', repeat:true, lunar:true});
    DB.addSpecial({name:'结婚纪念', date:'2020-10-01', repeat:true});
    DB.addHabit({name:'喝水'});
    return DB._data.todo.length + '/' + DB._data.special_date.length + '/' + DB._data.habits.length;
  }`);
  ok('数据造好（2 待办 / 2 事件 / 1 习惯）', seed === '2/2/1', String(seed));

  /* ---- 规划器 ---- */
  head('C 提醒规划器');
  const planned = await evl(`function(){ return window.KlogNative.plan(new Date()).map(function(p){
      return { key:p.key, title:p.title, body:p.body, at:p.at.getTime(), every:p.every||null, ch:p.channelId }; }) }`);
  ok('排程条数 > 0', planned.length > 0, JSON.stringify(planned.length));
  const kinds = planned.reduce(function (m, p) { m[p.key.split('|')[0]] = (m[p.key.split('|')[0]] || 0) + 1; return m; }, {});
  ok('含待办到期提醒', !!kinds.todo, JSON.stringify(kinds));
  ok('含纪念日提醒（农历 + 公历两条）', !!kinds.ev, JSON.stringify(kinds));
  ok('含习惯打卡提醒', !!kinds.habit, JSON.stringify(kinds));
  ok('含每日摘要', !!kinds.sum, JSON.stringify(kinds));
  ok('无到期日的待办未被误排', planned.filter(p => p.title.indexOf('买猫粮') >= 0).length === 0);
  ok('全部时间点都在未来', planned.every(p => p.at > Date.now() - 60000));
  ok('摘要为每日重复', planned.some(p => p.key.indexOf('sum|') === 0 && p.every === 'day'));
  /* 公历周年交给系统年周期；农历周年公历日期逐年漂移，只能排最近一次，
     且若下次发生日已超出 30 天窗口，本轮不排才是正确行为 */
  ok('公历周年挂 every:year', planned.some(p => /结婚纪念/.test(p.title) && p.every === 'year'),
      JSON.stringify(planned.filter(p => /纪念|生日/.test(p.title)).map(p => p.title + '#' + p.every)));
  const lunarCheck = await evl(`function(){
      var ev = window.WorkbenchDB.listSpecial().filter(function(x){ return x.name === '妈妈生日'; })[0];
      var got = window.KlogNative.plan(new Date()).filter(function(p){ return /妈妈生日/.test(p.title); });
      return { days: ev ? ev.days : null, n: got.length, every: got[0] ? (got[0].every || null) : null };
    }`);
  ok('农历事件不挂系统年周期（靠滚动续排）',
      lunarCheck.n === 0 ? (lunarCheck.days === null || lunarCheck.days === 0 || lunarCheck.days > 30)
                         : lunarCheck.every === null,
      JSON.stringify(lunarCheck));
  ok('通道 id 全部合法', planned.every(p => ['klog-todo', 'klog-event', 'klog-habit', 'klog-sum'].indexOf(p.ch) >= 0));
  const uniqCount = await evl(`function(){ var s = {};
      window.KlogNative.plan(new Date()).forEach(function(p){ s[window.KlogNative.idOf(p.key)] = 1; });
      return Object.keys(s).length; }`);
  ok('通知 id 无碰撞', uniqCount === planned.length, uniqCount + '/' + planned.length);

  /* ---- 排程落地 ---- */
  head('D 系统排程');
  const syncRes = await evl(`function(){ return window.KlogNative.sync('probe').then(function(r){ return r||{}; }) }`);
  ok('sync 已执行', !!syncRes, JSON.stringify(syncRes));
  const log = await evl(`function(){ return { sched: __LOG.scheduled.length, chans: __LOG.channels.map(function(c){return c.id}), haptic: __LOG.haptic.slice() } }`);
  ok('已排入系统通知', log.sched >= planned.length, log.sched + ' vs ' + planned.length);
  ok('四条通知通道已建', log.chans.length === 4 && log.chans.indexOf('klog-todo') >= 0, JSON.stringify(log.chans));
  const shape = await evl(`function(){ var n=__LOG.scheduled[0]; return { hasId: typeof n.id === 'number',
      hasTitle: !!n.title, hasBody: !!n.body, at: n.schedule && n.schedule.at, ch: n.channelId } }`);
  ok('通知结构完整（数字 id + 标题 + 正文 + 时间）', shape.hasId && shape.hasTitle && !!shape.at, JSON.stringify(shape));

  /* ---- 撤销与重排 ---- */
  head('E 数据变更后重排');
  await evl(`function(){ var t=window.WorkbenchDB._data.todo.filter(function(x){return x.title==='写周报'})[0];
             window.WorkbenchDB.updateTodo(t.id,{done:true}); return 1 }`);
  await sleep(2200);
  const afterDone = await evl(`function(){ return { haptic: __LOG.haptic.slice(), pend: __LOG.pending.length, cancels: __LOG.cancelled.length } }`);
  ok('完成待办 → 成功音', afterDone.haptic.indexOf('success') >= 0, JSON.stringify(afterDone.haptic));
  ok('完成后该条被撤销', afterDone.cancels > 0, JSON.stringify(afterDone));

  await evl(`function(){ var t=window.WorkbenchDB._data.todo.filter(function(x){return x.title==='写周报'})[0];
             window.WorkbenchDB.updateTodo(t.id,{done:false}); return 1 }`);
  await sleep(2000);
  const undo = await evl(`function(){ var a=__LOG.haptic.slice(); return a.filter(function(x){return x==='success'}).length }`);
  ok('取消完成 → 不再响成功音（保持静默）', undo === 1, 'success × ' + undo);

  const delHap = await evl(`function(){ var t=window.WorkbenchDB._data.todo.filter(function(x){return x.title==='买猫粮'})[0];
      window.WorkbenchDB.deleteTodo(t.id); return __LOG.haptic.slice(-1)[0] }`);
  ok('删除待办 → 警告音', delHap === 'warning', String(delHap));

  const errHap = await evl(`function(){ try { window.WorkbenchDB.addTodo({title:''}); } catch(e){} return __LOG.haptic.slice(-1)[0] }`);
  ok('非法输入 → 错误音', errHap === 'error', String(errHap));

  /* ---- 设置面板 ---- */
  head('F 个人中心「提醒与手感」');
  await evl(`function(){ var b=document.getElementById('userBar')||document.getElementById('avatarBtn'); if(b)b.click(); return 1 }`);
  await sleep(1200);
  ok('分区已渲染', await evl(`!!document.getElementById('nt-master')`));
  ok('复用站内开关组件', await evl(`!!document.querySelector('#nt-master') && !!document.querySelector('.pf-switch #nt-master')`));
  ok('四类提醒开关齐全', await evl(`['nt-todo','nt-ev','nt-hb','nt-sm'].every(function(i){return !!document.getElementById(i)})`));
  ok('时间控件为原生 input[type=time]', await evl(`!!document.querySelector('.pf-time') && document.querySelector('.pf-time').type === 'time'`));
  ok('提示行已给出权限结论', await evl(`(document.getElementById('nt-hint').textContent||'').length > 4`));
  ok('排程摘要行有内容', await evl(`/排|条/.test(document.getElementById('nt-plan').textContent)`));

  const fold = await evl(`function(){
      var m=document.getElementById('nt-master'); m.checked=false; m.dispatchEvent(new Event('change',{bubbles:true}));
      var t=document.querySelector('.nt-sub[data-for="nt-todo"]');
      return { hidden: t.hidden, disp: getComputedStyle(t).display }; }`);
  ok('总开关关闭 → 子行收起且真的不可见', fold.hidden === true && fold.disp === 'none', JSON.stringify(fold));
  await sleep(1600);
  ok('关总开关后撤销了系统排程', await evl(`__LOG.pending.length === 0`), await evl(`__LOG.pending.length`));

  const unfold = await evl(`function(){
      var m=document.getElementById('nt-master'); m.checked=true; m.dispatchEvent(new Event('change',{bubbles:true}));
      var t=document.querySelector('.nt-sub[data-for="nt-todo"]');
      var h=document.querySelector('.nt-sub[data-for="nt-hb"]');
      return { todo: getComputedStyle(t).display, hb: getComputedStyle(h).display }; }`);
  ok('重开总开关 → 子行恢复显示', unfold.todo !== 'none' && unfold.hb !== 'none', JSON.stringify(unfold));
  await sleep(1800);
  ok('重开后重新排程', await evl(`__LOG.pending.length > 0`), await evl(`__LOG.pending.length`));

  /* 单项关闭应只收自己 */
  const oneOff = await evl(`function(){
      var h=document.getElementById('nt-hb'); h.checked=false; h.dispatchEvent(new Event('change',{bubbles:true}));
      return { hb: getComputedStyle(document.querySelector('.nt-sub[data-for="nt-hb"]')).display,
               todo: getComputedStyle(document.querySelector('.nt-sub[data-for="nt-todo"]')).display }; }`);
  ok('关单项只收自己', oneOff.hb === 'none' && oneOff.todo !== 'none', JSON.stringify(oneOff));

  /* App 内隐藏登录/云端入口 */
  head('G 离线外壳收口');
  const hidden = await evl(`function(){ var el=document.querySelector('.pf-login-act');
      return { present: !!el, disp: el ? getComputedStyle(el).display : 'n/a' } }`);
  ok('登录入口在 App 内隐藏', !hidden.present || hidden.disp === 'none', JSON.stringify(hidden));
  ok('个人中心无「每日自动备份」行', await evl(`!document.getElementById('pf-auto')`));
  ok('全程零接口请求', reqs.filter(u => u.indexOf('/api/') >= 0).length === 0,
      reqs.filter(u => u.indexOf('/api/') >= 0).join(','));
  ok('App 模式无 JS 异常', errs.length === 0, errs[0]);

  /* ---- 备份搬运链路（电脑导出 → 手机导入） ---- */
  head('H 备份往返');
  const round = await evl(`function(){
      var DB = window.WorkbenchDB;
      var snap = JSON.stringify(DB.exportData());
      var before = DB._data.todo.length + '/' + DB._data.special_date.length;
      DB.reset();
      var mid = DB._data.todo.length;
      DB.importData(snap);
      var lunar = DB._data.special_date.some(function (x) { return x.lunar && x.repeat; });
      return { before: before, mid: mid, after: DB._data.todo.length + '/' + DB._data.special_date.length, lunar: lunar,
               kb: Math.round(snap.length / 1024) };
    }`);
  ok('导出 JSON 可被识别（' + round.kb + ' KB）', round.kb > 0);
  ok('重置后确实清空', round.mid === 0, JSON.stringify(round));
  ok('导入后条数原样恢复', round.before === round.after, round.before + ' → ' + round.after);
  ok('农历周年标记随备份带回', round.lunar === true);
  await sleep(1800);
  ok('导入后排程自动重建', await evl(`__LOG.pending.length > 0`), await evl(`__LOG.pending.length`));
  ok('非 App 环境不接管导出', await evl(`window.KlogNative.isApp ? true : window.KlogNative.saveBackup('{}', 'a.json') === false`));

  console.log('\n────────────────────────────');
  console.log(fail === 0 ? '✓ 全部通过：' + pass + ' 项' : '✗ 通过 ' + pass + ' / 失败 ' + fail);
  ws.close(); chrome.kill(); server.close();
  process.exit(fail === 0 ? 0 : 1);
}

main().catch(function (e) { console.error('✗ ' + (e && e.stack || e)); try { process.exit(1); } catch (_) {} });
