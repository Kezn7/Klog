#!/usr/bin/env node
/* ============================================================
   Klog · Android 图标资源生成（不依赖 @capacitor/assets）
   ------------------------------------------------------------
   品牌源件就是站内 assets/favicon.svg（黑底 + 白色 K 字形），不另画第二套标。
   做法：把 favicon 的 <path> 拆出来，按需重组成不同外壳的 SVG 再用 sharp
   光栅化 —— 全程本地渲染，尺寸精确可控，也不碰 GitHub release 下载（国内易挂）。

   产出到 mobile/native-res/res/，由 apply-native.cjs 覆盖进 Android 工程：
     mipmap 各密度/ic_launcher.png                      传统方形图标
     mipmap 各密度/ic_launcher_round.png                传统圆形图标
     mipmap 各密度/ic_launcher_foreground.png           自适应图标前景层
     mipmap-anydpi-v26/ic_launcher(_round).xml          自适应图标声明（含 monochrome）
     drawable 各密度/ic_notification.png                通知栏小图标（纯白剪影）
   另出 mobile/assets/app-icon.png 与 splash.png 作为「关于」页与商店素材备用。

   用法：node scripts/make-icons.cjs
   ============================================================ */
'use strict';

const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const MOBILE = path.resolve(__dirname, '..');
const ROOT   = path.resolve(MOBILE, '..');
const SRC    = path.join(ROOT, 'assets', 'favicon.svg');
const RES    = path.join(MOBILE, 'native-res', 'res');
const EXTRA  = path.join(MOBILE, 'assets');

const BG    = '#111111';
const INK   = '#FFFFFF';
/* 启动器图标：边长 px（mdpi 48dp 起）；自适应图标层固定 108dp */
const LAUNCH = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
const ADAPT  = { mdpi: 108, hdpi: 162, xhdpi: 216, xxhdpi: 324, xxxhdpi: 432 };
/* 通知小图标：24dp */
const SMALL  = { mdpi: 24, hdpi: 36, xhdpi: 48, xxhdpi: 72, xxxhdpi: 144 };

main().catch(function (e) { console.error('✗ ' + ((e && e.stack) || e)); process.exit(1); });

async function main() {
  const svg = fs.readFileSync(SRC, 'utf8');
  const paths = svg.match(/<path[\s\S]*?\/>/g);
  if (!paths || paths.length < 2) throw new Error('favicon.svg 里没取到字形 <path>，请核对源件');
  const glyph = paths.join('\n');
  /* 字形在 200×200 视口里天然居中（bbox 中心 ≈ 100,100），围绕中心缩放即可 */
  const art = function (scale, color) {
    var inner = color
      ? glyph.replace(/fill="#FCFCFC"/g, 'fill="' + color + '"')
      : glyph;
    return '<g transform="translate(100,100) scale(' + scale + ') translate(-100,-100)">' + inner + '</g>';
  };
  const doc = function (inner) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">'
      + inner + '</svg>';
  };

  const SQUARE = doc('<rect width="200" height="200" rx="25" fill="' + BG + '"/>' + art(0.8, INK));
  const CIRCLE = doc('<circle cx="100" cy="100" r="100" fill="' + BG + '"/>' + art(0.8, INK));
  /* 自适应前景：安全区是 108dp 里的中心 66dp，字形按 0.62 收进安全区内 */
  const FORE   = doc(art(0.62, INK));
  const FLAT   = doc(art(1, INK));            /* 纯字形，透明底 */

  rmrf(RES);
  fs.mkdirSync(EXTRA, { recursive: true });

  for (const d of Object.keys(LAUNCH)) {
    const px = LAUNCH[d], ax = ADAPT[d];
    mkdir(path.join(RES, 'mipmap-' + d));
    await png(SQUARE, px, path.join(RES, 'mipmap-' + d, 'ic_launcher.png'));
    await png(CIRCLE, px, path.join(RES, 'mipmap-' + d, 'ic_launcher_round.png'));
    await png(FORE, ax, path.join(RES, 'mipmap-' + d, 'ic_launcher_foreground.png'));
    mkdir(path.join(RES, 'drawable-' + d));
    await png(FLAT, SMALL[d], path.join(RES, 'drawable-' + d, 'ic_notification.png'));
  }

  /* 自适应图标（Android 8+）：黑底 + 白字形前景；monochrome 供 Android 13 主题图标 */
  mkdir(path.join(RES, 'mipmap-anydpi-v26'));
  const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n'
    + '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
    + '    <background android:drawable="@color/ic_launcher_background"/>\n'
    + '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
    + '    <monochrome android:drawable="@mipmap/ic_launcher_foreground"/>\n'
    + '</adaptive-icon>\n';
  fs.writeFileSync(path.join(RES, 'mipmap-anydpi-v26', 'ic_launcher.xml'), adaptive);
  fs.writeFileSync(path.join(RES, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), adaptive);

  /* 备用素材：1024 图标与启动图（「关于」页、商店上架用） */
  await png(SQUARE, 1024, path.join(EXTRA, 'app-icon.png'));
  await png(doc('<rect width="200" height="200" fill="' + BG + '"/>' + art(0.34, INK)), 2732, path.join(EXTRA, 'splash.png'));

  const files = walk(RES);
  console.log('✓ Android 图标资源：' + files.length + ' 个文件 → mobile/native-res/res');
  console.log('  另出 mobile/assets/{app-icon.png,splash.png}');
}

function png(svgStr, size, out) {
  return sharp(Buffer.from(svgStr), { density: Math.max(300, Math.round(size / 200 * 300)) })
    .resize(size, size, { fit: 'contain', background: '#00000000' })
    .png()
    .toFile(out);
}
function mkdir(p) { fs.mkdirSync(p, { recursive: true }); }
function rmrf(p) {
  if (!fs.existsSync(p)) return;
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    const s = path.join(p, e.name);
    if (e.isDirectory()) rmrf(s); else fs.unlinkSync(s);
  }
  fs.rmdirSync(p);
}
function walk(p) {
  var out = [];
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    const s = path.join(p, e.name);
    if (e.isDirectory()) out = out.concat(walk(s)); else out.push(s);
  }
  return out;
}
