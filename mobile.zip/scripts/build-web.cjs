#!/usr/bin/env node
/* ============================================================
   Klog · 静态化构建：把 index.php 模板固定求值为纯静态 HTML
   ------------------------------------------------------------
   手机 App（Capacitor WebView）里没有 PHP 运行时，但业务数据层
   本来就是 local-first（IndexedDB，未登录态零接口调用），所以打包只需要两件事：
     1) 模板求值 —— 按「本地模式」把 index.php 里的 PHP 片段落成字面量；
     2) 关掉云端 —— 强制 window.LOGIN_AUTHED = false，使
        WorkbenchDB.CLOUD_ENABLED = false，全站零 API 请求、可离线跑。
   任何未识别的 <?php 残留都会让构建直接失败，绝不静默产出可疑页面。

   用法：node scripts/build-web.cjs
   产物：mobile/www/{index.html, assets/**}
   ============================================================ */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MOBILE = path.resolve(__dirname, '..');
const ROOT   = path.resolve(MOBILE, '..');              // 站点根：index.php + assets/
const OUT    = path.join(MOBILE, 'www');
const APP_NAME = 'Klog';

const rel = (...p) => path.join(ROOT, ...p);
const read = p => fs.readFileSync(p, 'utf8');

const misses = [];

/* ---------- 1. 取模板主体（丢弃 PHP 逻辑头部） ---------- */
const raw = read(rel('index.php'));
const start = raw.indexOf('<!DOCTYPE html>');
if (start < 0) fail('index.php 里找不到 <!DOCTYPE html>');
let html = raw.slice(start);

/* ---------- 2. 构建号：按内容哈希，跨机器、跨打包稳定 ---------- */
const HASHFILES = ['assets/workbench.css', 'assets/app.js', 'assets/workbench-db.js', 'assets/klog-native.js'];
const build = HASHFILES
  .map(f => f + ':' + crypto.createHash('md5').update(read(rel(f))).digest('hex').slice(0, 12))
  .join('-');

/* ---------- 3. 资源版本查询串：静态包整体随 APK 分发，去掉 ?v= ---------- */
html = html.replace(/([?&]v=)<\?php[^>]*\?>/g, '');

/* ---------- 4. 用户管理入口整块删除（离线包不存在多账号） ---------- */
html = html.replace(/\n?[ \t]*<\?php if \(\$wbIsMax\): \?>[\s\S]*?<\?php endif; \?>\n?/g, '\n');

/* ---------- 5. 字面量求值表（顺序敏感；未命中即报错） ---------- */
const L = [
  /* 标题 / 品牌 / 构建号 */
  [`<title><?php echo htmlspecialchars($appName, ENT_QUOTES, 'UTF-8'); ?></title>`,
   `<title>${APP_NAME}</title>`],
  [`<div class="logo-cn"><?php echo htmlspecialchars($appName, ENT_QUOTES, 'UTF-8'); ?></div>`,
   `<div class="logo-cn">${APP_NAME}</div>`],
  [`content="<?php echo htmlspecialchars($wbBuild, ENT_QUOTES, 'UTF-8'); ?>"`,
   `content="${build}"`],
  [`var B = '<?php echo htmlspecialchars($wbBuild, ENT_QUOTES, 'UTF-8'); ?>';`,
   `var B = '${build}';`],

  /* 顶栏身份：一律落成本机访客 */
  [`<span class="user-avatar" aria-hidden="true"><?php echo function_exists('mb_substr') && $wbMe !== '' ? mb_substr($wbMe, 0, 1) : ($wbMe !== '' ? substr($wbMe, 0, 1) : '客'); ?></span>`,
   `<span class="user-avatar" aria-hidden="true">客</span>`],
  [`<span class="user-name"><?php echo htmlspecialchars($wbMe !== '' ? wb_display_name($wbMe) : '访客', ENT_QUOTES, 'UTF-8'); ?><?php if ($wbMe !== ''): ?> <span class="role-badge role-<?php echo htmlspecialchars($wbRole, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars(wb_display_name($wbRole), ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?></span>`,
   `<span class="user-name">访客</span>`],
  [`<span class="user-sub"><?php echo $wbMe !== '' ? '个人中心' : '本地模式'; ?></span>`,
   `<span class="user-sub">本机存储</span>`],
  [`title="个人中心与设置"><?php echo $wbMe !== '' ? htmlspecialchars(function_exists('mb_substr') ? mb_substr($wbMe, 0, 1) : substr($wbMe, 0, 1), ENT_QUOTES, 'UTF-8') : '客'; ?></button>`,
   `title="个人中心与设置">客</button>`],

  /* 登录浮层：保留 DOM（app.js 有 null 保护，避免整页崩），但不自动弹出 */
  [`<div class="login-mask" id="loginMask" <?php if ($__loginError !== '') echo 'data-open="1"'; ?> hidden>`,
   `<div class="login-mask" id="loginMask" hidden>`],
  [`<div class="login-error"><?php echo htmlspecialchars($__loginError, ENT_QUOTES, 'UTF-8'); ?></div>`,
   `<div class="login-error"></div>`],
  [`<?php if (!$__authed): ?>`, ``],
  [`<?php endif; ?>`, ``],

  /* 登录态注入：强制本地模式 —— 整份包能离线运行的关键 */
  [`<script>window.LOGIN_AUTHED = <?php echo $__authed ? 'true' : 'false'; ?>;window.LOGIN_USER = <?php echo json_encode($wbMe !== '' ? $wbMe : ''); ?>;window.LOGIN_ROLE = <?php echo json_encode($wbMe !== '' ? $wbRole : 'free'); ?>;</script>`,
   `<script>window.LOGIN_AUTHED = false;window.LOGIN_USER = "";window.LOGIN_ROLE = "free";`
   + `window.KLOG_BUILD = ${JSON.stringify(build)};</script>`],
];
for (const [from, to] of L) {
  if (html.indexOf(from) < 0) { misses.push('未命中：' + from.slice(0, 90)); continue; }
  html = html.split(from).join(to);
}

/* ---------- 6. 残留检查 ---------- */
const left = html.split('\n').map((l, i) => [i + 1, l]).filter(([, l]) => /<\?(php|=)/.test(l));
if (misses.length || left.length) {
  if (misses.length) console.error('✗ 以下模板片段未被求值：\n' + misses.map(m => '  ' + m).join('\n'));
  if (left.length) console.error('✗ 仍有未求值的 PHP：\n' + left.map(([n, l]) => `  L${n}: ${l.trim().slice(0, 160)}`).join('\n'));
  process.exit(1);
}

/* ---------- 7. 落盘 ---------- */
rmrf(OUT);
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'index.html'), html);
copyDir(rel('assets'), path.join(OUT, 'assets'));

const bytes = fs.statSync(path.join(OUT, 'index.html')).size;
console.log(`✓ 静态包：${path.relative(ROOT, OUT).replace(/\\/g, '/')}  index.html ${(bytes / 1024).toFixed(1)} KB`);
console.log(`  build ${build}`);

/* ---------- 工具 ---------- */
function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const s = path.join(from, e.name), d = path.join(to, e.name);
    if (e.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}
function rmrf(p) {
  if (!fs.existsSync(p)) return;
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    const s = path.join(p, e.name);
    if (e.isDirectory()) rmrf(s); else fs.unlinkSync(s);
  }
  fs.rmdirSync(p);
}
function fail(msg) { console.error('✗ ' + msg); process.exit(1); }
