#!/usr/bin/env node
/* ============================================================
   Klog · Android 工程落地（幂等，可在 CI 每次构建前重跑）
   ------------------------------------------------------------
   cap sync 只会覆盖 www 资源与插件注册，不会替我们声明权限，
   所以这里做三件事，且都可重复执行：
     1) 把 native-res/res 覆盖进 android/app/src/main/res（图标与通知小图标）
     2) 把模板默认的 ic_launcher_background 从 #FFFFFF 改回品牌黑 #111111
        —— 不改的话自适应图标是白底白字，直接看不见
     3) 往 AndroidManifest 补通知/精确闹钟/震动/开机恢复四类权限
   另外：用 package.json 版本与 CI 构建号回填 versionName / versionCode。

   用法：node scripts/apply-native.cjs
   ============================================================ */
'use strict';

const fs = require('fs');
const path = require('path');

const MOBILE = path.resolve(__dirname, '..');
const ANDROID = path.join(MOBILE, 'android');
const RES_SRC = path.join(MOBILE, 'native-res', 'res');
const MANIFEST = path.join(ANDROID, 'app/src/main/AndroidManifest.xml');
const GRADLE = path.join(ANDROID, 'app/build.gradle');
const BG_COLOR = path.join(ANDROID, 'app/src/main/res/values/ic_launcher_background.xml');

const PKG = JSON.parse(fs.readFileSync(path.join(MOBILE, 'package.json'), 'utf8'));

/* 通知（Android 13+ 运行时权限）· 精确闹钟 · 震动 · 开机后恢复已排提醒 */
const PERMS = [
  ['android.permission.POST_NOTIFICATIONS', '通知栏提醒'],
  ['android.permission.SCHEDULE_EXACT_ALARM', '精确闹钟（到点即发）'],
  ['android.permission.USE_EXACT_ALARM', '闹钟类应用的精确闹钟授权'],
  ['android.permission.VIBRATE', '震动反馈'],
  ['android.permission.RECEIVE_BOOT_COMPLETED', '重启后恢复已排提醒'],
  ['android.permission.WAKE_LOCK', '唤醒设备以准点投递']
];

if (!fs.existsSync(ANDROID)) fail('未找到 android/ 工程，请先执行 npx cap add android');
if (!fs.existsSync(MANIFEST)) fail('未找到 AndroidManifest.xml');

/* ---------- 1. 覆盖资源 ---------- */
let copied = 0;
if (fs.existsSync(RES_SRC)) {
  copyMerge(RES_SRC, path.join(ANDROID, 'app/src/main/res'));
  copied = countFiles(RES_SRC);
}
console.log('✓ 资源覆盖：' + copied + ' 个文件 → android/app/src/main/res');

/* ---------- 2. 品牌底色 ---------- */
if (fs.existsSync(BG_COLOR)) {
  const before = fs.readFileSync(BG_COLOR, 'utf8');
  const after = before.replace(/(<color name="ic_launcher_background">)[^<]*(<\/color>)/, '$1#111111$2');
  if (after !== before) fs.writeFileSync(BG_COLOR, after);
  console.log('✓ 自适应图标底色：' + (/#111111/.test(after) ? '#111111' : '未改到，请检查 ' + BG_COLOR));
} else {
  console.log('! 模板里没有 values/ic_launcher_background.xml（可能已改结构），跳过底色');
}

/* ---------- 3. 权限 ---------- */
let mf = fs.readFileSync(MANIFEST, 'utf8');
const add = PERMS.filter(function (p) { return mf.indexOf(p[0]) < 0; });
if (add.length) {
  const block = add.map(function (p) {
    return '    <uses-permission android:name="' + p[0] + '" /> <!-- ' + p[1] + ' -->';
  }).join('\n');
  if (mf.indexOf('<!-- Permissions -->') >= 0) {
    mf = mf.replace('<!-- Permissions -->', '<!-- Permissions -->\n' + block);
  } else {
    mf = mf.replace('</application>', '</application>\n\n' + block + '\n');
  }
  fs.writeFileSync(MANIFEST, mf);
  console.log('✓ 权限新增 ' + add.length + ' 条');
} else {
  console.log('✓ 权限齐备，无需改动');
}

/* ---------- 4. 版本号 ---------- */
if (fs.existsSync(GRADLE)) {
  let g = fs.readFileSync(GRADLE, 'utf8');
  const buildNo = parseInt(process.env.KLOG_BUILD_NO || '0', 10);
  const code = buildNo > 0 ? buildNo : 1;
  g = g.replace(/versionName\s+"[^"]*"/, 'versionName "' + PKG.version + '"');
  g = g.replace(/versionCode\s+\d+/, 'versionCode ' + code);
  fs.writeFileSync(GRADLE, g);
  console.log('✓ 版本：versionName ' + PKG.version + ' / versionCode ' + code);
}

console.log('完成。下一步：cd android && gradlew assembleDebug（或交给 CI）');

/* ---------- 工具 ---------- */
function copyMerge(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const s = path.join(from, e.name), d = path.join(to, e.name);
    if (e.isDirectory()) copyMerge(s, d);
    else fs.copyFileSync(s, d);
  }
}
function countFiles(p) {
  let n = 0;
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    n += e.isDirectory() ? countFiles(path.join(p, e.name)) : 1;
  }
  return n;
}
function fail(msg) { console.error('✗ ' + msg); process.exit(1); }
