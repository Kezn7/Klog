/* ============================================================
   Klog · 原生能力桥（Capacitor / Android App）
   ------------------------------------------------------------
   职责：
     1) 震动反馈 —— 数据变更成功/失败/危险操作的手感；Web 端降级 navigator.vibrate
     2) 系统通知 —— 待办到期、纪念日（含农历）、习惯打卡、每日摘要，
                    排进系统闹钟，App 被杀、锁屏、离线都照响
     3) 提醒设置 —— 复用个人中心既有 .pfg/.pf-switch/.pf-seg 组件语言，不另创第二套样式
     4) 离线外壳 —— App 内隐藏登录与云端相关行

   加载顺序：workbench-db.js → **本文件** → app.js
   硬约束：本文件在浏览器里必须完全无害。所有原生调用都带存在性守卫并吞掉异常，
           任何一次插件失败都不允许冒到业务层。
   ============================================================ */
(function (global) {
  'use strict';

  var Cap = global.Capacitor;
  var PLUGINS = (Cap && Cap.Plugins) || {};
  var IS_APP = (Cap && typeof Cap.isNativePlatform === 'function')
    ? !!Cap.isNativePlatform()
    : (global.KLOG_SHELL === 'app');
  var PLATFORM = (Cap && Cap.getPlatform) ? Cap.getPlatform() : 'web';

  var LN  = PLUGINS.LocalNotifications || null;   /* @capacitor/local-notifications */
  var HP  = PLUGINS.Haptics || null;              /* @capacitor/haptics             */
  var APP = PLUGINS.App || null;                  /* @capacitor/app                 */

  /* ---------------- 工具 ---------------- */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dateStr(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(d, n) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n, d.getHours(), d.getMinutes(), 0, 0);
  }
  function parseHM(s, dflt) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(String(s == null ? '' : s));
    if (!m) return dflt;
    return { h: Math.min(23, +m[1]), m: Math.min(59, +m[2]) };
  }
  function atTime(ds, hm, dayOffset) {
    var p = String(ds).split('-');
    return new Date(+p[0], +p[1] - 1, +p[2] + (dayOffset || 0), hm.h, hm.m, 0, 0);
  }
  function ls(k, dflt) {
    try { var v = global.localStorage.getItem(k); return v === null ? dflt : v; } catch (e) { return dflt; }
  }
  function lsSet(k, v) { try { global.localStorage.setItem(k, String(v)); } catch (e) { /* 忽略 */ } }
  function on(k) { return ls(k, '1') !== '0'; }
  function attempt(fn, fallback) {           /* 原生方法可能整个缺失：调用本身也要保护 */
    try {
      var r = fn();
      if (r && typeof r.then === 'function') return r.catch(function (e) { note(e); return fallback; });
      return Promise.resolve(r === undefined ? fallback : r);
    } catch (e) { note(e); return Promise.resolve(fallback); }
  }
  var lastError = '';
  function note(e) { if (e) { lastError = String((e && e.message) || e); if (global.console) global.console.warn('[klog-native]', lastError); } }

  /* ---------------- 设置项（沿用站内 wb_ 前缀；总开关复用旧键 wb_reminder） ---------------- */
  var K = {
    master: 'wb_reminder', haptic: 'wb_haptic',
    todo_on: 'wb_nt_todo', todo_at: 'wb_nt_todo_time',
    ev_on: 'wb_nt_event',  ev_at: 'wb_nt_event_time',  ev_lead: 'wb_nt_event_lead',
    hb_on: 'wb_nt_habit',  hb_at: 'wb_nt_habit_time',
    sm_on: 'wb_nt_sum',    sm_at: 'wb_nt_sum_time',
    plan: 'wb_nt_plan'
  };
  var DFLT = { todo: '09:00', event: '09:30', habit: '21:00', sum: '08:30' };
  function settings() {
    return {
      master: on(K.master),
      haptic: on(K.haptic),
      todo:  { on: on(K.todo_on), time: ls(K.todo_at, DFLT.todo) },
      event: { on: on(K.ev_on),   time: ls(K.ev_at, DFLT.event), lead: parseInt(ls(K.ev_lead, '0'), 10) || 0 },
      habit: { on: on(K.hb_on),   time: ls(K.hb_at, DFLT.habit) },
      sum:   { on: on(K.sm_on),   time: ls(K.sm_at, DFLT.sum) }
    };
  }

  /* ============================================================
     一、震动反馈
     ============================================================ */
  /* 档位：light / medium / heavy（冲击）· success / warning / error（通知音）· selection（微调） */
  function haptic(kind) {
    if (!on(K.haptic)) return;
    if (IS_APP && HP) {
      var ok = attempt(function () {
        if (kind === 'success' || kind === 'warning' || kind === 'error') {
          var fn = HP['notification' + kind.charAt(0).toUpperCase() + kind.slice(1)];
          if (typeof fn === 'function') return fn.call(HP);
        }
        if (kind === 'selection' && typeof HP.selectionChanged === 'function') return HP.selectionChanged();
        var style = (kind === 'heavy' || kind === 'error') ? 'heavy'
                  : (kind === 'medium' || kind === 'warning') ? 'medium' : 'light';
        if (typeof HP.impactOccurred === 'function') return HP.impactOccurred({ style: style });
        return null;
      }, null);
      if (ok) { ok.catch(function (e) { note(e); }); return; }
    }
    if (global.navigator && typeof global.navigator.vibrate === 'function') {
      var pat = kind === 'error'   ? [0, 46, 90, 46, 90, 60]
              : kind === 'warning' || kind === 'medium' ? [0, 34, 60, 34]
              : kind === 'heavy'   ? [0, 58]
              : kind === 'success' ? [0, 18, 40, 18]
              : [0, 12];
      try { global.navigator.vibrate(pat); } catch (e) { /* 忽略 */ }
    }
  }

  /* 数据层方法 → 手感。遵循站内既有的克制原则：只有「完成」这类正反馈响一次，
     取消完成 / 撤销打卡一律静默；破坏性操作给警告音，异常给错误音。 */
  var HAPTIC_MAP = {
    addTodo: 'light', updateTodo: 'light', archiveTodo: 'medium', unarchiveTodo: null,
    deleteTodo: 'warning', restoreTrash: 'light', purgeTrash: 'error', emptyTrash: 'error',
    checkInHabit: 'success', undoCheckIn: null, toggleHabit: 'none',
    addHabit: 'light', updateHabit: 'light', removeHabit: 'warning',
    addSpecial: 'light', updateSpecial: 'light', deleteSpecial: 'warning',
    addMemo: 'light', updateMemo: 'light', deleteMemo: 'warning', toggleMemoPin: 'light',
    deleteTag: 'warning', renameTag: 'light',
    addCategory: 'light', updateCategory: 'light', removeCategory: 'warning',
    addEventType: 'light', updateEventType: 'light', removeEventType: 'warning',
    saveDiary: 'light', deleteDiary: 'warning',
    setupProfile: 'success', importData: 'success', reset: 'error'
  };
  function hapticFor(name, args, threw) {
    if (threw) { haptic('error'); return; }
    if (name === 'updateTodo') {           /* 完成=成功音；取消完成=静默 */
      var patch = args[1];
      if (patch && patch.done === true) { haptic('success'); return; }
      if (patch && patch.done === false) return;
      haptic('light'); return;
    }
    if (name === 'toggleHabit') return;    /* 内部已走 checkIn / undo，避免双震 */
    var k = HAPTIC_MAP[name];
    if (k && k !== 'none') haptic(k);
  }

  /* ============================================================
     二、提醒规划器（纯计算：浏览器里也能直接断言，不依赖真机）
     ============================================================ */
  var CH = {
    todo:  { id: 'klog-todo',  name: '待办到期', desc: '待办到期提醒',         imp: 4 },
    event: { id: 'klog-event', name: '纪念日',   desc: '生日、纪念与事件提醒', imp: 4 },
    habit: { id: 'klog-habit', name: '习惯打卡', desc: '每日习惯打卡提醒',     imp: 3 },
    sum:   { id: 'klog-sum',   name: '日程摘要', desc: '每日概要与统计',       imp: 2 }
  };
  var MAX_PLAN = 55;      /* Android 侧插件对未决通知数有硬性上限，留余量 */
  var HORIZON = 30;       /* 往后排程天数，随重排滚动续期 */

  function idOf(key) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < key.length; i++) { h ^= key.charCodeAt(i); h = (h * 16777619) >>> 0; }
    return (h % 1900000000) + 1000;
  }

  /* 重复待办 → 未来最近一次发生日期 + 可交给系统的周期 */
  function todoOccurrence(t, now) {
    var r = t.repeat, base = t.due;
    if (!r || !r.type) return { date: base, every: null };
    var p = String(base).split('-');
    var due = new Date(+p[0], +p[1] - 1, +p[2]);
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var first = due > today ? due : today;
    if (r.type === 'daily') return { date: dateStr(first), every: 'day' };
    if (r.type === 'weekly') {
      var days = (r.days && r.days.length) ? r.days : [due.getDay()];
      for (var i = 0; i < 8; i++) {
        var c = addDays(first, i);
        if (days.indexOf(c.getDay()) >= 0) return { date: dateStr(c), every: 'week' };
      }
      return { date: base, every: 'week' };
    }
    if (r.type === 'monthly') {
      for (var n = 0; n < 26; n++) {
        var yy = today.getFullYear() + Math.floor((today.getMonth() + n) / 12);
        var mm = (today.getMonth() + n) % 12;
        var dim = new Date(yy, mm + 1, 0).getDate();
        var c2 = new Date(yy, mm, Math.min(r.dom || 1, dim));
        if (c2 >= today && dateStr(c2) >= base) return { date: dateStr(c2), every: 'month' };
      }
      return { date: base, every: 'month' };
    }
    for (var k = 0; k < 3; k++) {          /* yearly */
      var c3 = new Date(today.getFullYear() + k, +p[1] - 1, +p[2]);
      if (c3 >= today) return { date: dateStr(c3), every: 'year' };
    }
    return { date: base, every: 'year' };
  }

  function todoStats(d, ds) {
    var s = { open: 0, today: 0, over: 0 };
    (d.todo || []).forEach(function (t) {
      if (!t || t.done || t.archived) return;
      s.open++;
      if (!t.due) return;
      if (t.due === ds) s.today++;
      else if (t.due < ds) s.over++;
    });
    return s;
  }
  function habitsUnchecked(d, ds) {
    var out = [];
    (d.habits || []).forEach(function (h) {
      if (!h) return;
      var done = (d.habit_log || []).some(function (l) { return l && l.h === h.id && l.d === ds && (+l.n || 0) > 0; });
      if (!done) out.push(h.name);
    });
    return out;
  }

  /* 期望排程表：[{key,title,body,at,every,channelId,extra}] */
  function plan(now) {
    now = now || new Date();
    var DB = global.WorkbenchDB;
    var cfg = settings();
    var out = [];
    if (!DB || !DB._data || !cfg.master) return out;

    var d = DB._data, ds = dateStr(now), st = todoStats(d, ds);
    var edge = addDays(now, HORIZON).getTime();
    function push(p) {
      if (!(p.at instanceof Date) || isNaN(p.at.getTime())) return;
      if (p.at.getTime() <= now.getTime()) return;                  /* 已过点的一律不排 */
      if (!p.every && p.at.getTime() > edge) return;                /* 一次性受窗口限制 */
      out.push(p);
    }

    /* 1) 待办到期 —— 逐条按到期日+设定时间；逾期数以文字附带 */
    if (cfg.todo.on) {
      var hmT = parseHM(cfg.todo.time, { h: 9, m: 0 });
      (d.todo || []).forEach(function (t) {
        if (!t || t.done || t.archived || !t.due) return;
        var occ = todoOccurrence(t, now);
        push({ key: 'todo|' + t.id + '|' + occ.date + '|' + cfg.todo.time,
               title: '待办到期 · ' + occ.date,
               body: t.title + (st.over ? '（另有 ' + st.over + ' 项逾期）' : ''),
               at: atTime(occ.date, hmT), every: occ.every,
               channelId: CH.todo.id, extra: { kind: 'todo', id: t.id } });
      });
    }

    /* 2) 纪念日 / 生日 —— 发生日由数据层 nextOccur 算好（含农历周年） */
    if (cfg.event.on && typeof DB.listSpecial === 'function') {
      var hmE = parseHM(cfg.event.time, { h: 9, m: 30 });
      (DB.listSpecial() || []).forEach(function (ev) {
        if (!ev || ev.archived || !ev.nextDate || ev.days === null || ev.days < 0) return;
        var body = ev.name + '（' + (ev.lunar ? '农历 ' : '') + ev.nextDate + '）· '
          + (ev.days === 0 ? '就是今天' : '还有 ' + ev.days + ' 天');
        if (cfg.event.lead > 0) {
          push({ key: 'ev|' + ev.id + '|lead' + cfg.event.lead + '|' + cfg.event.time,
                 title: '临近 ' + ev.name, body: cfg.event.lead + ' 天后：' + body,
                 at: atTime(ev.nextDate, hmE, -cfg.event.lead), every: null,
                 channelId: CH.event.id, extra: { kind: 'event', id: ev.id } });
        }
        /* 公历周年交给系统年周期；农历周年的公历日期逐年漂移，只排本次，
           下次 App 启动或 6 小时滚动重排时续上一年 —— 窗口内始终 ≥1 次 */
        push({ key: 'ev|' + ev.id + '|' + ev.nextDate + '|' + cfg.event.time,
               title: (ev.repeat ? '纪念日 · ' : '今天 · ') + ev.name, body: body,
               at: atTime(ev.nextDate, hmE), every: (ev.repeat && !ev.lunar) ? 'year' : null,
               channelId: CH.event.id, extra: { kind: 'event', id: ev.id } });
      });
    }

    /* 3) 习惯打卡 —— 只排一条。打卡会触发 save → 重排，全打完后这条自动被撤销 */
    if (cfg.habit.on && (d.habits || []).length) {
      var hmH = parseHM(cfg.habit.time, { h: 21, m: 0 });
      var left = habitsUnchecked(d, ds);
      if (left.length) {
        var atH = atTime(ds, hmH);
        if (atH.getTime() <= now.getTime()) atH = addDays(atH, 1);
        push({ key: 'habit|' + cfg.habit.time + '|' + left.join(','),
               title: '习惯打卡 · 还差 ' + left.length + ' 项',
               body: left.slice(0, 4).join('、') + (left.length > 4 ? ' 等 ' + left.length + ' 项' : ''),
               at: atH, every: null, channelId: CH.habit.id, extra: { kind: 'habit' } });
      }
    }

    /* 4) 每日摘要 —— 固定时间一条，正文取当前统计 */
    if (cfg.sum.on) {
      var hmS = parseHM(cfg.sum.time, { h: 8, m: 30 });
      var atS = atTime(ds, hmS);
      if (atS.getTime() <= now.getTime()) atS = addDays(atS, 1);
      var bits = ['进行中 ' + st.open + ' 项'];
      if (st.today) bits.push('今日到期 ' + st.today);
      if (st.over) bits.push('逾期 ' + st.over);
      var up = (typeof DB.upcoming === 'function' ? DB.upcoming(7) : []) || [];
      if (up.length) bits.push('7 天内纪念 ' + up.length);
      push({ key: 'sum|' + cfg.sum.time + '|' + bits.join('/'),
             title: '今日日程 · ' + dateStr(atS), body: bits.join(' · '),
             at: atS, every: 'day', channelId: CH.sum.id, extra: { kind: 'summary' } });
    }

    out.sort(function (a, b) { return a.at - b.at; });
    return out.slice(0, MAX_PLAN);
  }
  function fingerprint(list) {
    return list.map(function (p) {
      return p.key + '@' + p.at.getTime() + (p.every ? '#' + p.every : '');
    }).join('|');
  }

  /* ============================================================
     三、排程执行
     ============================================================ */
  var syncing = false, queued = false, timer = null;

  function sync(reason) {
    if (!IS_APP) return Promise.resolve({ skipped: 'web' });
    if (!LN) return Promise.resolve({ skipped: 'no-plugin' });
    if (syncing) { queued = true; return Promise.resolve({ skipped: 'busy' }); }
    syncing = true;
    var list = plan(new Date());
    var fp = fingerprint(list);
    return attempt(function () { return LN.pending(); }, { pendingNotifications: [] })
      .then(function (res) {
        var pend = (res && res.pendingNotifications) || [];
        var want = {};
        list.forEach(function (p) { want[idOf(p.key)] = 1; });
        var stale = pend.filter(function (n) { return !want[n.id]; }).map(function (n) { return { id: n.id }; });
        if (!stale.length && fp === ls(K.plan, '') && list.length && reason === 'data') {
          return { unchanged: true, count: list.length };   /* 数据重排且指纹未变：本轮跳过 */
        }
        var chain = stale.length
          ? attempt(function () { return LN.cancel({ notifications: stale }); }, {})
          : Promise.resolve({});
        return chain.then(function () {
          if (!list.length) { lsSet(K.plan, ''); return { removed: stale.length, count: 0 }; }
          return ensureChannels().then(function () {
            return attempt(function () {
              return LN.schedule({
                notifications: list.map(function (p) {
                  return {
                    id: idOf(p.key), title: p.title, body: p.body,
                    channelId: p.channelId, autoCancel: true, extra: p.extra || {},
                    schedule: { at: p.at, every: p.every || undefined, allowWhileIdle: true }
                  };
                })
              });
            }, {});
          }).then(function () {
            lsSet(K.plan, fp);
            return { scheduled: list.length, removed: stale.length };
          });
        });
      })
      .then(function (r) {
        syncing = false;
        if (queued) { queued = false; queueSync('cascade'); }
        return r || {};
      }, function (e) {
        note(e); syncing = false;
        if (queued) { queued = false; queueSync('cascade'); }
        return { failed: true };
      });
  }
  function queueSync(reason) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(function () { timer = null; sync(reason); }, 1200);
  }
  function flushSync() { if (timer) { clearTimeout(timer); timer = null; } return sync('flush'); }

  var channelsMade = false;
  function ensureChannels() {
    if (channelsMade || !LN || typeof LN.createChannel !== 'function') return Promise.resolve();
    channelsMade = true;
    return [CH.todo, CH.event, CH.habit, CH.sum].reduce(function (p, c) {
      return p.then(function () {
        return attempt(function () {
          return LN.createChannel({ id: c.id, name: c.name, description: c.desc, importance: c.imp, sound: 'default' });
        }, {});
      });
    }, Promise.resolve());
  }

  /* ---------------- 权限与健康度 ---------------- */
  function permissionReport(ask) {
    var r = { notifications: 'unknown', exact: 'unknown', app: IS_APP };
    if (!IS_APP) {
      r.notifications = (global.Notification && global.Notification.permission) || 'unsupported';
      return Promise.resolve(r);
    }
    var jobs = [];
    if (LN) {
      if (ask !== false && typeof LN.requestPermission === 'function') {
        jobs.push(attempt(function () { return LN.requestPermission(); }, {})
          .then(function (res) { if (res && res.display) r.notifications = res.display; }));
      } else if (typeof LN.checkPermissions === 'function') {
        jobs.push(attempt(function () { return LN.checkPermissions(); }, {})
          .then(function (res) { if (res && res.display) r.notifications = res.display; }));
      }
      if (typeof LN.canScheduleExactNotifications === 'function') {
        jobs.push(attempt(function () { return LN.canScheduleExactNotifications(); }, { result: false })
          .then(function (res) { r.exact = (res && res.result) ? 'granted' : 'denied'; }));
      }
    }
    return Promise.all(jobs).then(function () { return r; });
  }
  function openSystemSettings() {
    return attempt(function () {
      if (APP && typeof APP.openAppSettings === 'function') return APP.openAppSettings();
      if (LN && typeof LN.openSettings === 'function') return LN.openSettings();
      return null;
    }, {});
  }
  function requestExact() {
    return attempt(function () {
      if (LN && typeof LN.requestExactNotifications === 'function') return LN.requestExactNotifications();
      return openSystemSettings();
    }, {});
  }

  /* ============================================================
     四、提醒设置 UI（复用个人中心的 pfg / pf-switch / pf-seg）
     结构上所有行常驻 DOM，开关只翻 hidden —— 原地展开收起，不关卡重开
     ============================================================ */
  function pf() { return global.KlogPf || null; }

  function timeRow(parentId, inputId, title, value, shown) {
    var P = pf();
    return '<div class="pfg-row pfg-ctl nt-sub"' + (shown ? '' : ' hidden') + ' data-for="' + parentId + '">'
      + '<span class="pfg-ico" aria-hidden="true">' + P.icons.clock + '</span>'
      + '<span class="pfg-t">' + P.esc(title) + '</span>'
      + '<input type="time" class="pf-time" id="' + inputId + '" value="' + value + '" step="300" aria-label="' + P.esc(title) + '">'
      + '</div>';
  }

  function settingsHtml() {
    var P = pf();
    if (!P) return '';
    var c = settings();
    var sub = function (parent, shown) {
      return ' class="pfg-row pfg-ctl nt-sub" data-for="' + parent + '"' + (shown ? '' : ' hidden');
    };
    var seg = function (id, title, opts, cur) {
      return '<div' + sub(id, cur !== null) + '><span class="pfg-t" style="flex:1 1 auto">' + P.esc(title) + '</span>'
        + '<span class="pf-seg" id="' + id + '" role="group" aria-label="' + P.esc(title) + '">'
        + opts.map(function (o) {
            return '<button type="button" data-v="' + o[0] + '"' + (String(cur) === String(o[0]) ? ' class="active"' : '') + '>'
              + P.esc(o[1]) + '</button>';
          }).join('') + '</span></div>';
    };

    return P.pfGroup('提醒与手感',
        P.pfSwitchRow('nt-master', 'bell', '提醒总开关', c.master)
      + '<div class="pfg-note" id="nt-hint">正在检查系统权限…</div>'
      /* 四个子开关 */
      + P.pfSwitchRow('nt-todo', 'todo', '待办到期', c.todo.on)
      + timeRow('nt-todo', 'nt-todo-at', '到期提醒时间', c.todo.time, c.todo.on)
      + P.pfSwitchRow('nt-ev', 'calendar', '纪念日 / 生日', c.event.on)
      + timeRow('nt-ev', 'nt-ev-at', '纪念提醒时间', c.event.time, c.event.on)
      + seg('nt-lead', '提前提醒', [[0, '当天'], [1, '提前 1 天'], [3, '提前 3 天']], c.event.on ? c.event.lead : null)
      + P.pfSwitchRow('nt-hb', 'habit', '习惯打卡', c.habit.on)
      + timeRow('nt-hb', 'nt-hb-at', '打卡提醒时间', c.habit.time, c.habit.on)
      + P.pfSwitchRow('nt-sm', 'chart', '每日日程摘要', c.sum.on)
      + timeRow('nt-sm', 'nt-sm-at', '摘要推送时间', c.sum.time, c.sum.on)
      /* 震动 */
      + P.pfSwitchRow('nt-haptic', 'size', '重要操作震动', c.haptic)
      + '<div class="pfg-note nt-static">完成待办、打卡、删除归档与出错时给一次手感；取消一律静默。</div>'
      /* 自检与跳转 */
      + '<div class="pfg-row pfg-ctl"><span class="pfg-t" style="flex:1 1 auto">自检</span>'
        + '<span class="pf-seg" id="nt-test" role="group" aria-label="自检">'
          + '<button type="button" data-v="notify">试通知</button>'
          + '<button type="button" data-v="haptic">试震动</button>'
          + '<button type="button" data-v="sync">重建排程</button>'
        + '</span></div>'
      + '<div class="pfg-row pfg-ctl"' + (IS_APP ? '' : ' hidden') + '><span class="pfg-t" style="flex:1 1 auto">系统权限</span>'
        + '<span class="pf-seg"><button type="button" id="nt-sys">通知与闹钟设置</button></span></div>'
      + '<div class="pfg-note" id="nt-plan">加载中…</div>');
  }

  function bindSettings(card) {
    var P = pf();
    if (!P || !card) return;
    function $(sel) { return card.querySelector(sel); }
    function each(list, fn) { Array.prototype.forEach.call(list, fn); }
    function showSub(parentId, shown) {
      each(card.querySelectorAll('.nt-sub[data-for="' + parentId + '"]'), function (el) { el.hidden = !shown; });
    }
    function fmt(d) { return (d.getMonth() + 1) + '/' + d.getDate() + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }

    function paintPlan() {
      var el = $('#nt-plan');
      if (!el) return;
      var list = plan(new Date());
      if (!IS_APP) { el.textContent = '浏览器版只在页面打开期间提醒；安装 App 后可锁屏、离线、被杀进程都准点送达。'; return; }
      el.textContent = '当前排入系统 ' + list.length + ' 条'
        + (list[0] ? '，最早 ' + fmt(list[0].at) : '（无可提醒事项）')
        + (settings().master ? '' : '；总开关已关闭，全部提醒已撤销')
        + (lastError ? '；最近一次提示：' + lastError : '');
    }
    function paintHint() {
      var el = $('#nt-hint');
      if (!el) return;
      var c = settings();
      if (!c.master) { el.textContent = '已关闭全部提醒，系统里排着的通知会一并撤销。'; paintPlan(); return; }
      permissionReport(false).then(function (r) {
        var bits = [];
        if (IS_APP) {
          bits.push(r.notifications === 'granted' ? '通知已授权'
                  : r.notifications === 'denied' ? '通知被拒绝，请在下方「系统权限」里允许'
                  : '通知权限待确认，首次排程会弹窗询问');
          bits.push(r.exact === 'granted' ? '精确闹钟已允许' : '未允许精确闹钟，到点可能有数分钟偏差');
          bits.push('收不到提醒时把 Klog 移出电池优化名单');
        } else {
          bits.push(r.notifications === 'granted' ? '浏览器通知已授权，页面开着才提醒'
                  : r.notifications === 'denied' ? '浏览器通知被拒绝'
                  : r.notifications === 'unsupported' ? '当前浏览器不支持通知'
                  : '浏览器通知待授权，页面开着才提醒');
        }
        el.textContent = bits.join(' · ');
        paintPlan();
      });
    }

    /* 开关：写值 → 原地展开/收起对应子行 → 重排 */
    each(card.querySelectorAll('#nt-master,#nt-todo,#nt-ev,#nt-hb,#nt-sm,#nt-haptic'), function (el) {
      var map = { 'nt-master': [K.master, 'master'], 'nt-todo': [K.todo_on, 'todo'], 'nt-ev': [K.ev_on, 'event'],
                  'nt-hb': [K.hb_on, 'habit'], 'nt-sm': [K.sm_on, 'sum'], 'nt-haptic': [K.haptic, 'haptic'] };
      var m = map[el.id];
      if (!m) return;
      el.addEventListener('change', function () {
        var self = el, checked = !!self.checked;
        lsSet(m[0], checked ? '1' : '0');
        if (m[1] === 'haptic') {
          if (checked) haptic('success');
        } else {
          showSub(self.id, checked);
          if (m[1] === 'event') showSub('nt-lead', checked && on(K.master));
          if (m[1] === 'master') {
            /* 子行是否露出，取决于「总开关 ∧ 该子开关」两者 */
            ['nt-todo', 'nt-ev', 'nt-hb', 'nt-sm'].forEach(function (id) {
              var kid = card.querySelector('#' + id);
              showSub(id, checked && !!(kid && kid.checked));
            });
            var evCb = card.querySelector('#nt-ev');
            showSub('nt-lead', checked && !!(evCb && evCb.checked));
          }
        }
        haptic('selection');
        (m[1] === 'master' ? flushSync : queueSync)('setting');
        paintHint();
      });
    });

    /* 时间：Android WebView 的原生时间对话框就是最合适的控件，不另造滚轮 */
    each(card.querySelectorAll('.pf-time'), function (el) {
      var map = { 'nt-todo-at': K.todo_at, 'nt-ev-at': K.ev_at, 'nt-hb-at': K.hb_at, 'nt-sm-at': K.sm_at };
      el.addEventListener('change', function () {
        var v = parseHM(this.value, null);
        var key = map[this.id];
        if (!v || !key) return;
        lsSet(key, pad(v.h) + ':' + pad(v.m));
        haptic('light');
        queueSync('setting');
        paintPlan();
      });
    });

    /* 分段：提前量 */
    var lead = $('#nt-lead');
    if (lead) lead.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-v]');
      if (!b) return;
      lsSet(K.ev_lead, b.getAttribute('data-v'));
      each(lead.querySelectorAll('button[data-v]'), function (x) { x.classList.toggle('active', x === b); });
      haptic('selection');
      queueSync('setting');
      paintPlan();
    });

    /* 自检 */
    var test = $('#nt-test');
    if (test) test.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-v]');
      if (!b) return;
      var what = b.getAttribute('data-v');
      haptic('selection');
      if (what === 'haptic') {
        haptic('success');
        setTimeout(function () { haptic('warning'); }, 380);
        setTimeout(function () { haptic('error'); }, 780);
        say('依次播放：成功 / 警告 / 错误');
      }
      if (what === 'notify') {
        if (!IS_APP || !LN) { say('浏览器模式不支持排系统闹钟'); return; }
        permissionReport(true).then(function (r) {
          if (r.notifications !== 'granted') { say('系统通知未授权'); paintHint(); return; }
          ensureChannels().then(function () {
            return attempt(function () {
              return LN.schedule({ notifications: [{
                id: 1, title: 'Klog 自检', body: '通知链路正常，锁屏和离线也能收到。',
                channelId: CH.sum.id, autoCancel: true,
                schedule: { at: new Date(Date.now() + 6000) }
              }] });
            }, {});
          }).then(function () { say('已排一条 6 秒后的自检通知'); });
        });
      }
      if (what === 'sync') {
        flushSync().then(function (res) {
          say(IS_APP ? ('排程完成：' + ((res && (res.scheduled || res.count || res.removed)) || 0) + ' 条') : '浏览器模式：仅计算，不排系统闹钟');
          paintPlan();
        });
      }
    });
    var sys = $('#nt-sys');
    if (sys) sys.addEventListener('click', function () { haptic('light'); openSystemSettings(); });

    function say(msg) {
      var el = $('#nt-plan');
      if (el) { el.textContent = msg; setTimeout(paintPlan, 2600); }
    }
    paintHint();
    paintPlan();
  }

  /* ============================================================
     四·五、备份导出通道
     App 内 WebView 没有下载管理器，<a download> 的 Blob 会静默失败：
     优先系统分享（存到文件 / 发给自己），不支持则退回剪贴板；
     两者都不行才返回 false，让调用方继续走浏览器下载路径。
     ============================================================ */
  function sayToast(msg, type) {
    if (global.KlogToast) { try { global.KlogToast(msg, type); return; } catch (e) { /* 忽略 */ } }
    if (global.console) console.log('[Klog] ' + msg);
  }
  function saveBackup(json, filename) {
    if (!IS_APP) return false;
    try {
      var file = new File([json], filename, { type: 'application/json' });
      if (global.navigator && navigator.canShare && navigator.share &&
          navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: filename }).then(function () {
          sayToast('备份已通过系统分享发出');
          haptic('success');
        }, function (e) {
          if (e && e.name === 'AbortError') return;          /* 用户自己取消，不打扰 */
          note(e);
          copyBackup(json);
        });
        return true;
      }
    } catch (e) { note(e); }
    return copyBackup(json);
  }
  function copyBackup(json) {
    try {
      if (global.navigator && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(json).then(function () {
          sayToast('备份已复制到剪贴板（' + Math.max(1, Math.round(json.length / 1024)) + ' KB），粘贴到任意文本里即可保存');
          haptic('success');
        }, function (e) {
          note(e);
          sayToast('系统分享与剪贴板都不可用，本次未能导出', 'error');
        });
        return true;
      }
    } catch (e) { note(e); }
    return false;
  }

  /* ============================================================
     五、启动与包装
     ============================================================ */
  var wrapped = false;
  function wrapDb() {
    var DB = global.WorkbenchDB;
    if (!DB || wrapped) return;
    wrapped = true;
    Object.keys(HAPTIC_MAP).forEach(function (name) {
      var orig = DB[name];
      if (typeof orig !== 'function') return;
      DB[name] = function () {
        var args = arguments;
        try {
          var r = orig.apply(this, args);
          hapticFor(name, args, false);
          return r;
        } catch (e) {
          hapticFor(name, args, true);
          throw e;
        }
      };
    });
    var origSave = DB.save;
    if (typeof origSave === 'function') {
      DB.save = function () {
        var r = origSave.apply(this, arguments);
        if (IS_APP) queueSync('data');
        return r;
      };
    }
  }

  function start() {
    if (!IS_APP) return;
    wrapDb();
    hideCloudUi();
    permissionReport(true);
    attempt(function () { return LN && typeof LN.register === 'function' ? LN.register() : null; }, null);
    sync('boot');
    /* 滚动续期：把 30 天窗口往前推，同时刷新摘要与未打卡正文 */
    setInterval(function () { queueSync('tick'); }, 6 * 3600 * 1000);
    if (global.document) {
      global.document.addEventListener('visibilitychange', function () {
        if (!global.document.hidden) queueSync('visible');
      });
    }
    if (APP && typeof APP.addListener === 'function') {
      attempt(function () { return APP.addListener('resume', function () { queueSync('resume'); }); }, null);
      attempt(function () {
        return APP.addListener('pause', function () { if (timer) { clearTimeout(timer); timer = null; } sync('pause'); });
      }, null);
    }
    if (LN && typeof LN.addListener === 'function') {
      attempt(function () {
        return LN.addListener('actionPerformed', function (a) {
          global.__KLOG_DEEPLINK = (a && a.notification && a.notification.extra) || null;
        });
      }, null);
    }
  }

  /* App 内不该出现的入口：登录、云端备份、账号安全 */
  function hideCloudUi() {
    var doc = global.document;
    if (!doc || doc.getElementById('klog-app-css')) return;
    var st = doc.createElement('style');
    st.id = 'klog-app-css';
    st.textContent =
      '[data-shell="app"] .pf-login-act,[data-shell="app"] #pf-auto,[data-shell="app"] #pf-security,'
      + '[data-shell="app"] #pf-remind,[data-shell="app"] #pf-remind-hint,[data-shell="app"] .login-mask'
      + '{display:none!important}'
      + '.pf-time{-webkit-appearance:none;appearance:none;border:0;background:transparent;color:inherit;'
      + 'font:inherit;font-variant-numeric:tabular-nums;text-align:right;min-height:38px;padding:0}'
      + '.pfg-ctl:has(.pf-time){cursor:text}'
      + '.pfg-ctl .pf-seg{flex:0 0 auto}'
      /* .pfg-ctl 自带 display 会压掉 UA 的 [hidden]{display:none}，必须点名补回 */
      + '.nt-sub[hidden]{display:none!important}'
      + '.nt-sub{transition:none}';
    (doc.head || doc.body).appendChild(st);
  }

  /* ---------------- 对外 ---------------- */
  global.KlogNative = {
    isApp: IS_APP,
    platform: PLATFORM,
    settings: settings,
    haptic: haptic,
    plan: plan,
    sync: sync,
    start: start,
    wrapDb: wrapDb,
    settingsHtml: settingsHtml,
    bindSettings: bindSettings,
    saveBackup: saveBackup,
    permissionReport: permissionReport,
    lastError: function () { return lastError; },
    channels: CH,
    keys: K,
    idOf: idOf
  };

  /* 浏览器端：不碰系统闹钟，只接管手感，原 Web 通知逻辑保持原样 */
  wrapDb();
  if (IS_APP) {
    if (global.document && global.document.readyState === 'loading') {
      global.document.addEventListener('DOMContentLoaded', function () { start(); });
    } else { start(); }
  }
})(typeof window !== 'undefined' ? window : this);
