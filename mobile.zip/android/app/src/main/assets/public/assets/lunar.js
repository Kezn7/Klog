/* ============================================================
   农历工具（Klog）
   ------------------------------------------------------------
   公历 ↔ 农历 双向转换，支持 1900-2100 年
   含：闰月 / 农历月日中文 / 干支生肖纪年
   ============================================================ */
(function (global) {
  'use strict';

  /* 1900-2100 年农历数据表：
     bits 0xf     —— 闰月月份（0 表示当年无闰月）
     bit  0x10000 —— 闰月大小（1 = 30 天）
     bits 0xfff0  —— 每月大小（1 = 30 天，自正月起高位到低位） */
  var INFO = [
    0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
    0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
    0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
    0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
    0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
    0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5b0, 0x14573, 0x052b0, 0x0a9a8, 0x0e950, 0x06aa0,
    0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
    0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b6a0, 0x195a6,
    0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
    0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x05ac0, 0x0ab60, 0x096d5, 0x092e0,
    0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
    0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
    0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
    0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
    0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0,
    0x14b63, 0x09370, 0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06b20, 0x1a6c4, 0x0aae0,
    0x0a2e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0, 0x0a6d0, 0x055d4,
    0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50, 0x055a0, 0x0aba4, 0x0a5b0, 0x052b0,
    0x0b273, 0x06930, 0x07337, 0x06aa0, 0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160,
    0x0e968, 0x0d520, 0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a2d0, 0x0d150, 0x0f252,
    0x0d520
  ];

  var MONTH_CN = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊'];
  var DAY_CN = ['初一', '初二', '初三', '初四', '初五', '初六', '初七', '初八', '初九', '初十',
    '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十',
    '廿一', '廿二', '廿三', '廿四', '廿五', '廿六', '廿七', '廿八', '廿九', '三十'];
  var GAN = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'];
  var ZHI = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'];
  var ZODIAC = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪'];

  var MIN_YEAR = 1900, MAX_YEAR = 2100;
  /* 基准日：1900-01-31 = 农历 1900 年正月初一 */
  var BASE = Date.UTC(1900, 0, 31);

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function leapMonth(y) { return INFO[y - MIN_YEAR] & 0xf; }
  function leapDays(y) { return leapMonth(y) ? ((INFO[y - MIN_YEAR] & 0x10000) ? 30 : 29) : 0; }
  function monthDays(y, m) { return (INFO[y - MIN_YEAR] & (0x10000 >> m)) ? 30 : 29; }
  function yearDays(y) {
    var v = INFO[y - MIN_YEAR], sum = 348, i;
    for (i = 0x8000; i > 0x8; i >>= 1) if (v & i) sum++;
    return sum + leapDays(y);
  }

  /* 某农历年的月序列（闰月插在对应月之后），供逐月推算使用 */
  function yearMonths(y) {
    var lm = leapMonth(y), arr = [], i;
    for (i = 1; i <= 12; i++) {
      arr.push({ m: i, leap: false, days: monthDays(y, i) });
      if (lm === i) arr.push({ m: i, leap: true, days: leapDays(y) });
    }
    return arr;
  }

  /* 公历(YYYY-MM-DD) → 农历 {y,m,d,leap}，越界返回 null */
  function solarToLunar(dateStr) {
    var p = String(dateStr || '').split('-');
    if (p.length !== 3) return null;
    var t = Date.UTC(+p[0], +p[1] - 1, +p[2]);
    if (isNaN(t)) return null;
    var offset = Math.round((t - BASE) / 86400000);
    if (offset < 0) return null;
    var y = MIN_YEAR, temp;
    while (y <= MAX_YEAR) { temp = yearDays(y); if (offset < temp) break; offset -= temp; y++; }
    if (y > MAX_YEAR) return null;
    var months = yearMonths(y), i = 0;
    while (i < months.length - 1 && offset >= months[i].days) { offset -= months[i].days; i++; }
    return { y: y, m: months[i].m, leap: months[i].leap, d: offset + 1 };
  }

  /* 农历 → 公历(YYYY-MM-DD)，组合非法（无该闰月/超天数/越界）返回 null */
  function lunarToSolar(y, m, d, leap) {
    if (y < MIN_YEAR || y > MAX_YEAR) return null;
    var months = yearMonths(y), i, target = null;
    for (i = 0; i < months.length; i++) {
      if (months[i].m === m && months[i].leap === !!leap) { target = months[i]; break; }
    }
    if (!target || d < 1 || d > target.days) return null;
    var offset = 0;
    for (var yy = MIN_YEAR; yy < y; yy++) offset += yearDays(yy);
    for (i = 0; i < months.length; i++) {
      if (months[i] === target) break;
      offset += months[i].days;
    }
    offset += d - 1;
    var t = new Date(BASE + offset * 86400000);
    return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate());
  }

  /* ---------------- 名称格式化 ---------------- */
  function monthName(m, leap) { return (leap ? '闰' : '') + MONTH_CN[m - 1] + '月'; }
  function dayName(d) { return DAY_CN[d - 1] || ''; }
  function yearName(y) {
    var g = (y - 4) % 10, z = (y - 4) % 12;
    if (g < 0) g += 10;
    if (z < 0) z += 12;
    return GAN[g] + ZHI[z] + ZODIAC[z] + '年';
  }
  /* 农历月日文本，如「六月初八」「闰四月十四」 */
  function fullText(l) { return l ? monthName(l.m, l.leap) + dayName(l.d) : ''; }

  global.Lunar = {
    MIN_YEAR: MIN_YEAR,
    MAX_YEAR: MAX_YEAR,
    leapMonth: leapMonth,
    monthDays: monthDays,
    yearMonths: yearMonths,
    solarToLunar: solarToLunar,
    lunarToSolar: lunarToSolar,
    monthName: monthName,
    dayName: dayName,
    yearName: yearName,
    fullText: fullText
  };
})(window);
