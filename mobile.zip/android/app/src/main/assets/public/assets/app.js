/* ============================================================
   Klog · 页面交互逻辑
   ------------------------------------------------------------
   依赖 assets/workbench-db.js（数据层）
   职责：视图渲染 / 表单弹窗 / 筛选搜索 / 备份导入导出 /
        主题切换 / 异常与二次确认弹窗 / Toast
   ============================================================ */
(function () {
  'use strict';

  var DB = window.WorkbenchDB;
  var Errors = window.DBErrors;

  var APP_NAME = (document.querySelector('.logo-cn') || {}).textContent || 'Klog';

  /* ---------------- DOM 工具 ---------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* 头像白名单：仅接受本地裁剪上传生成的 data URL，防属性注入 / javascript: 伪协议 */
  function safeAvatar(v) {
    v = String(v == null ? '' : v).replace(/\s/g, '');
    return /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(v) ? v : '';
  }

  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  }

  /* ---------------- 日期工具 ---------------- */
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  function fmtDateTime(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function fmtDate(iso) { return fmtDateTime(iso).slice(0, 10); }

  /* 距今天数：今天 0 / 未来正 / 过去负 */
  function daysFromToday(dateStr) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dateStr || ''))) return null;
    var p = dateStr.split('-');
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var target = new Date(+p[0], +p[1] - 1, +p[2]);
    return Math.round((target - today) / 86400000);
  }

  /* 生日周岁 / 纪念日周年：自 date 起完整经过的年数；未满 1 年或未来日期返回 null */
  function anniversaryCount(dateStr) {
    var p = String(dateStr || '').split('-');
    if (p.length !== 3 || !/^\d{4}$/.test(p[0])) return null;
    var now = new Date();
    var span = now.getFullYear() - (+p[0]);
    if (span <= 0) return null;
    var md = p[1] + p[2];
    var nowMd = String(now.getMonth() + 1).padStart(2, '0') + String(now.getDate()).padStart(2, '0');
    if (md > nowMd) span--; /* 今年的日子还没到 */
    return span >= 1 ? span : null;
  }

  /* 卡片/详情用徽章：生日 → 「N 岁」，纪念日 → 「N 周年」 */
  function yearsTagHtml(type, dateStr) {
    var n = anniversaryCount(dateStr);
    if (n === null) return '';
    return '<span class="tag years-tag">' + n + (type === 'birthday' ? ' 岁' : ' 周年') + '</span>';
  }

  /* 事件类型 → 展示元信息（标签 / 圆点色 / 语义）；生日、纪念日内置，其余按自定义类型解析 */
  function typeMeta(type) {
    if (type === 'birthday') return { label: '生日', color: '#FE2C55', kind: 'birthday' };
    if (type === 'anniversary') return { label: '纪念日', color: '#10B981', kind: 'anniversary' };
    var t = (DB.getEventType && DB.getEventType(type)) || null;
    if (t) return { label: t.name, color: t.color || '#888780', kind: 'custom', id: type };
    return { label: '自定义事件', color: '#888780', kind: 'custom', id: type };
  }

  /* 全部事件类型（内置生日/纪念日 + 自定义），供类型条与「全部类型」浮层共用 */
  function eventTypes() {
    var out = [
      { val: 'birthday', name: '生日', color: '#FE2C55', builtin: true },
      { val: 'anniversary', name: '纪念日', color: '#10B981', builtin: true }
    ];
    DB.listEventTypes().forEach(function (t) { out.push({ val: t.id, name: t.name, color: t.color || '#888780', builtin: false, id: t.id }); });
    return out;
  }
  /* 各类型下的事件数（按 type 原值计，含内置与自定义） */
  function eventTypeCounts() {
    var m = {};
    DB.listSpecial().forEach(function (e) { if (e && !e.archived) m[e.type] = (m[e.type] || 0) + 1; });
    return m;
  }

  function weekdayCN(dateStr) {
    var d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return '';
    return '周' + '日一二三四五六'.charAt(d.getDay());
  }

  function mdCN(dateStr) {
    var p = String(dateStr || '').split('-');
    if (p.length !== 3) return dateStr;
    return (+p[1]) + ' 月 ' + (+p[2]) + ' 日';
  }

  /* 编辑器内的子任务深拷贝 */
  function normSubsForEdit(list) {
    return (Array.isArray(list) ? list : []).map(function (s) {
      return { id: s.id, title: s.title, done: !!s.done };
    });
  }

  /* 重复规则 → 徽标文案 */
  function repeatLabel(rep) {
    if (!rep) return '';
    if (rep.type === 'daily') return '每天';
    if (rep.type === 'weekly') {
      var WD = ['日', '一', '二', '三', '四', '五', '六'];
      return '每周' + rep.days.map(function (d) { return WD[d]; }).join('');
    }
    if (rep.type === 'monthly') return '每月' + rep.dom + '号';
    return '每年';
  }

  /* Markdown 渲染组件：惰性加载 + 失败重试 + 优雅降级
     （规避个别环境下脚本间歇性加载失败导致的静默原文回退） */
  var _markedQueue = null;
  function ensureMarked(cb) {
    if (typeof window.marked !== 'undefined' && window.marked.parse) { cb(true); return; }
    if (_markedQueue) { _markedQueue.push(cb); return; }
    _markedQueue = [cb];
    var s = document.createElement('script');
    s.src = 'assets/vendor/marked.min.js?v=12';
    s.onload = function () {
      var q = _markedQueue; _markedQueue = null;
      var ok = typeof window.marked !== 'undefined' && window.marked.parse;
      q.forEach(function (f) { f(ok); });
    };
    s.onerror = function () {
      var q = _markedQueue; _markedQueue = null;
      q.forEach(function (f) { f(false); });
    };
    document.head.appendChild(s);
  }

  function mdFallbackHtml(src) {
    return '<p class="md-warn">Markdown 渲染组件暂时不可用，当前显示原文（可稍后重开预览）</p>' +
      esc(src).replace(/\n/g, '<br>');
  }

  /* 白名单式消毒：去除脚本类节点 / 事件属性 / javascript: 链接，外链加 noopener */
  function sanitizeMdHtml(html) {
    var box = document.createElement('div');
    box.innerHTML = html;
    box.querySelectorAll('script,style,iframe,object,embed,form,link,meta').forEach(function (el) { el.remove(); });
    box.querySelectorAll('*').forEach(function (el) {
      Array.prototype.forEach.call(el.attributes, function (a) {
        var n = a.name.toLowerCase();
        if (n.indexOf('on') === 0) el.removeAttribute(a.name);
        if ((n === 'href' || n === 'src') && /^\s*javascript:/i.test(a.value)) el.removeAttribute(a.name);
      });
    });
    box.querySelectorAll('a').forEach(function (a) {
      a.setAttribute('target', '_blank');
      a.setAttribute('rel', 'noopener noreferrer');
    });
    return box.innerHTML;
  }

  function mdToHtml(src) {
    try {
      if (typeof window.marked !== 'undefined' && window.marked.parse) {
        /* 注意：str() 是 workbench-db.js 的私有函数，这里不可用（历史上误用导致
           ReferenceError 被 catch 吞掉，Markdown 永远走「显示原文」兜底） */
        return sanitizeMdHtml(window.marked.parse(src == null ? '' : String(src)));
      }
    } catch (e) { /* 渲染异常时回退原文 */ }
    return mdFallbackHtml(src);
  }

  /* ---------------- 页面状态 ---------------- */
  var state = {
    view: 'overview',
    todoFilter: 'all',
    todoSearch: '',
    todoCat: '',      /* 分类筛选：''=全部 / 'none'=未分类 / 分类 id */
    memoSearch: '',
    memoTags: [],
    dateFilter: '',
    dateSearch: '',
    diarySearch: ''
  };

  /* 登录态资料缓存：{ nickname, avatar }；启动时经 profile 接口填充（独立于 state，避开 openProfile(state) 参数遮蔽） */
  var myProfile = null;

  /* 登录态与用户名：以页面注入的 window.LOGIN_AUTHED / LOGIN_USER 为准。
     未登录 = 本地优先模式（数据只存本机昵称 JSON 文件，displayUser 显示昵称）；
     落盘 wb_login_user 仅供登录弹卡预填，属尽力而为——失败不影响本页 */
  var LOGIN_AUTHED = (typeof window.LOGIN_AUTHED !== 'undefined') ? !!window.LOGIN_AUTHED : true;
  var LOGIN_USER = String((typeof window.LOGIN_USER !== 'undefined' && window.LOGIN_USER) ? window.LOGIN_USER : '');
  try { if (LOGIN_USER) localStorage.setItem('wb_login_user', LOGIN_USER); } catch (e) { /* 忽略：配额满/隐私模式 */ }
  function loginUser() { return LOGIN_USER || String((typeof window.LOGIN_USER !== 'undefined' && window.LOGIN_USER) ? window.LOGIN_USER : ''); }
  /* 显示名：登录态首字母大写；本地模式显示设置的昵称 */
  function displayUser() {
    if (!LOGIN_AUTHED) {
      var p = (window.WorkbenchDB && WorkbenchDB.getProfile) ? WorkbenchDB.getProfile() : null;
      return p ? p.nickname : '访客';
    }
    var u = loginUser();
    if (myProfile && myProfile.nickname) return myProfile.nickname; /* 昵称可重复：仅作显示名 */
    return u ? u.charAt(0).toUpperCase() + u.slice(1) : u;
  }
  /* 一次性清理改键前的旧存储键（无用户后缀版本），释放本地配额 */
  try { localStorage.removeItem('workbench_db_v1'); localStorage.removeItem('wb_ui_state'); } catch (e) { /* 忽略 */ }

  /* UI 状态持久化：刷新后记住所在页面与选定的筛选（视图/分类/标签/类型） */
  /* UI 状态键按身份隔离：登录账号各用各的；本地模式按昵称文件隔离 */
  var UI_KEY = (function () {
    if (LOGIN_AUTHED) return 'wb_ui_state_' + (LOGIN_USER || 'default');
    var p = (window.WorkbenchDB && WorkbenchDB.getProfile) ? WorkbenchDB.getProfile() : null;
    return 'wb_ui_state_local_' + (p ? p.slug : 'guest');
  })();
  function loadUiState() {
    try {
      var raw = localStorage.getItem(UI_KEY);
      if (!raw) return;
      var u = JSON.parse(raw);
      if (u && VIEWS[u.view] && (u.view !== 'users' || isMaxUser())) state.view = u.view;
      if (u.todoCat !== undefined) state.todoCat = String(u.todoCat);
      if (['all', 'open', 'done'].indexOf(u.todoFilter) !== -1) state.todoFilter = u.todoFilter;
      if (Array.isArray(u.memoTags)) state.memoTags = u.memoTags.map(String);
      if (typeof u.dateFilter === 'string' && u.dateFilter) state.dateFilter = u.dateFilter;
    } catch (e) { /* 忽略损坏数据 */ }
  }
  function saveUiState() {
    try {
      localStorage.setItem(UI_KEY, JSON.stringify({
        view: state.view, todoCat: state.todoCat, todoFilter: state.todoFilter,
        memoTags: state.memoTags, dateFilter: state.dateFilter
      }));
    } catch (e) { /* 存储满/隐私模式：静默 */ }
  }

  var VIEWS = {
    overview: { title: '概览', sub: '今日待办 · 习惯打卡 · 临近纪念 · 一周趋势' },
    todo: { title: '待办事项', sub: '计划任务 · 优先级 · 截止时间' },
    memo: { title: '备忘录', sub: '随手记下的想法与笔记' },
    date: { title: '纪念日', sub: '生日 · 自定义类型 · 自动倒计时' },
    habit: { title: '习惯打卡', sub: '每日坚持 · 连续记录与热力图' },
    diary: { title: '一日三问', sub: '记录成长与心情' },
    users: { title: '用户管理', sub: '账号与角色标识 · 仅 Max 可管理' }
  };

  /* ============================================================
     主题
     ============================================================ */
  function resolveTheme(pref) {
    if (pref === 'dark' || pref === 'light') return pref;
    return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  }

  function currentThemePref() {
    try {
      var t = localStorage.getItem('workbench_theme');
      if (t === 'dark' || t === 'light' || t === 'auto') return t;
    } catch (e) { /* 隐私模式 */ }
    return 'auto';
  }

  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }

  function applyTheme(pref) {
    var eff = resolveTheme(pref);
    document.documentElement.setAttribute('data-theme', eff);
    var meta = $('#metaThemeColor');
    if (meta) meta.setAttribute('content', eff === 'dark' ? '#101114' : '#F7F8FA');
    try { localStorage.setItem('workbench_theme', pref); } catch (e) { /* 忽略 */ }
  }

  /* ============================================================
     Toast
     ============================================================ */
  function toast(msg, type) {
    var wrap = $('#toastContainer');
    /* 栈控：最多同屏 2 条，新的永远在最下 */
    while (wrap.children.length >= 2) wrap.removeChild(wrap.firstChild);
    var el = document.createElement('div');
    el.className = 'toast' + (type === 'error' ? ' toast-error' : type === 'warn' ? ' toast-warn' : '');
    el.innerHTML = '<span class="toast-dot"></span>' + esc(msg);
    wrap.appendChild(el);
    var dismissed = false;
    function dismiss() {
      if (dismissed) return;
      dismissed = true;
      clearTimeout(timer);
      el.classList.add('toast-out');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 240);
    }
    var timer = setTimeout(dismiss, 2400);
    /* 点按立即关闭：看到了就不用等自动消失 */
    el.addEventListener('pointerdown', dismiss);
  }

  /* ============================================================
     自定义下拉（接管原生 select 的视觉与交互）
     ------------------------------------------------------------
     原生 select 展开后的列表由操作系统绘制，圆角 / 阴影 / 滚动条 /
     高亮色均无法用 CSS 覆盖（Safari 甚至忽略 option 样式）。
     此处保留原生 select 承载数据与 change 事件（农历联动等既有逻辑
     不受影响），仅用按钮 + 浮层接管视觉与交互。
     ============================================================ */
  var selOpen = null;

  function enhanceSelects(root) {
    $all('select.form-input', root || document).forEach(function (sel) {
      if (sel.getAttribute('data-sel')) return;
      sel.setAttribute('data-sel', '1');

      var wrap = sel.parentNode;
      if (!wrap || wrap.className.indexOf('select-wrap') === -1) {
        wrap = document.createElement('div');
        wrap.className = 'select-wrap';
        sel.parentNode.insertBefore(wrap, sel);
        wrap.appendChild(sel);
      }

      /* 无障碍名称：优先关联 label，其次 aria-label */
      var lab = sel.id ? $('label[for="' + sel.id + '"]', document) : null;
      var name = (lab ? lab.textContent.replace(/\*/g, '').trim() : '') ||
                 sel.getAttribute('aria-label') || '';

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'sel-btn';
      btn.setAttribute('aria-haspopup', 'listbox');
      btn.setAttribute('aria-expanded', 'false');
      if (name) btn.setAttribute('aria-label', name);

      var panel = document.createElement('div');
      panel.className = 'sel-panel';
      panel.setAttribute('role', 'listbox');
      panel.tabIndex = -1;
      panel.hidden = true;

      sel.className += ' sel-native';
      sel.setAttribute('tabindex', '-1');
      sel.setAttribute('aria-hidden', 'true');

      wrap.appendChild(btn);
      wrap.appendChild(panel);

      var inst = { sel: sel, btn: btn, panel: panel, wrap: wrap, name: name };

      function sync() {
        var o = sel.options[sel.selectedIndex];
        btn.textContent = o ? o.textContent : (sel.value || '');
        btn.classList.toggle('is-placeholder', !!(o && o.value === ''));
      }

      function render() {
        panel.innerHTML = '';
        Array.prototype.forEach.call(sel.options, function (o, i) {
          var item = document.createElement('div');
          item.className = 'sel-opt' + (i === sel.selectedIndex ? ' is-active' : '');
          item.setAttribute('role', 'option');
          item.setAttribute('aria-selected', i === sel.selectedIndex ? 'true' : 'false');
          item.tabIndex = -1;
          item.textContent = o.textContent;
          panel.appendChild(item);
        });
        sync();
      }

      function close() {
        if (panel.hidden) return;
        panel.hidden = true;
        btn.setAttribute('aria-expanded', 'false');
        btn.classList.remove('is-open');
        if (selOpen === inst) selOpen = null;
      }
      inst.close = close;

      function pick(i) {
        sel.selectedIndex = i;
        /* 派发原生 change，保证农历联动等既有监听照常工作 */
        var ev;
        try { ev = new Event('change', { bubbles: true }); }
        catch (e) { ev = document.createEvent('HTMLEvents'); ev.initEvent('change', true, false); }
        sel.dispatchEvent(ev);
        close();
      }

      function open() {
        if (selOpen && selOpen !== inst) selOpen.close();
        render();
        panel.hidden = false;
        btn.setAttribute('aria-expanded', 'true');
        btn.classList.add('is-open');

        /* fixed 定位：按触发按钮的视口坐标计算，脱离弹窗 overflow 裁切 */
        var GAP = 4, MARGIN = 12, MAXH = 240;
        var r = btn.getBoundingClientRect();
        panel.style.width = r.width + 'px';
        panel.style.left = Math.round(
          Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - r.width - 8))
        ) + 'px';
        var contentH = Math.min(MAXH, panel.scrollHeight);
        var below = window.innerHeight - r.bottom - MARGIN;
        var above = r.top - MARGIN;
        var up = below < contentH && above > below;
        panel.classList.toggle('is-up', up);
        if (up) {
          panel.style.top = 'auto';
          panel.style.bottom = Math.round(window.innerHeight - r.top + GAP) + 'px';
          panel.style.maxHeight = Math.max(120, Math.min(MAXH, above)) + 'px';
        } else {
          panel.style.bottom = 'auto';
          panel.style.top = Math.round(r.bottom + GAP) + 'px';
          panel.style.maxHeight = Math.max(120, Math.min(MAXH, below)) + 'px';
        }

        var act = $('.sel-opt.is-active', panel);
        if (act) { act.scrollIntoView({ block: 'nearest' }); act.focus(); }
        else { panel.focus(); }
        selOpen = inst;
      }

      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        /* 移动端：与日期选择同款的选择卡片（底部抽屉），取代贴边浮层 */
        if (wbCoarse()) { openOptionPicker(inst); return; }
        if (panel.hidden) open(); else close();
      });

      panel.addEventListener('click', function (e) {
        var item = e.target.closest ? e.target.closest('.sel-opt') : null;
        if (!item) return;
        pick($all('.sel-opt', panel).indexOf(item));
      });

      panel.addEventListener('keydown', function (e) {
        var items = $all('.sel-opt', panel);
        var idx = items.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') { e.preventDefault(); if (items[idx + 1]) items[idx + 1].focus(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); if (items[idx - 1]) items[idx - 1].focus(); }
        else if (e.key === 'Home') { e.preventDefault(); if (items[0]) items[0].focus(); }
        else if (e.key === 'End') { e.preventDefault(); if (items[items.length - 1]) items[items.length - 1].focus(); }
        else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (idx >= 0) pick(idx); }
        else if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); }
        else if (e.key === 'Tab') { close(); }
      });

      /* 选项被动态重建（农历年 / 月 / 日）时自动同步 */
      if (window.MutationObserver) {
        new MutationObserver(render).observe(sel, { childList: true });
      }
      sel.addEventListener('change', sync);
      render();
    });
  }

  /* ============================================================
     自定义日历（接管原生 date picker 弹层）
     ------------------------------------------------------------
     原生日历弹层由浏览器绘制，无法匹配站点风格。此处保留原生
     input[type=date] 承载数据与 input/change 事件，弹出站点风格
     的月历浮层（fixed 定位、单例、挂在 body 上彻底脱离裁切）。
     ============================================================ */
  var dpOpen = null;    /* { inp, ico, y, m } */
  var dpPanel = null;   /* 单例浮层 */

  function dpParse(v) {
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(String(v || ''));
    return m ? { y: +m[1], m: +m[2] - 1, d: +m[3] } : null;
  }

  function dpEnsure() {
    if (dpPanel) return;
    dpPanel = document.createElement('div');
    dpPanel.className = 'dp-panel';
    dpPanel.setAttribute('role', 'dialog');
    dpPanel.setAttribute('aria-label', '选择日期');
    dpPanel.hidden = true;
    document.body.appendChild(dpPanel);

    dpPanel.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var tl = t.closest('.dp-tl');
      if (tl) { dpOpen.view = tl.getAttribute('data-view'); dpRender('in'); dpPlace(); return; }
      var yr = t.closest('.dp-year');
      if (yr) { dpOpen.y = +yr.getAttribute('data-y'); dpOpen.view = 'month'; dpRender('out'); dpPlace(); return; }
      var mo = t.closest('.dp-month');
      if (mo) { dpOpen.m = +mo.getAttribute('data-m'); dpOpen.view = 'day'; dpRender('out'); dpPlace(); return; }
      var nav = t.closest('.dp-nav');
      if (nav) { dpShift(+nav.getAttribute('data-nav')); return; }
      var day = t.closest('.dp-day');
      if (day) { dpPick(day.getAttribute('data-v')); return; }
      var q = t.closest('.dp-quick');
      if (q) dpPick(q.getAttribute('data-q') === 'today' ? todayStr() : '');
    });
    dpPanel.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        e.preventDefault(); dpShift(e.key === 'ArrowRight' ? 1 : -1);
      }
    });
  }

  /* 头部下拉箭头（线条风格，与全局图标一致） */
  var HABIT_CHECK = '<svg class="habit-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>';
  /* 打卡「减一次」小钮：与勾选图标同线条风格 */
  var HB_MINUS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 12h12"/></svg>';
  var DP_CARET = '<svg class="dp-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';

  function dpRender(anim) {
    if (!dpOpen || !dpPanel) return;
    var y = dpOpen.y, m = dpOpen.m, view = dpOpen.view || 'day';
    var sel = dpParse(dpOpen.inp.value);
    var t = new Date();
    var todayV = t.getFullYear() + '-' + pad(t.getMonth() + 1) + '-' + pad(t.getDate());
    var head = '', body = '';

    if (view === 'year') {
      /* 年份列表：对齐农历库范围（1900-2100），无库时退回当年 ±100/+10 */
      var yMin = (window.Lunar ? Lunar.MIN_YEAR : t.getFullYear() - 100);
      var yMax = (window.Lunar ? Lunar.MAX_YEAR : t.getFullYear() + 10);
      var ys = '', yy;
      for (yy = yMin; yy <= yMax; yy++) {
        ys += '<button type="button" class="dp-year' + (yy === y ? ' is-sel' : '') +
              '" data-y="' + yy + '">' + yy + '</button>';
      }
      head = '<span class="dp-title">选择年份</span>';
      body = '<div class="dp-years">' + ys + '</div>';
    } else if (view === 'month') {
      var ms = '', mi;
      for (mi = 0; mi < 12; mi++) {
        ms += '<button type="button" class="dp-month' + (mi === m ? ' is-sel' : '') +
              '" data-m="' + mi + '">' + (mi + 1) + ' 月</button>';
      }
      head =
        '<button type="button" class="dp-nav" data-nav="-12" aria-label="上一年">‹</button>' +
        '<button type="button" class="dp-tl dp-year-tl" data-view="year" aria-label="选择年份">' + y + ' 年' + DP_CARET + '</button>' +
        '<button type="button" class="dp-nav" data-nav="12" aria-label="下一年">›</button>';
      body = '<div class="dp-months">' + ms + '</div>';
    } else {
      var startDow = new Date(y, m, 1).getDay();          /* 0 = 周日 */
      var dim = new Date(y, m + 1, 0).getDate();
      var dimPrev = new Date(y, m, 0).getDate();
      var week = '日一二三四五六', i, cells = '';
      for (i = 0; i < week.length; i++) cells += '<span>' + week.charAt(i) + '</span>';
      var days = '';
      for (i = 0; i < 42; i++) {
        var d, mo = m, yy2 = y, cls = 'dp-day';
        if (i < startDow) { d = dimPrev - startDow + 1 + i; mo = m - 1; cls += ' is-out'; }
        else if (i >= startDow + dim) { d = i - startDow - dim + 1; mo = m + 1; cls += ' is-out'; }
        else d = i - startDow + 1;
        if (mo < 0) { mo = 11; yy2--; } else if (mo > 11) { mo = 0; yy2++; }
        var v = yy2 + '-' + pad(mo + 1) + '-' + pad(d);
        if (sel && sel.y === yy2 && sel.m === mo && sel.d === d) cls += ' is-sel';
        if (v === todayV) cls += ' is-today';
        days += '<button type="button" class="' + cls + '" data-v="' + v + '">' + d + '</button>';
      }
      /* 头部（Win11 式逐级下钻）：day「年 月 ▾」→ month「年 ▾」→ year 列表；
         右侧 ‹ › 仅切换上下月 */
      head =
        '<button type="button" class="dp-tl dp-ym" data-view="month" aria-label="选择月份">' +
          y + ' 年 ' + (m + 1) + ' 月' + DP_CARET +
        '</button>' +
        '<span class="dp-head-navs">' +
          '<button type="button" class="dp-nav" data-nav="-1" aria-label="上一月">‹</button>' +
          '<button type="button" class="dp-nav" data-nav="1" aria-label="下一月">›</button>' +
        '</span>';
      body = '<div class="dp-week">' + cells + '</div><div class="dp-grid">' + days + '</div>';
    }

    dpPanel.innerHTML =
      '<div class="dp-head">' + head + '</div>' + body +
      '<div class="dp-foot">' +
        '<button type="button" class="dp-quick" data-q="clear">清除</button>' +
        '<button type="button" class="dp-quick" data-q="today">今天</button>' +
      '</div>';

    if (view === 'year') {
      var selY = dpPanel.querySelector('.dp-year.is-sel');
      if (selY) selY.scrollIntoView({ block: 'center' });
    }

    /* 视图切换动画：下钻（日→月→年）从小到大放大入场，选中返回从大到小收拢 */
    if (anim && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      var bodyEl = dpPanel.querySelector('.dp-years, .dp-months, .dp-grid');
      if (bodyEl) {
        var cls = anim === 'in' ? 'dp-zoom-in' : 'dp-zoom-out';
        bodyEl.classList.remove('dp-zoom-in', 'dp-zoom-out');
        void bodyEl.offsetWidth; /* 重放动画 */
        bodyEl.classList.add(cls);
        bodyEl.addEventListener('animationend', function () {
          bodyEl.classList.remove('dp-zoom-in', 'dp-zoom-out');
        }, { once: true });
      }
    }
  }

  /* 日历导航：年、月两个维度各自独立——
     « »（±12）仅切换年份，月份保持不变；
     ‹ ›（±1）仅切换月份，在年内 1 ↔ 12 月循环，不带动年份 */
  function dpShift(n) {
    if (!dpOpen) return;
    if (n === 12 || n === -12) {
      var y = dpOpen.y + n / 12;
      /* 对齐农历库支持范围，超出后停在边界 */
      if (window.Lunar) {
        y = Math.min(Lunar.MAX_YEAR, Math.max(Lunar.MIN_YEAR, y));
      }
      dpOpen.y = y;
    } else {
      dpOpen.m += n;
      if (dpOpen.m < 0) dpOpen.m = 11;
      else if (dpOpen.m > 11) dpOpen.m = 0;
    }
    dpRender();
  }

  function dpPick(v) {
    if (!dpOpen) return;
    var inp = dpOpen.inp;
    inp.value = v;
    /* 派发 input + change，兼容农历换算等既有监听 */
    var ev;
    try { ev = new Event('input', { bubbles: true }); }
    catch (e) { ev = document.createEvent('HTMLEvents'); ev.initEvent('input', true, false); }
    inp.dispatchEvent(ev);
    try { ev = new Event('change', { bubbles: true }); }
    catch (e) { ev = document.createEvent('HTMLEvents'); ev.initEvent('change', true, false); }
    inp.dispatchEvent(ev);
    dpClose();
  }

  function dpPlace() {
    if (!dpOpen || !dpPanel) return;
    var r = dpOpen.disp.getBoundingClientRect();
    var w = Math.max(r.width, 264);
    dpPanel.style.width = w + 'px';
    dpPanel.style.left = Math.round(
      Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - w - 8))
    ) + 'px';
    var h = dpPanel.offsetHeight || 320;
    var below = window.innerHeight - r.bottom - 12;
    var above = r.top - 12;
    var up = below < h && above > below;
    dpPanel.classList.toggle('is-up', up);
    if (up) {
      dpPanel.style.top = 'auto';
      dpPanel.style.bottom = Math.round(window.innerHeight - r.top + 4) + 'px';
    } else {
      dpPanel.style.bottom = 'auto';
      dpPanel.style.top = Math.round(r.bottom + 4) + 'px';
    }
  }

  function dpClose() {
    if (!dpPanel || dpPanel.hidden) return;
    dpPanel.hidden = true;
    if (dpOpen && dpOpen.ico) dpOpen.ico.classList.remove('is-open');
    if (dpOpen && dpOpen.disp) dpOpen.disp.setAttribute('aria-expanded', 'false');
    dpOpen = null;
  }

  function dpOpenFor(inp, disp) {
    dpEnsure();
    var d = dpParse(inp.value) ||
            (function () { var t = new Date(); return { y: t.getFullYear(), m: t.getMonth() }; })();
    var ico = inp.parentNode ? inp.parentNode.querySelector('.date-ico') : null;
    if (dpOpen && dpOpen.ico) dpOpen.ico.classList.remove('is-open');
    dpOpen = { inp: inp, disp: disp, ico: ico, y: d.y, m: d.m, view: 'day' };
    dpRender();
    dpPanel.hidden = false;
    disp.setAttribute('aria-expanded', 'true');
    if (ico) ico.classList.add('is-open');
    dpPlace();
  }

  function enhanceDates(root) {
    $all('input[type="date"]', root || document).forEach(function (inp) {
      if (inp.getAttribute('data-dp')) return;
      inp.setAttribute('data-dp', '1');

      var wrap = inp.parentNode;
      if (!wrap || wrap.className.indexOf('date-wrap') === -1) {
        wrap = document.createElement('div');
        wrap.className = 'date-wrap';
        inp.parentNode.insertBefore(wrap, inp);
        wrap.appendChild(inp);
      }

      var lab = inp.id ? $('label[for="' + inp.id + '"]', document) : null;
      var name = (lab ? lab.textContent.replace(/\*/g, '').trim() : '') ||
                 inp.getAttribute('aria-label') || '';

      /* 原生 input 隐藏：仅承载数据与 input/change 事件。
         移动端点按日期框会直接唤起系统日历（浏览器内置行为，事件无法拦截），
         故可见层换成 .dp-display 按钮，系统选择器彻底不再出现 */
      inp.className += ' dp-native';
      inp.setAttribute('tabindex', '-1');
      inp.setAttribute('aria-hidden', 'true');

      /* 展示层：站点风格按钮，显示当前值（含星期），点击打开日历 */
      var disp = document.createElement('button');
      disp.type = 'button';
      disp.className = 'dp-display';
      disp.setAttribute('aria-haspopup', 'dialog');
      disp.setAttribute('aria-expanded', 'false');
      if (name) disp.setAttribute('aria-label', name);
      wrap.insertBefore(disp, inp.nextSibling);

      var ico = document.createElement('button');
      ico.type = 'button';
      ico.className = 'date-ico';
      ico.setAttribute('aria-label', '打开日历');
      ico.setAttribute('tabindex', '-1');
      ico.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>';
      wrap.appendChild(ico);

      function sync() {
        var v = inp.value;
        if (v) {
          disp.textContent = v + (weekdayCN(v) ? ' ' + weekdayCN(v) : '');
          disp.classList.remove('is-placeholder');
        } else {
          disp.textContent = '请选择日期';
          disp.classList.add('is-placeholder');
        }
      }

      function toggle(e) {
        e.stopPropagation();
        if (dpOpen && dpOpen.inp === inp) { dpClose(); return; }
        if (dpOpen) dpClose();
        if (wbCoarse()) {
          /* 移动端：iOS 式滚轮日期选择器（公历/农历） */
          openWheelPicker(inp.value, function (s) {
            inp.value = s; /* value 拦截自动同步展示层 */
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            inp.dispatchEvent(new Event('change', { bubbles: true }));
          });
          return;
        }
        dpOpenFor(inp, disp);
      }
      disp.addEventListener('click', toggle);
      ico.addEventListener('click', toggle);
      inp.addEventListener('change', sync);

      /* 程序化赋值（如农历换算 solarInput.value = s）不触发任何事件，
         拦截 value 写入：同步展示层，并刷新打开中的日历视图 */
      try {
        var vDesc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
        if (vDesc && vDesc.set) {
          Object.defineProperty(inp, 'value', {
            configurable: true,
            get: function () { return vDesc.get.call(this); },
            set: function (v) {
              vDesc.set.call(this, v);
              sync();
              if (dpOpen && dpOpen.inp === inp) {
                var d2 = dpParse(inp.value);
                if (d2) { dpOpen.y = d2.y; dpOpen.m = d2.m; dpRender(); dpPlace(); }
              }
            }
          });
        }
      } catch (e) { /* 极端环境降级为事件驱动同步 */ }

      sync();
    });
  }

  /* ============================================================
     移动端表单统一化：把桌面表单自动重排为 iOS 分组卡
     （配合 .fg-card CSS；桌面端不调用即零影响）
     ============================================================ */
  function clickFormPrimary() {
    var b = Modal.card ? $('[data-primary]', Modal.card) : null;
    if (b) b.click(); /* 底栏被 mobFormify 隐藏但按钮仍在：头部对勾代触发 */
  }
  function mobFormify() {
    if (!wbCoarse()) return;
    var card = Modal.card;
    card.classList.add('wbf-modal');
    var body = $('#modalBody', card);
    if (!body) return;

    /* ① 桌面端两列网格在手机上拆成逐行：外层 .field 只是 .field-row 的容器，
       拆掉它让每格各自成行（分组标记 data-fg 随之带到每一格） */
    $all('.field-row', body).forEach(function (row) {
      var host = row.parentNode.classList.contains('field') ? row.parentNode : row;
      var fg = host.getAttribute('data-fg') || row.getAttribute('data-fg') || null;
      /* children 是活集合：一边搬家一边迭代会隔一个漏一个，必须先取快照 */
      Array.prototype.slice.call(row.children).forEach(function (ch) {
        if (!ch.classList.contains('field')) ch.classList.add('field');
        if (fg) ch.setAttribute('data-fg', fg);
        host.parentNode.insertBefore(ch, host);
      });
      host.parentNode.removeChild(host);
    });

    /* ② 相邻同 data-fg 的字段并成一张分组卡；无标记统一归到空串组 = 旧版「全部一张卡」。
       事件页在 HTML 里直接写了 .fg-card，body 顶层没有 .field，本步自然跳过。 */
    var fields = Array.prototype.filter.call(body.children, function (n) {
      return n.classList && (n.classList.contains('field') || n.classList.contains('check-line'));
    });
    var cur = null, curKey;
    fields.forEach(function (f) {
      var k = f.getAttribute('data-fg');
      k = (k === null || k === undefined) ? '' : k;
      if (!cur || curKey !== k) {
        cur = document.createElement('div');
        cur.className = 'fg-card';
        body.insertBefore(cur, f);
        curKey = k;
      }
      cur.appendChild(f);
      /* ③ 归类：HTML 里已写明行式/堆叠/开关的听其自便，其余按内容自动判。
         带 .field-hint 的单值控件仍是行式（提示语换到第二行），不再降级成堆叠 */
      if (f.classList.contains('fg-row') || f.classList.contains('fg-stack') || f.classList.contains('fg-switch')) return;
      if (f.classList.contains('check-line') || f.querySelector('.switch-row')) f.classList.add('fg-switch');
      else if (f.querySelector('textarea, .sub-editor, .field-row-3, .md-field-head, .cat-palette, .mood-row')) f.classList.add('fg-stack');
      else f.classList.add('fg-row');
    });
    /* 开关统一化：check-line 复选框 → 左标题右开关（与 switch-row 同款，
       原 input 节点搬家，id/checked 读写零改动） */
    $all('.check-line', body).forEach(function (cl) {
      var inp = cl.querySelector('input[type="checkbox"]');
      if (!inp || cl.getAttribute('data-sw')) return;
      cl.setAttribute('data-sw', '1');
      var txt = '';
      var span = cl.querySelector('span');
      if (span) txt = span.textContent;
      else if (inp.nextSibling) txt = (inp.nextSibling.textContent || '').trim();
      cl.classList.add('switch-row');
      cl.innerHTML =
        '<span class="switch-text"><span class="switch-label">' + esc(txt) + '</span></span>' +
        '<span class="status-switch"><span class="switch-slider"></span></span>';
      cl.querySelector('.status-switch').insertBefore(inp, cl.querySelector('.switch-slider'));
    });
    var foot = $('.modal-foot', card);
    if (foot) {
      var delBtn = $('.modal-foot-left .btn-danger', foot);
      if (delBtn) {
        var wrap = document.createElement('div');
        wrap.className = 'dd-foot-inline';
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'dd-del-text';
        btn.textContent = '删除';
        btn.addEventListener('click', function () { delBtn.click(); });
        wrap.appendChild(btn);
        body.appendChild(wrap);
      }
      foot.style.display = 'none';
    }
  }

  /* 详情弹窗（移动端）：底栏「编辑」搬进内容成为通栏胶囊、删除降为红字行 */
  function mobDetailify() {
    if (!wbCoarse()) return;
    var card = Modal.card;
    var body = $('#modalBody', card);
    var foot = $('.modal-foot', card);
    if (!body || !foot) return;
    var primary = $('[data-primary]', foot);
    var del = $('.modal-foot-left .btn-danger', foot);
    if (!primary && !del) return;
    var wrap = document.createElement('div');
    wrap.className = 'dd-foot-inline';
    if (primary) wrap.appendChild(primary); /* 原按钮直接搬家：点击逻辑零改动 */
    if (del) wrap.appendChild(del);
    body.appendChild(wrap);
    foot.style.display = 'none';
  }

  /* ============================================================
     滚轮日期选择器（移动端 · iOS 原生滚轮式）
     触屏/窄屏下取代日历面板：公历/农历三列滚轮，拖动带惯性投射、
     松手弹性吸附；农历含闰月；确定后写回隐藏的 input[type=date]。
     ============================================================ */
  function wbCoarse() {
    return window.innerWidth <= 768 ||
      (window.matchMedia && window.matchMedia('(hover: none) and (pointer: coarse)').matches);
  }

  function openWheelPicker(solarStr, onOk) {
    var H = 44, HALF = 2; /* 可视 5 行，中心上下各 2 行 */
    var now = new Date();
    var yMin = (window.Lunar && Lunar.MIN_YEAR) || 1901;
    var yMax = Math.min((window.Lunar && Lunar.MAX_YEAR) || 2099, now.getFullYear() + 10);
    var years = [];
    for (var yy = yMin; yy <= yMax; yy++) years.push(yy);
    function clamp(v, a, b) { return Math.min(Math.max(v, a), b); }
    function solarDays(y, m) { return new Date(y, m, 0).getDate(); }

    var init = /^\d{4}-\d{2}-\d{2}$/.test(solarStr || '') ? solarStr : todayStr();
    var ip = init.split('-').map(Number);
    var mode = 's';
    var sy = clamp(ip[0], yMin, yMax), sm = ip[1], sd = ip[2];
    var ly = sy, lmi = 0, ld = 1, lMonths = [];

    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet" role="dialog" aria-modal="true" aria-label="选择日期">' +
        '<div class="wp-title">选择日期</div>' +
        '<div class="wp-seg">' +
          '<button type="button" class="wp-seg-btn is-on" data-m="s">公历</button>' +
          '<button type="button" class="wp-seg-btn" data-m="l">农历</button>' +
        '</div>' +
        '<div class="wp-wheels">' +
          '<div class="wp-col" data-c="y"></div>' +
          '<div class="wp-col" data-c="m"></div>' +
          '<div class="wp-col" data-c="d"></div>' +
        '</div>' +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-cancel">关闭</button>' +
          '<button type="button" class="wp-btn wp-btn-ok">确定</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    var sheet = mask.firstChild;
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var wheelClosed = false;
    var wfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收日期滚轮 */

    function lunarMonthsOf(y) {
      if (!window.Lunar) return [];
      try { return Lunar.yearMonths(clamp(y, Lunar.MIN_YEAR, Lunar.MAX_YEAR)); }
      catch (e) { return []; }
    }
    function solarOfCurrent() { return sy + '-' + pad(sm) + '-' + pad(sd); }
    function lunarOfCurrent() {
      var e = lMonths[lmi];
      if (!e || !window.Lunar) return null;
      return Lunar.lunarToSolar(ly, e.m, Math.min(ld, e.days), e.leap);
    }

    /* ---- 单列滚轮 ---- */
    function makeWheel(col, items, idx, onSel) {
      var list = document.createElement('div');
      list.className = 'wp-list';
      col.innerHTML = '';
      col.appendChild(list);
      var cur = clamp(idx || 0, 0, Math.max(items.length - 1, 0));
      function paint(anim) {
        var buf = [];
        for (var i = 0; i < items.length; i++) {
          buf.push('<div class="wp-item' + (i === cur ? ' is-on' : '') + '">' + esc(items[i]) + '</div>');
        }
        list.innerHTML = buf.join('');
        list.style.transition = anim ? 'transform .3s cubic-bezier(.2,.85,.3,1)' : 'none';
        list.style.transform = 'translateY(' + (HALF * H - cur * H) + 'px)';
      }
      var drag = null;
      col.addEventListener('pointerdown', function (e) {
        if (drag) return;
        drag = { y0: e.clientY, lastY: e.clientY, v: 0, base: cur * H };
        try { col.setPointerCapture(e.pointerId); } catch (err) {}
        list.style.transition = 'none';
        e.preventDefault();
      });
      col.addEventListener('pointermove', function (e) {
        if (!drag) return;
        var off = drag.base - (e.clientY - drag.y0);
        var maxOff = (items.length - 1) * H;
        if (off < 0) off *= .3;                       /* 越界橡皮筋 */
        else if (off > maxOff) off = maxOff + (off - maxOff) * .3;
        drag.v = e.clientY - drag.lastY;
        drag.lastY = e.clientY;
        list.style.transform = 'translateY(' + (HALF * H - off) + 'px)';
      });
      function up(e) {
        if (!drag) return;
        var d = drag; drag = null;
        var off = d.base - (e.clientY - d.y0);
        var ni = clamp(Math.round((off - d.v * 5) / H), 0, items.length - 1); /* 惯性投射 */
        if (ni !== cur) { cur = ni; paint(true); onSel(cur); }
        else paint(true);
      }
      col.addEventListener('pointerup', up);
      col.addEventListener('pointercancel', up);
      paint(false);
      return {
        rebuild: function (items2, idx2) { items = items2; cur = clamp(idx2 || 0, 0, Math.max(items2.length - 1, 0)); paint(false); }
      };
    }

    var colY = sheet.querySelector('[data-c="y"]');
    var colM = sheet.querySelector('[data-c="m"]');
    var colD = sheet.querySelector('[data-c="d"]');
    var wY, wM, wD;

    function dayItemsSolar() {
      var n = [], d; for (d = 1; d <= solarDays(sy, sm); d++) n.push(d + '日'); return n;
    }
    function dayItemsLunar() {
      var e = lMonths[lmi]; if (!e) return [];
      var n = [], d; for (d = 1; d <= e.days; d++) n.push(Lunar.dayName(d)); return n;
    }
    function buildD() {
      if (mode === 's') { sd = clamp(sd, 1, solarDays(sy, sm)); wD.rebuild(dayItemsSolar(), sd - 1); }
      else {
        var e = lMonths[lmi];
        ld = clamp(ld, 1, e ? e.days : 30);
        wD.rebuild(dayItemsLunar(), ld - 1);
      }
    }
    function buildL() {
      lMonths = lunarMonthsOf(ly);
      lmi = clamp(lmi, 0, Math.max(lMonths.length - 1, 0));
      wM.rebuild(lMonths.map(function (x) { return Lunar.monthName(x.m, x.leap); }), lmi);
      buildD();
    }
    function build() {
      if (mode === 's') {
        sd = clamp(sd, 1, solarDays(sy, sm));
        wY = makeWheel(colY, years.map(String), years.indexOf(sy), function (i) { sy = years[i]; buildD(); });
        var mLabels = []; for (var m = 1; m <= 12; m++) mLabels.push(m + '月');
        wM = makeWheel(colM, mLabels, sm - 1, function (i) { sm = i + 1; buildD(); });
        wD = makeWheel(colD, dayItemsSolar(), sd - 1, function (i) { sd = i + 1; });
      } else {
        lMonths = lunarMonthsOf(ly);
        lmi = clamp(lmi, 0, Math.max(lMonths.length - 1, 0));
        var e0 = lMonths[lmi];
        ld = clamp(ld, 1, e0 ? e0.days : 30);
        wY = makeWheel(colY, years.map(String), clamp(years.indexOf(ly), 0, years.length - 1), function (i) { ly = years[i]; buildL(); });
        wM = makeWheel(colM, lMonths.map(function (x) { return Lunar.monthName(x.m, x.leap); }), lmi, function (i) { lmi = i; buildD(); });
        wD = makeWheel(colD, dayItemsLunar(), ld - 1, function (i) { ld = i + 1; });
      }
    }
    function syncSegUI() {
      $all('.wp-seg-btn', sheet).forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-m') === mode); });
    }

    $('.wp-seg [data-m="s"]', sheet).addEventListener('click', function () {
      if (mode === 's') return;
      var s = lunarOfCurrent();
      if (s) { var p = s.split('-').map(Number); sy = p[0]; sm = p[1]; sd = p[2]; }
      mode = 's'; syncSegUI(); build();
    });
    $('.wp-seg [data-m="l"]', sheet).addEventListener('click', function () {
      if (mode === 'l') return;
      if (window.Lunar) {
        var l = Lunar.solarToLunar(solarOfCurrent());
        if (l) {
          ly = clamp(l.y, yMin, yMax);
          lMonths = lunarMonthsOf(ly);
          for (var i = 0; i < lMonths.length; i++) {
            if (lMonths[i].m === l.m && !!lMonths[i].leap === !!l.leap) { lmi = i; break; }
          }
          ld = l.d;
        }
      }
      mode = 'l'; syncSegUI(); build();
    });

    function close() {
      if (wheelClosed) return;
      wheelClosed = true;
      if (wfr) WbBack.finish(wfr);
      mask.classList.remove('is-open');
      document.removeEventListener('keydown', onKey, true);
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 320);
    }
    function confirm() {
      var s = mode === 's' ? solarOfCurrent() : lunarOfCurrent();
      if (!s) { toast('农历日期超出换算范围', 'warn'); return; }
      close();
      onOk(s);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

    $('.wp-btn-cancel', sheet).addEventListener('click', close);
    $('.wp-btn-ok', sheet).addEventListener('click', confirm);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    mask.addEventListener('pointerdown', function (e) { if (e.target === mask) e.stopPropagation(); });
    document.addEventListener('keydown', onKey, true);

    build();
  }

  /* ============================================================
     移动端选项选择卡片（与滚轮日期选择器同款底部抽屉）
     灰色胶囊选项、选中黑底白字，关闭/确定收尾；
     确定后写回原生 select 并派发 change（联动逻辑照常触发）。
     ============================================================ */
  function openOptionPicker(inst) {
    var sel = inst.sel;
    var opts = Array.prototype.map.call(sel.options, function (o) { return o.textContent; });
    if (!opts.length) return;
    var pending = sel.selectedIndex >= 0 ? sel.selectedIndex : 0;
    var title = inst.name || '请选择';

    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    var rows = [];
    for (var i = 0; i < opts.length; i++) {
      rows.push('<button type="button" class="op-item' + (i === pending ? ' is-on' : '') +
                '" data-i="' + i + '">' + esc(opts[i]) + '</button>');
    }
    mask.innerHTML =
      '<div class="wp-sheet" role="dialog" aria-modal="true" aria-label="' + esc(title) + '">' +
        '<div class="wp-title">' + esc(title) + '</div>' +
        '<div class="op-list">' + rows.join('') + '</div>' +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-cancel">关闭</button>' +
          '<button type="button" class="wp-btn wp-btn-ok">确定</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    var sheet = mask.firstChild;
    requestAnimationFrame(function () { mask.classList.add('is-open'); });

    function paint() {
      $all('.op-item', sheet).forEach(function (b) {
        b.classList.toggle('is-on', parseInt(b.getAttribute('data-i'), 10) === pending);
      });
    }
    var opclosed = false;
    var bfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收这张选择卡 */
    function close() {
      if (opclosed) return;
      opclosed = true;
      if (bfr) WbBack.finish(bfr);
      mask.classList.remove('is-open');
      document.removeEventListener('keydown', onKey, true);
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 320);
    }
    function confirm() {
      close();
      if (sel.selectedIndex === pending) return;
      sel.selectedIndex = pending;
      /* 派发原生 change：分类/农历联动、脏标记等既有监听照常工作 */
      var ev;
      try { ev = new Event('change', { bubbles: true }); }
      catch (e) { ev = document.createEvent('HTMLEvents'); ev.initEvent('change', true, false); }
      sel.dispatchEvent(ev);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

    sheet.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.op-item') : null;
      if (!b) return;
      pending = parseInt(b.getAttribute('data-i'), 10);
      paint();
    });
    $('.wp-btn-cancel', sheet).addEventListener('click', close);
    $('.wp-btn-ok', sheet).addEventListener('click', confirm);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    mask.addEventListener('pointerdown', function (e) { if (e.target === mask) e.stopPropagation(); });
    document.addEventListener('keydown', onKey, true);

    var act = $('.op-item.is-on', sheet);
    if (act && act.scrollIntoView) act.scrollIntoView({ block: 'center' });
  }

  /* 点击外部 / Esc / 滚动 / 缩放：关闭已展开的下拉与日历（pointerdown 兼容触屏） */
  document.addEventListener('pointerdown', function (e) {
    if (selOpen && !selOpen.wrap.contains(e.target)) selOpen.close();
    if (dpOpen && dpPanel && !dpPanel.contains(e.target) &&
        !(dpOpen.inp.parentNode && dpOpen.inp.parentNode.contains(e.target))) dpClose();
  });
  /* iOS 软键盘弹起会遮住正在输入的行：窄屏聚焦时把目标滚到可视区中部 */
  document.addEventListener('focusin', function (e) {
    var t = e.target;
    if (!t || !t.matches || !t.matches('input:not([type=hidden]), textarea')) return;
    if (window.innerWidth > 768) return;
    setTimeout(function () {
      if (document.activeElement === t && t.scrollIntoView) {
        t.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }, 300);
  });
  /* Esc 优先关闭浮层（捕获阶段拦截，避免连带关闭整个弹窗） */
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (selOpen) {
      var s = selOpen; s.close(); s.btn.focus();
      e.preventDefault(); e.stopPropagation(); return;
    }
    if (dpOpen) {
      var i = dpOpen.inp; dpClose();
      e.preventDefault(); e.stopPropagation();
      if (i && i.focus) i.focus();
    }
  }, true);
  /* fixed 浮层在滚动 / 缩放后会与触发按钮错位，直接关闭（浮层自身滚动除外） */
  document.addEventListener('scroll', function (e) {
    if (!selOpen && !dpOpen) return;
    if (selOpen && selOpen.panel.contains(e.target)) return;
    if (dpOpen && dpPanel && dpPanel.contains(e.target)) return;
    if (selOpen) selOpen.close();
    if (dpOpen) dpClose();
  }, true);
  window.addEventListener('resize', function () {
    if (selOpen) selOpen.close();
    if (dpOpen) dpClose();
    updateTabIndicator(false);
  });

  /* ============================================================
     统一「返回栈」（浏览器 History 接管）
     ------------------------------------------------------------
     手机侧滑 / 浏览器返回 = history.back()。SPA 里没有路由时，
     它会把整个应用退回浏览器启动页。这里为「弹窗屏幕」与「整屏浮层
     （确认抽屉 / 选择卡片 / 小票查看器）」各压入一条同源历史记录，
     用单一 popstate 分发器按 LIFO 逐层消费：最上层是谁就消隐谁，
     从而「详情←列表←浏览器」各返回一层，而不会误关底层或跳出应用。

     frame 语义：
       onBack()  —— 该层被「用户返回」触发时执行的动作（关弹窗 / 收抽屉）。
                     执行时浏览器已回退一步，故不得再 history.back()。
       viaBrowser—— 标记本次消隐来自浏览器返回（finish 时只移栈不再 back）。
     ============================================================ */
  var WbBack = (function () {
    var frames = [];
    var internal = false;   /* 我们自己 history.back() 时吞掉随之而来的 popstate */
    var supported = !!(window.history && window.history.pushState);
    var seq = 0;
    var goDelta = 0, goScheduled = false;   /* 同拍内多次回退合并成一次 history.go */

    function flushBack() {
      goScheduled = false;
      var n = goDelta; goDelta = 0;
      if (!n) return;
      internal = true;
      try { history.go(-n); } catch (e) { internal = false; }
    }
    /* 合并排队回退 n 条：微任务末统一执行，规避同拍多次导航互相打架 */
    function queueBack(n) {
      goDelta += n;
      if (goScheduled) return;
      goScheduled = true;
      var p = window.Promise;
      if (p && p.resolve) p.resolve().then(flushBack);
      else setTimeout(flushBack, 0);
    }

    function onPop() {
      if (internal) { internal = false; return; }      /* 我们主动消费的那条记录 */
      if (!frames.length) return;                       /* 没有我们的层：放行（正常退出应用） */
      var fr = frames[frames.length - 1];
      fr.viaBrowser = true;
      if (fr.onBack) fr.onBack();
    }
    if (supported) window.addEventListener('popstate', onPop);

    /* 前进导航 / 浮层打开：压一条历史记录 + 入栈 */
    function enter(onBack, modal) {
      var fr = { id: ++seq, onBack: onBack, viaBrowser: false, closed: false, timer: null, modal: !!modal };
      frames.push(fr);
      try { history.pushState({ wb: fr.id }, ''); } catch (e) { /* 隐私模式等：静默降级，功能不受影响 */ }
      return fr;
    }

    /* 栈中最上方的「弹窗屏幕」层（返回父层时认领其既有记录用） */
    function topModal() {
      for (var i = frames.length - 1; i >= 0; i--) {
        if (frames[i].modal && !frames[i].closed) return frames[i];
      }
      return null;
    }

    /* 排空所有弹窗层（对象被删、整条链丢弃回列表）：一次 history.go(-n) 消费，
       避免同一拍内多次 back 让 internal 守卫与 popstate 竞态错乱。 */
    function drainModal() {
      var n = 0;
      for (var i = frames.length - 1; i >= 0; i--) {
        if (frames[i].modal) {
          frames[i].closed = true;
          if (frames[i].timer) { clearTimeout(frames[i].timer); frames[i].timer = null; }
          frames.splice(i, 1);
          n++;
        }
      }
      if (!n) return;
      queueBack(n);
    }

    /* 真正消费一条层记录：出栈；非浏览器返回时安静地 history.back() */
    function finish(fr) {
      if (!fr || fr.closed) return;
      fr.closed = true;
      if (fr.timer) { clearTimeout(fr.timer); fr.timer = null; }
      var i = frames.indexOf(fr);
      if (i >= 0) frames.splice(i, 1);
      if (fr.viaBrowser) return;                        /* 浏览器已回退，无需再 back */
      queueBack(1);
    }

    /* 常规（程序化）关闭：延后一拍再消费——期间若紧跟「前进开新层」（详情→编辑
       串链）会 cancelDrop 撤销，从而把父层记录留给子层的「返回」。
       若本层是被浏览器返回触发（viaBrowser）则直接消费，不排定时器。 */
    function dropSoon(fr) {
      if (!fr || fr.closed) return;
      if (fr.viaBrowser) { finish(fr); return; }
      fr.timer = setTimeout(function () { fr.timer = null; finish(fr); }, 0);
    }
    function cancelDrop(fr) { if (fr && fr.timer) { clearTimeout(fr.timer); fr.timer = null; } }

    /* 脏守卫拦截了关闭（弹窗仍开着）但浏览器已回退一步：补一条记录，
       让下一次返回仍能只退这一层，保持「一条记录一层」不变式。 */
    function rearm(fr) {
      if (!fr || fr.closed) return;
      fr.viaBrowser = false;
      if (frames.indexOf(fr) < 0) frames.push(fr);
      try { history.pushState({ wb: fr.id }, ''); } catch (e) { /* ignore */ }
    }

    return { supported: supported, enter: enter, finish: finish, topModal: topModal,
      drainModal: drainModal, dropSoon: dropSoon, cancelDrop: cancelDrop, rearm: rearm };
  })();

  /* ============================================================
     弹窗管理（聚焦圈定 / Esc 关闭 / Enter 提交）
     ============================================================ */
  var Modal = (function () {
    var mask = $('#modalMask'),
        card = $('#modalCard'),
        titleEl = $('#modalTitle'),
        bodyEl = $('#modalBody'),
        footEl = $('#modalFoot'),
        xBtn = $('#modalClose'),
        backBtn = $('#modalBack');

    var current = null;
    var lastFocus = null;
    var closeTimer = null;
    var dirtyFlag = false;  /* 表单脏标记：收到用户输入事件即置位 */
    var closeArmed = false; /* 脏数据双击确认：首次关闭提示，再次放行 */
    var lastCloseAt = 0;    /* 上一次弹窗完全关闭的时刻：用于识别「弹窗链切换」 */
    var lastCloseReturn = false; /* 上次关闭是否为「子弹窗返回父弹窗」（挂 afterClose） */
    var pendingReturn = null;    /* 延后一拍的「返回父弹窗」，被新弹窗接管时取消 */
    var returnReopenActive = false; /* scheduleReturn 正在重开父弹窗：本次 open 是「返回」不压栈 */
    var pendingDrop = null;         /* 上一次 close 延后消费的层记录，紧跟的前进 open 会撤销它 */

    /* 返回父弹窗延后一个宏任务执行：详情 / 编辑 → 删除确认这类串联里，
       close 之后紧跟着就是 confirm 的 open，若同步返回会让详情页先复活，
       确认删完关掉后又被这张迟到的详情页接住（用户看到「删完又回到详情页」）。
       触发前检查是否已有弹窗在场，有则放弃这次返回，直接回到列表 */
    function scheduleReturn(fn) {
      if (!fn) return;
      pendingReturn = fn;
      setTimeout(function () {
        if (pendingReturn !== fn) return;
        pendingReturn = null;
        if (current) return;
        returnReopenActive = true;    /* 这次 open 是「回到父层」，沿用其既有记录，不再压栈 */
        try { fn(); } finally { returnReopenActive = false; }
      }, 0);
    }

    /* 脏数据采集（捕获 input/change）：仅用户输入置位，程序化赋值（农历联动等）不触发 */
    function wbMarkDirty(e) {
      var t = e.target;
      if (!current || !current.dirtyGuard || !t) return;
      var n = t.tagName;
      if (n !== 'INPUT' && n !== 'TEXTAREA' && n !== 'SELECT') return;
      if (t.type === 'button' || t.type === 'submit') return;
      dirtyFlag = true;
    }
    bodyEl.addEventListener('input', wbMarkDirty, true);
    bodyEl.addEventListener('change', wbMarkDirty, true);

    /* 移动端「下拉到顶即关」：为声明 pullClose 的整屏抽屉（回收站 / 已归档）挂常驻
       touch 监听，按 current.pullClose 逐次判定，避免反复增删。规则与把手抽屉一致：
       内容已滚到顶 + 继续下拉才接管，过阈值即关（走正常 close 保返回栈/原位露出父层），
       否则回弹。桌面端不接管（保持居中对话框）。 */
    var mPull = null;
    function mSheetMobile() { return window.matchMedia && window.matchMedia('(max-width: 768px)').matches; }
    bodyEl.addEventListener('touchstart', function (e) {
      if (mPull || closeTimer) return;
      if (!current || !current.pullClose || current.persistent || !mSheetMobile()) return;
      if (bodyEl.scrollTop > 0) return; /* 内容还能上滚，交回原生滚动 */
      if (e.target && e.target.closest && e.target.closest('input,textarea,[contenteditable]')) return;
      var t = e.touches[0];
      mPull = { y0: t.clientY, dy: 0, on: false, t0: Date.now() };
    }, { passive: true });
    bodyEl.addEventListener('touchmove', function (e) {
      if (!mPull) return;
      var t = e.touches[0];
      mPull.dy = t.clientY - mPull.y0;
      if (!mPull.on) {
        if (mPull.dy > 6 && bodyEl.scrollTop <= 0) { mPull.on = true; card.style.transition = 'none'; }
        else { return; } /* 上滑滚动 / 轻抖 → 放行 */
      }
      e.preventDefault();
      bodyEl.scrollTop = 0;
      card.style.transform = 'translateY(' + Math.max(0, mPull.dy) + 'px)';
    }, { passive: false });
    function mPullEnd() {
      if (!mPull) return;
      var dy = mPull.dy, dt = Math.max(1, Date.now() - mPull.t0), on = mPull.on;
      mPull = null;
      if (!on) return;
      var vel = Math.abs(dy) / dt;
      if (dy > 96 || (dy > 40 && vel > 0.5)) {
        card.style.transition = ''; card.style.transform = ''; /* 先复位，避免残留 translateY 把父层顶出屏 */
        close();
      } else { /* 未过阈值：平滑回弹 */
        card.style.transition = 'transform .22s cubic-bezier(.16, 1, .3, 1)';
        card.style.transform = '';
        setTimeout(function () { if (!mPull) card.style.transition = ''; }, 240);
      }
    }
    bodyEl.addEventListener('touchend', mPullEnd);
    bodyEl.addEventListener('touchcancel', mPullEnd);

    /* 弹窗打开期间隔离背景（读屏/触摸不再触达页面内容），关闭时解除 */
    function setAppInert(on) {
      var el = document.querySelector('.app');
      if (el) { try { el.inert = !!on; } catch (e) { /* 老浏览器忽略 */ } }
    }

    function focusables() {
      return $all('button, input, select, textarea, a[href]', card).filter(function (el) {
        return !el.disabled && el.offsetParent !== null;
      });
    }

    function open(opts) {
      /* 移动端离场淡出进行中：新弹窗只登记目标，待旧内容淡出完毕再真正打开 */
      /* 关闭动画收尾中：排队等待——迟到的收尾回调会隐藏新弹窗，必须串行 */
      if (closeTimer) {
        setTimeout(function () { open(opts); }, 180);
        return;
      }
      /* 弹窗链切换判定：上一个弹窗仍在场，或距上次关闭不足 380ms
         （详情→编辑/删除确认走的是 close 后立刻 open 的串行链）。
         据此让新内容自顶部推入，与返回时的下移离场成对，方向可感知；
         「保存后回到详情」这类返回（关闭时挂 afterClose）不算推入 */
      var chained = ((!!current || (Date.now() - lastCloseAt < 380)) && !lastCloseReturn) || !!opts.chain; /* opts.chain：强制自上而下推入（待办详情统一入场方向，不随打开路径忽上忽下） */
      lastCloseAt = 0;
      lastCloseReturn = false;
      current = opts || {};
      lastFocus = document.activeElement;

      titleEl.textContent = current.title || '';
      /* 头部右侧胶囊操作（移动端编辑页「保存」）：无则收起 */
      var headEl2 = titleEl.parentNode;
      var ha = headEl2 ? headEl2.querySelector('.modal-head-act') : null;
      if (current.headAction && headEl2) {
        if (!ha) {
          ha = document.createElement('button');
          ha.type = 'button';
          ha.className = 'modal-head-act';
          ha.addEventListener('click', function () {
            if (closeTimer) return;
            if (current && current.headAction) current.headAction.onClick();
          });
          headEl2.appendChild(ha);
        }
        ha.style.display = '';
        if (current.headAction.icon) {
          ha.classList.add('is-icon');
          ha.setAttribute('aria-label', current.headAction.text || '保存');
          ha.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 13l4.4 4.4L19 7"/></svg>';
        } else {
          ha.classList.remove('is-icon');
          ha.removeAttribute('aria-label');
          ha.textContent = current.headAction.text;
        }
      } else if (ha) {
        ha.style.display = 'none';
      }
      bodyEl.innerHTML = current.body || '';
      enhanceSelects(card); /* 表单内原生 select → 自定义下拉 */
      enhanceDates(card);   /* 表单内原生 date → 自定义日历 */
      xBtn.style.display = current.persistent ? 'none' : '';
      backBtn.style.display = current.persistent ? 'none' : '';
      footEl.innerHTML = '';
      var leftWrap = null;
      var rightWrap = document.createElement('div');
      rightWrap.className = 'modal-foot-group';
      (current.actions || []).forEach(function (a) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'btn ' + (a.className || 'btn-default');
        if ((a.text === '取消' && !a.keepCancel) || a.text === '关闭') b.setAttribute('data-cancel', '1'); /* 移动端隐藏取消/关闭；确认/提示类弹窗 keepCancel 豁免 */
        b.textContent = a.text;
        if (a.primary) b.setAttribute('data-primary', '1');
        b.addEventListener('click', function () {
          if (closeTimer) return; /* 关闭动画进行中：忽略重复点击 */
          if (a.onClick) a.onClick(); else close();
        });
        if (a.align === 'left') {
          if (!leftWrap) {
            leftWrap = document.createElement('div');
            leftWrap.className = 'modal-foot-group modal-foot-left';
          }
          leftWrap.appendChild(b);
        } else {
          rightWrap.appendChild(b);
        }
      });
      if (leftWrap) footEl.appendChild(leftWrap);
      if (rightWrap.children.length) footEl.appendChild(rightWrap);
      footEl.style.display = (leftWrap || rightWrap.children.length) ? '' : 'none'; /* 无操作按钮：整条底栏收起 */

      mask.hidden = false;
      card.classList.remove('closing');
      card.classList.remove('dc-card', 'rm-modal', 'dd-modal', 'cf-modal', 'diary-form', 'wbf-modal', 'hm-modal'); /* 清理上一个弹窗的修饰类（个人中心宽度 / 小票机定高与台面内衬 / 事件详情灰底 / 确认弹窗外壳 / 回顾编辑灰底 / mobFormify 的表单灰底 / 习惯详情热力加宽），防止泄漏到下一个弹窗；表单页随后会自己重新挂上 wbf-modal */
      /* 修饰类必须在 open 内部补挂：close→open 串行时 open 会被 closeTimer 延后 180ms，
         若在调用点外部同步 add，这个类会先落到「正在离场」的旧弹窗卡片上——
         旧页面因此吃到新弹窗的入场动画（看着像又弹回来一次），随后真正的 open
         又会把它清掉，新弹窗反而丢了外壳样式 */
      if (current.cls) String(current.cls).split(' ').forEach(function (c) { if (c) card.classList.add(c); });
      /* 重播进入动画：遮罩常驻时 display 不变化，需显式重启元素级 animation */
      card.classList.remove('cascade');
      card.classList.add('cascade');
      card.classList.toggle('chain-in', chained); /* 链式切换：级联入场改为自上而下推入 */
      card.style.animation = 'none';
      void card.offsetWidth;
      card.style.animation = '';
      dirtyFlag = false;
      closeArmed = false;
      setAppInert(true);
      /* 滚动归零：新弹窗一律从顶部呈现（close 已清空内容，此处兜底） */
      bodyEl.scrollTop = 0;
      card.scrollTop = 0;

      /* 返回栈：为这一「屏幕」维护一条历史记录 */
      if (WbBack.supported) {
        if (returnReopenActive) {
          /* 回到父层：沿用父层既有记录（其记录从未被移除），把它认领给新 current */
          current._frame = WbBack.topModal();
        } else {
          /* 前进导航：撤销上一 close 的延后消费（详情→编辑串链须保留父层记录），再压新层 */
          if (pendingDrop) { WbBack.cancelDrop(pendingDrop); pendingDrop = null; }
          current._frame = WbBack.enter(browserBack, true);
        }
      }

      /* 自动聚焦第一个输入框（readonly / date / 按钮除外）。
         位于滚动视口外的输入框不参与——初始 focus 会把长弹窗内容
         顶到中部（如个人中心直接定位到偏好设置 / 密码区），
         此时回退到 footer 主按钮（固定可见、不引发滚动） */
      var cardRect = card.getBoundingClientRect();
      var first = $all('input, select, textarea', card).filter(function (el) {
        return !el.disabled && !el.readOnly && el.type !== 'date' &&
               el.type !== 'button' && el.type !== 'checkbox' && el.type !== 'radio' &&
               el.offsetParent !== null;
      }).filter(function (el) {
        var r = el.getBoundingClientRect();
        return r.top >= cardRect.top && r.bottom <= cardRect.bottom;
      })[0];
      setTimeout(function () {
        var el = first || footEl.querySelector('[data-primary]') || (backBtn && backBtn.offsetParent !== null ? backBtn : xBtn);
        el.focus();
        /* 有内容时把光标定位到文本末尾，便于继续编辑 */
        if (el && el.value && el.setSelectionRange) {
          try { el.setSelectionRange(el.value.length, el.value.length); } catch (e) { /* 部分输入类型不支持 */ }
        }
      }, 30);
    }

    function close(immediate, skipReturn) {
      immediate = immediate === true; /* 防御：事件监听器直传时 event 对象会被误当 immediate */
      skipReturn = skipReturn === true; /* 对象已消失（如抽屉里确认删除）：不要走「返回父弹窗」 */
      if (!current || closeTimer) return true; /* 已在关闭动画中则忽略（对返回栈而言已处理，勿再回补） */
      /* 脏数据守卫：表单有未保存更改时，首次关闭只提示（再次关闭放行） */
      if (!immediate && current.dirtyGuard && dirtyFlag && !closeArmed) {
        closeArmed = true;
        var fe = $('#formError', card);
        if (fe) { fe.textContent = '更改尚未保存——再次关闭将放弃更改'; fe.classList.add('show'); }
        shakeEl(card);
        return false;
      }
      closeArmed = false;
      if (current.beforeClose && current.beforeClose() === false) return false;
      var done = current; /* afterClose 用：current 在清理中被置空 */
      /* 返回栈：消费本层的历史记录 */
      if (WbBack.supported) {
        if (skipReturn) {
          /* 对象被删：整条弹窗链丢弃回列表——排空所有弹窗层，只回退一次 */
          if (pendingDrop) { WbBack.cancelDrop(pendingDrop); pendingDrop = null; }
          WbBack.drainModal();
        } else if (done.afterClose) {
          /* 返回父层：同步消费本（子）层，父层记录随即成为栈顶供重开认领 */
          WbBack.finish(done._frame);
        } else {
          /* 普通关闭 or 前进串链：延后一拍消费；紧随的前进 open 会撤销它（保留本层给子层返回） */
          pendingDrop = done._frame;
          WbBack.dropSoon(pendingDrop);
        }
        done._frame = null;
      }
      /* 子弹窗返回模式（挂 afterClose）：一律瞬切——跳过 170ms 收起动画，
         遮罩全程连续；取消 / X / Esc / 遮罩 / 完成 / 保存行为完全一致 */
      if (done.afterClose) immediate = true;
      /* immediate=true：立即关闭通道——跳过退出动画，瞬间清理遮罩/内容/焦点，
         随后打开的新弹窗只播放自己的进入动画（一次干净的浮现，零闪动） */
      if (immediate) {
        if (closeTimer) { clearTimeout(closeTimer); closeTimer = null; }
        current = null;
        lastCloseAt = Date.now();
        lastCloseReturn = !!done.afterClose;
        if (selOpen) selOpen.close();
        dpClose();
        /* 全端统一瞬切清理（同步链一帧内被 open 覆盖，无空白帧）；遮罩常驻不隐藏 */
        card.classList.remove('closing', 'form-enter', 'leaving', 'chain-in');
        bodyEl.innerHTML = '';
        footEl.innerHTML = '';
        setAppInert(false);
        if (skipReturn) { mask.hidden = true; } /* 没有紧随的 open：遮罩必须真正收起，否则空壳挡住页面 */
        else scheduleReturn(done.afterClose);
        return true;
      }
      card.classList.remove('form-enter');
      card.classList.add('closing');
      closeTimer = setTimeout(function () {
        closeTimer = null;
        mask.hidden = true;
        card.classList.remove('closing', 'chain-in');
        bodyEl.innerHTML = '';
        footEl.innerHTML = '';
        current = null;
        lastCloseAt = Date.now();
        lastCloseReturn = !!done.afterClose;
        if (selOpen) selOpen.close();
        dpClose();
        setAppInert(false);
        if (lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) { /* 忽略 */ } }
        if (!skipReturn) scheduleReturn(done.afterClose);
      }, 170);
      return true;
    }

    /* 浏览器/侧滑返回触发：关这一层。persistent 不允许被返回关闭（原地补记录）。
       脏守卫拦截时（close 返回 false）把浏览器已退的那一步补回来，保持「一记录一层」。 */
    function browserBack() {
      if (!current) return;
      if (current.persistent) { if (current._frame) WbBack.rearm(current._frame); return; }
      var fr = current._frame;
      if (close() === false && fr) WbBack.rearm(fr);
    }

    /* 键盘：Esc 关闭（persistent 除外）/ Tab 圈定 / Enter 触发主按钮 */
    document.addEventListener('keydown', function (e) {
      if (mask.hidden || !current) return;
      if (e.key === 'Escape' && !current.persistent) {
        e.preventDefault();
        close();
      } else if (e.key === 'Tab') {
        var fs = focusables();
        if (!fs.length) return;
        var first = fs[0], last = fs[fs.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      } else if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && !e.isComposing) {
        if (e.defaultPrevented) return; /* 该控件已自行处理回车（如子任务「回车=加下一条」），别抢着保存整张表单 */
        var btn = footEl.querySelector('[data-primary]');
        if (btn) { e.preventDefault(); btn.click(); }
      }
    });

    /* 点击遮罩关闭（persistent 除外） */
    mask.addEventListener('mousedown', function (e) {
      if (e.target === mask && current && !current.persistent) close();
    });
    xBtn.addEventListener('click', function () { close(); });
    backBtn.addEventListener('click', function () { close(); });

    return { open: open, close: close, markClean: function () { dirtyFlag = false; closeArmed = false; },
      markDirty: function () { if (current && current.dirtyGuard) dirtyFlag = true; },
      /* 取消尚未触发的「返回父弹窗」：对象已被删除时，不能让那张迟到的详情页复活 */
      cancelReturn: function () { pendingReturn = null; },
      get card() { return card; } };
  })();

  /* 二次确认弹窗 */
  /* ============================================================
     确认类弹窗统一外壳（删除 / 重置 / 退出 / 容量 / 数据异常）
     ------------------------------------------------------------
     线性描边图标圆底 + 对象名 + 说明，底栏在手机上转成通栏胶囊。
     图标沿用站点既有笔画（1.8 / round cap），danger 走淡红底 + 红图。
     ============================================================ */
  var CF_ICONS = {
    warn:   '<path d="M12 8.4v5.2M12 16.8h.01"/><circle cx="12" cy="12" r="9"/>',
    trash:  '<path d="M4.5 6.5h15M9.5 6.5V5a1.4 1.4 0 0 1 1.4-1.4h2.2A1.4 1.4 0 0 1 14.5 5v1.5M6.5 6.5l.8 13a1.6 1.6 0 0 0 1.6 1.5h6.2a1.6 1.6 0 0 0 1.6-1.5l.8-13"/><path d="M10.1 10.5v6.5M13.9 10.5v6.5"/>',
    reset:  '<path d="M3.6 12a8.4 8.4 0 1 0 2.6-6.1"/><path d="M3.6 4.6V10h5.4"/>',
    logout: '<path d="M15.2 17.4l4.4-4.4-4.4-4.4"/><path d="M19.6 13H9.2"/><path d="M12.4 4.6H6.6A2.6 2.6 0 0 0 4 7.2v9.6a2.6 2.6 0 0 0 2.6 2.6h5.8"/>'
  };
  function cfBody(o) {
    return '<div class="cf-body">' +
      '<div class="cf-mark' + (o.danger ? ' is-danger' : '') + '">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
          (CF_ICONS[o.icon] || CF_ICONS.warn) + '</svg>' +
      '</div>' +
      (o.headline ? '<div class="cf-headline">' + o.headline + '</div>' : '') +
      '<div class="cf-msg">' + o.message + '</div>' +
    '</div>';
  }
  /* 修饰类交给 Modal.open 在延后队列落地后再挂（见 open 内注释），
     这里只声明，不在外部直接操作 classList */
  function cfOpen(o) {
    o.cls = 'cf-modal';
    Modal.open(o);
  }

  /* 未显式指定图标时按标题语义推断，避免逐个调用点补参数 */
  function inferCfIcon(title) {
    var t = String(title || '');
    if (/退出/.test(t)) return 'logout';
    if (/重置|恢复/.test(t)) return 'reset';
    if (/删除|清空|移除/.test(t)) return 'trash';
    return 'warn';
  }
  /* 手机端确认抽屉：与滚轮日期选择器 / 选项卡片同一外壳、同一动效
     （.wp-mask 淡入 + .wp-sheet 自下而上 .32s var(--ease-enter)，底栏 .wp-foot 双胶囊）。
     它独立挂在 body 上、不占用 #modalCard，因此底下的详情 / 编辑弹窗不会被顶掉。 */
  function cfSheet(opts) {
    var label = opts.title || '操作确认';
    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet cf-sheet" role="dialog" aria-modal="true" aria-label="' + esc(label) + '">' +
        '<div class="wp-title">' + esc(label) + '</div>' +
        cfBody(opts) +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-cancel">' + esc(opts.cancelText || '取消') + '</button>' +
          '<button type="button" class="wp-btn wp-btn-ok' + (opts.danger ? ' wp-btn-danger' : '') + '">' + esc(opts.okText || '确认') + '</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    var sheet = mask.firstChild;
    requestAnimationFrame(function () { mask.classList.add('is-open'); });

    var closed = false;
    var bfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收这张抽屉 */
    function close() {
      if (closed) return;
      closed = true;
      if (bfr) WbBack.finish(bfr);
      mask.classList.remove('is-open');
      document.removeEventListener('keydown', onKey, true);
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 320);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

    $('.wp-btn-cancel', sheet).addEventListener('click', close);
    $('.wp-btn-ok', sheet).addEventListener('click', function () {
      if (closed) return;
      if (opts.onOk && opts.onOk() === false) return; /* 校验失败：抽屉留在原地 */
      close();
      /* 对象已不存在：收起底下的详情 / 编辑弹窗。
         必须走常规关闭（瞬切通道是给「紧接着 open」设计的，会把遮罩留在原地），
         并先清脏标记，否则表单的未保存守卫会拦下这次关闭 */
      if (opts.closeUnderlying) {
        Modal.cancelReturn();
        Modal.markClean();
        Modal.close(false, true);
      }
    });
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    mask.addEventListener('pointerdown', function (e) { if (e.target === mask) e.stopPropagation(); });
    document.addEventListener('keydown', onKey, true);
  }

  function confirmModal(opts) {
    opts.icon = opts.icon || inferCfIcon(opts.title);
    /* 触屏走独立抽屉；桌面只有一张卡片、无法叠层，仍先收起当前弹窗再弹确认 */
    if (wbCoarse() && !opts.persistent) { cfSheet(opts); return; }
    if (opts.closeUnderlying) Modal.close(true);
    cfOpen({
      title: opts.title || '操作确认',
      persistent: !!opts.persistent,
      body: cfBody(opts),
      actions: [
        { text: opts.cancelText || '取消', className: 'btn-default', keepCancel: true },
        {
          text: opts.okText || '确认',
          className: opts.danger ? 'btn-danger' : 'btn-primary',
          primary: true,
          onClick: function () {
            var stop = opts.onOk && opts.onOk() === false;
            if (!stop) Modal.close();
          }
        }
      ]
    });
  }

  /* 水平抖动（WAAPI）：刻意不通过切换 .shake 类来改 animation 属性——
     类移除时 animation 会恢复为入场动画（wrFormIn / sheetUp）并重放一次。
     element.animate 独立于 CSS 动画列表，彻底避免入场重放 */
  var SHAKE_KEYFRAMES = [
    { transform: 'translateX(0)' },
    { transform: 'translateX(-4px)', offset: 0.25 },
    { transform: 'translateX(4px)', offset: 0.55 },
    { transform: 'translateX(-2px)', offset: 0.8 },
    { transform: 'translateX(0)' }
  ];

  function shakeEl(el) {
    if (!el || !el.animate) return; /* 老浏览器降级为仅显示错误文案 */
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    el.animate(SHAKE_KEYFRAMES, { duration: 350, easing: 'ease' });
  }

  /* 表单校验失败：错误文案 + 抖动；标记并聚焦出错字段 */
  function showFormError(msg, fieldId) {
    var err = $('#formError', Modal.card);
    if (err) { err.textContent = msg; err.classList.add('show'); }
    shakeEl(Modal.card);
    /* 清除上一次的出错标记，标记本次出错字段 */
    $all('[aria-invalid]', Modal.card).forEach(function (el) { el.removeAttribute('aria-invalid'); });
    var target = fieldId ? $('#' + fieldId, Modal.card) : null;
    if (target) target.setAttribute('aria-invalid', 'true');
    /* 聚焦出错字段（优先）；隐藏的原生 select/date 不参与，回退第一个可见输入框 */
    var first = $all('input, select, textarea', Modal.card).filter(function (el) {
      return !el.disabled && el.offsetParent !== null;
    })[0];
    var focusEl = (target && target.offsetParent !== null) ? target : first;
    if (focusEl) focusEl.focus();
  }

  /* 变更类异常统一处理 */
  function handleMutationError(e) {
    if (e instanceof Errors.QuotaError) { quotaModal(); return true; }
    toast(e && e.message ? e.message : '操作失败', 'error');
    return true;
  }

  /* 存储已满弹窗 */
  function quotaModal() {
    cfOpen({
      title: '本地存储空间已满',
      body: cfBody({
        danger: true, icon: 'warn',
        message: '空间已满，最近一次操作可能未保存。<br><br>请先<b>导出备份</b>，再清理缓存或删除无用数据后重试。'
      }),
      actions: [
        { text: '取消', className: 'btn-default', keepCancel: true },
        { text: '导出备份', className: 'btn-primary', primary: true, onClick: function () { Modal.close(); doExport(); } }
      ]
    });
  }

  /* 缓存损坏弹窗：导入备份 / 确认重置，不自动覆盖数据 */
  function corruptModal(msg) {
    cfOpen({
      title: '本地数据异常',
      persistent: true,
      body: cfBody({
        danger: true, icon: 'reset',
        message: esc(msg) + '<br><br>请选择「导入备份」恢复数据，或「确认重置」清空本机缓存（<b>不可撤销</b>）。'
      }),
      actions: [
        { text: '导入备份', className: 'btn-default', onClick: function () { $('#importFile').click(); } },
        {
          text: '确认重置', className: 'btn-danger', primary: true,
          onClick: function () {
            try { DB.reset(); } catch (e) { handleMutationError(e); return; }
            Modal.close();
            switchView('overview');
            toast('已重置为初始数据');
          }
        }
      ]
    });
  }

  /* ============================================================
     空状态
     ============================================================ */
  var SVG_BOX = '<svg class="empty-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="3" y="4" width="18" height="6" rx="1"/><path d="M3 10v9a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-9"/><path d="M9 15h6"/></svg>';
  var SVG_SEARCH = '<svg class="empty-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>';
  var SVG_PLUS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';

  /* 空状态：
     hasFilter=true  → 筛选无结果（清空筛选）
     hasFilter=false → 模块确实为空（主文案 sub + 引导按钮 quick） */
  function quickLabel(q) {
    return q === 'todo' ? '新增待办' : q === 'memo' ? '新建备忘' : q === 'date' ? '新增事件' : q === 'diary' ? '写今日回顾' : '新增习惯';
  }
  function emptyHtml(hasFilter, noun, sub, quick) {
    if (hasFilter) {
      return SVG_SEARCH + '未找到匹配的' + noun +
        '<button type="button" class="btn-link empty-clear" data-action="clear-filter">清空筛选条件</button>';
    }
    return '<div class="empty-main">' + SVG_BOX + '</div>' +
      '<div class="empty-text">' + sub + '</div>' +
      '<button type="button" class="btn btn-primary btn-sm" data-quick="' + esc(quick) + '">' +
        SVG_PLUS + '<span>' + quickLabel(quick) + '</span></button>';
  }

  /* ============================================================
     KPI 数字滚动（380ms 三次缓出，尊重 reduced-motion）
     ============================================================ */
  function animateCounters(root) {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    $all('[data-count]', root).forEach(function (el) {
      var target = parseInt(el.getAttribute('data-count'), 10) || 0;
      if (!target) { el.textContent = '0'; return; }
      var t0 = null, dur = 380;
      function tick(now) {
        if (t0 === null) t0 = now;
        var p = Math.min(1, (now - t0) / dur);
        el.textContent = String(Math.round(target * (1 - Math.pow(1 - p, 3))));
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  /* ============================================================
     视图切换
     ============================================================ */
  /* 移动端悬浮新增按钮（FAB）：按当前视图切换动作与可见性，桌面端由 CSS 隐藏 */
  var FAB_ACTIONS = {
    todo: function () { openTodoForm(null); },
    memo: function () { openMemoForm(null); },
    date: function () { openDateForm(null); },
    habit: function () { openHabitForm(null); },
    diary: function () { openDiaryForm(null); }
  };
  var FAB_LABELS = { todo: '新增待办', memo: '新建备忘', date: '新增事件', habit: '新增习惯', diary: '写今日回顾' };

  function updateFab() {
    var fab = $('#fabAdd');
    if (!fab) return;
    var fn = FAB_ACTIONS[state.view];
    fab.hidden = !fn;
    /* 同步导航栏的 has-add 状态：CSS 据此让 dock 在居中/左移之间滑动 */
    var bar = fab.closest('.tabbar');
    if (bar) bar.classList.toggle('has-add', !!fn);
    if (fn) fab.setAttribute('aria-label', FAB_LABELS[state.view]);
  }

  /* 选中指示器（半透明圆角胶囊 · 果冻动效）：
     外层负责位移（弹性曲线带过冲回弹），内芯负责形变（沿运动方向拉伸后回弹）。
     anim=false 用于首次定位与窗口尺寸变化，不做滑动动画 */
  function updateTabIndicator(anim) {
    var dock = $('.tabbar-dock');
    var ind = $('.tabbar-ind');
    if (!dock || !ind) return;
    var item = $('.menu-item.active', dock);
    if (!item) { ind.style.opacity = '0'; return; } /* 概览页：dock 无选中项，指示块收起 */
    ind.style.opacity = '1';
    var core = ind.firstElementChild;
    if (!core) {
      core = document.createElement('span');
      core.className = 'tabbar-ind-core';
      ind.appendChild(core);
    }
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var w = item.offsetWidth + 'px';
    var x = item.offsetLeft + 'px';
    var prevX = parseFloat(ind.dataset.x || '');
    ind.dataset.x = x;
    if (!anim || !ind.style.width || reduced) {
      /* 首次定位/系统减弱动效：瞬时就位 */
      ind.style.transition = 'none';
      ind.style.width = w;
      ind.style.transform = 'translateX(' + x + ')';
      void ind.offsetWidth;
      ind.style.transition = '';
      return;
    }
    ind.style.width = w;
    ind.style.transform = 'translateX(' + x + ')';
    /* 内芯形变：幅度按跨越的 tab 数计（1 格轻抿，5 格明显拉长），过冲后挤压回正 */
    var steps = (isFinite(prevX) && prevX !== parseFloat(x))
      ? Math.min(5, Math.max(1, Math.abs(parseFloat(x) - prevX) / Math.max(item.offsetWidth, 1)))
      : 1;
    var amp = 0.14 + steps * 0.05;                    /* 峰值拉伸 0.19 ~ 0.39 */
    /* 形变原点：按目标 tab 距哪侧 dock 边缘更近来锚定，保证拉伸只朝内侧、不弹出边界 */
    var siblings = $all('.menu-item', dock);
    var lastIdx = siblings.length - 1;
    var idx = siblings.indexOf(item);
    var origin;
    if (idx <= 0) origin = 'left center';            /* 首个：向右（内）拉伸 */
    else if (idx >= lastIdx) origin = 'right center';/* 末个：向左（内）拉伸 */
    else origin = (parseFloat(x) >= prevX) ? 'left center' : 'right center'; /* 中间：背离前进方向 */
    core.style.transformOrigin = origin;
    if (core.animate) {
      core.animate([
        { transform: 'scaleX(1)',               easing: 'cubic-bezier(.3,.72,.3,1)' },
        { transform: 'scaleX(' + (1 + amp) + ')', offset: .34, easing: 'cubic-bezier(.25,.8,.35,1)' },
        { transform: 'scaleX(' + (1 - amp * .38) + ')', offset: .7 },
        { transform: 'scaleX(1)',               offset: 1 }
      ], { duration: 460, fill: 'none' });
    }
  }

  /* 再次点击「已选中」的 tab：指示块原地果冻弹跳（不切视图，纯反馈）
     中间项左右均匀弹跳；首/末项只朝 dock 内侧挤压，避免胶囊越出圆角边界 */
  function wobbleTabIndicator() {
    var dock = $('.tabbar-dock');
    var ind = $('.tabbar-ind');
    if (!dock || !ind || !ind.firstElementChild) return;
    var item = $('.menu-item.active', dock);
    if (!item) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var core = ind.firstElementChild;
    if (!core.animate) return;
    var siblings = $all('.menu-item', dock);
    var idx = siblings.indexOf(item), lastIdx = siblings.length - 1;
    var frames;
    if (idx <= 0) {
      frames = [
        { transform: 'scaleX(1) translateX(0)' },
        { transform: 'scaleX(1.16) translateX(6%)', offset: .34, easing: 'cubic-bezier(.25,.8,.35,1)' },
        { transform: 'scaleX(.95) translateX(0)', offset: .7 },
        { transform: 'scaleX(1) translateX(0)', offset: 1 }
      ];
    } else if (idx >= lastIdx) {
      frames = [
        { transform: 'scaleX(1) translateX(0)' },
        { transform: 'scaleX(1.16) translateX(-6%)', offset: .34, easing: 'cubic-bezier(.25,.8,.35,1)' },
        { transform: 'scaleX(.95) translateX(0)', offset: .7 },
        { transform: 'scaleX(1) translateX(0)', offset: 1 }
      ];
    } else {
      /* 左右均匀：+7% → -7% → +3.5% → 归位，振幅逐次衰减（果冻回弹，不夸张） */
      frames = [
        { transform: 'scaleX(1) translateX(0)' },
        { transform: 'scaleX(1.1) translateX(7%)', offset: .2, easing: 'cubic-bezier(.3,.7,.3,1)' },
        { transform: 'scaleX(1.1) translateX(-7%)', offset: .48, easing: 'cubic-bezier(.3,.7,.3,1)' },
        { transform: 'scaleX(1.04) translateX(3.5%)', offset: .72, easing: 'cubic-bezier(.3,.7,.3,1)' },
        { transform: 'scaleX(1) translateX(0)', offset: 1 }
      ];
    }
    core.style.transformOrigin = 'center';
    core.animate(frames, { duration: idx <= 0 || idx >= lastIdx ? 420 : 520, fill: 'none' });
  }

  /* 列表级联入场：仅在视图切换（animate=true）时重放，筛选重渲染不打扰；reduced-motion 跳过 */
  function staggerList(el, on) {
    if (!el) return;
    el.classList.remove('list-cascade');
    if (on && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      void el.offsetWidth;
      el.classList.add('list-cascade');
    }
  }

  function switchView(name) {
    if (!VIEWS[name]) name = 'overview';
    state.view = name;

    $all('.menu-item[data-view]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-view') === name);
    });
    $all('.view').forEach(function (v) { v.hidden = v.id !== 'view-' + name; });

    $('#viewTitle').textContent = VIEWS[name].title;
    $('#viewSub').textContent = VIEWS[name].sub;
    document.title = name === 'overview' ? APP_NAME : VIEWS[name].title + ' · ' + APP_NAME;

    renderView(name, true);
    updateFab();
    updateTabIndicator(true);
  }

  function renderView(name, animate) {
    if (name === 'users') { renderUsers(); saveUiState(); return; }
    if (DB._data === null) return;
    if (name === 'todo') renderTodos(animate);
    else if (name === 'memo') renderMemos(animate);
    else if (name === 'date') renderDates(animate);
    else if (name === 'habit') renderHabits(animate);
    else if (name === 'diary') renderDiary(animate);
    else renderOverview(animate);
    renderCounts();
    saveUiState();
  }

  /* ============================================================
     用户管理：账号列表 + 角色标识（Max / Pro / Free）
     角色仅作标识不做数据权限隔离；管理操作仅 Max 可执行
     ============================================================ */
  var ROLE_LABEL = { ultra: 'Ultra', max: 'Max', pro: 'Pro', free: 'Free' };
  var SVG_ROLE_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="width:13px;height:13px"><path d="M5 13l4 4L19 7"/></svg>';

  function isMaxUser() {
    var r = window.LOGIN_ROLE || 'free'; return r === 'ultra' || r === 'max';
  }

  function roleBadgeHtml(role) {
    return '<span class="role-badge role-' + esc(role) + '">' + (ROLE_LABEL[role] || esc(role)) + '</span>';
  }

  function renderUsers() {
    var box = $('#usersRows');
    if (!box) return;
    if (!isMaxUser()) {
      box.innerHTML = '<div class="users-denied">仅 Max 账号可进入用户管理</div>';
      return;
    }
    box.innerHTML = '<div class="cat-row-empty">加载中…</div>';
    fetch('api/account.php?action=users&_ts=' + Date.now(), { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res || !res.ok) {
          box.innerHTML = '<div class="cat-row-empty">' + esc((res && res.error) || '加载失败') + '</div>';
          return;
        }
        box.innerHTML = res.users.map(function (u) {
          var name = u.username || '';
          var nick = u.nickname || '';
          var disp = nick || (name.charAt(0).toUpperCase() + name.slice(1));
          var av = safeAvatar(u.avatar);
          var me = name === (window.LOGIN_USER || '');
          var avatarInner = av ? '<img class="avatar-img" src="' + esc(av) + '" alt="">' : esc(name.slice(0, 1).toUpperCase());
          return '<div class="user-row">' +
            '<span class="user-row-avatar" aria-hidden="true">' + avatarInner + '</span>' +
            '<div class="user-row-info">' +
              '<div class="user-row-name">' + esc(disp) + (me ? '<span class="tag tag-me">当前</span>' : '') + roleBadgeHtml(u.role) + '</div>' +
              '<div class="user-row-sub">' + (nick ? '@' + esc(name) + ' · ' : '') + (u.created ? '添加于 ' + esc(u.created) : '') + (me ? ' · 当前登录账号' : '') + '</div>' +
            '</div>' +
            '<div class="dd user-role-dd" data-dd-user="' + esc(name) + '">' +
            '<button type="button" class="dd-toggle form-input" aria-haspopup="listbox" aria-expanded="false" title="调整角色">' +
              '<span>' + (ROLE_LABEL[u.role] || esc(u.role)) + '</span>' + DP_CARET +
            '</button>' +
            '<div class="dd-menu" hidden>' +
              ['ultra', 'max', 'pro', 'free'].map(function (rv) {
                return '<button type="button" class="dd-item' + (u.role === rv ? ' is-sel' : '') + '" data-dd-val="' + rv + '">' + ROLE_LABEL[rv] + (u.role === rv ? ' ' + SVG_ROLE_CHECK : '') + '</button>';
              }).join('') +
            '</div>' +
          '</div>' +
            (me ? '' : '<button type="button" class="cat-act cat-act-del" data-u-del="' + esc(name) + '" title="删除账号">' + SVG_TRASH + '</button>') +
          '</div>';
        }).join('') || '<div class="cat-row-empty">暂无账号</div>';
      })
      .catch(function () { box.innerHTML = '<div class="cat-row-empty">加载失败，请重试</div>'; });
  }

  function openAddUserForm() {
    if (!isMaxUser()) { toast('仅 Max 账号可管理用户', 'error'); return; }
    Modal.open({
      title: '添加账号',
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        '<div class="field">' +
          '<label for="nu-name">用户名<span class="req">*</span></label>' +
          '<input class="form-input" id="nu-name" type="text" maxlength="32" placeholder="2-32 位，中文 / 字母 / 数字 / _ . -" autocomplete="off">' +
        '</div>' +
        '<div class="field">' +
          '<label for="nu-nick">昵称</label>' +
          '<input class="form-input" id="nu-nick" type="text" maxlength="32" placeholder="选填，可与其他账号相同；留空则显示用户名" autocomplete="off">' +
        '</div>' +
        '<div class="field">' +
          '<label for="nu-pass">初始密码<span class="req">*</span></label>' +
          '<input class="form-input" id="nu-pass" type="password" maxlength="64" placeholder="至少 4 位">' +
        '</div>' +
        '<div class="field">' +
          '<label for="nu-role">角色标识</label>' +
          '<div class="select-wrap"><select class="form-input" id="nu-role">' +
            '<option value="ultra">Ultra（创始人）</option>' +
            '<option value="max">Max（管理）</option>' +
            '<option value="pro">Pro（会员）</option>' +
            '<option value="free">Free（普通）</option>' +
          '</select></div>' +
          '<div class="field-hint">角色仅作标识展示，不影响各账号的数据与功能使用；Ultra / Max 可进入「用户」页管理。</div>' +
        '</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        { text: '取消', className: 'btn-default' },
        {
          text: '添加账号', className: 'btn-primary', primary: true,
          onClick: function () {
            var card = Modal.card;
            var u = $('#nu-name', card).value.trim();
            var pw = $('#nu-pass', card).value;
            var role = $('#nu-role', card).value;
            var nick = $('#nu-nick', card).value.trim();
            if (!u) { showFormError('请填写用户名'); return; }
            if (!pw) { showFormError('请填写初始密码'); return; }
            fetch('api/account.php?action=add', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: pw, role: role, nickname: nick }) })
              .then(function (r) { return r.json(); })
              .then(function (res) {
                if (!res || !res.ok) { showFormError((res && res.error) || '添加失败'); return; }
                Modal.close();
                toast('账号「' + u + '」已添加');
                renderUsers();
              })
              .catch(function () { showFormError('网络异常，请重试'); });
          }
        }
      ]
    });
    mobFormify(); /* 移动端：字段转行式、收起旧底部栏（保存走头部 ✓ → clickFormPrimary） */
  }

  function renderAll() { switchView(state.view); }
  /* 抽屉背后的静默刷新：只重建当前视图与筛选条，不重播 list-cascade 入场动画（防闪帧） */
  function refreshBehind() {
    if (state.view === 'memo') renderMemos(false);
    else if (state.view === 'todo') renderTodos(false);
    else if (state.view === 'date') renderDates(false);
    else renderAll();
  }

  loadUiState();

  /* 侧边栏计数 */
  function setCnt(id, n, warn) {
    var els = $all('#' + id + ', [data-cnt-for="' + id + '"]');
    els.forEach(function (el) {
      el.textContent = String(n);
      el.hidden = n === 0;
      if (warn !== undefined) el.classList.toggle('warn', !!warn);
    });
    return els[0] || null;
  }

  function renderCounts() {
    var todos = DB.listTodos('all');
    var open = todos.filter(function (t) { return !t.done; }).length;
    setCnt('cntTodo', open);
    setCnt('cntMemo', DB._data.memo.length);
    var up = DB.upcoming(7).length;
    setCnt('cntDate', up, up > 0);
    /* 习惯：今日未打卡数（>0 显示警示色） */
    var today = todayStr();
    var undone = DB.listHabits().filter(function (h) { return !DB.isHabitDone(h.id, today); }).length;
    setCnt('cntHabit', undone, undone > 0);
  }

  /* ============================================================
     概览
     ============================================================ */
  /* 今日一言：本地词库按「年内天数」取模，同一天内稳定不变 */
  var QUOTES = [
    '今天也要元气满满呀',
    '把大目标拆成今天能完成的小事',
    '先完成，再完美',
    '专注当下，就是最好的效率',
    '早睡早起，给明天的自己留足精神',
    '别让「以后再说」变成永远不做',
    '一天之中，先吃掉最难的青蛙',
    '慢慢来，比较快',
    '记录下来的想法，才有机会生长',
    '完成比完美重要，开始比等待重要',
    '给自己一个微笑，再开始干活',
    '保持好奇，每天学一点点',
    '把手机放远一点，把目标放近一点',
    '今天的小进步，是明天的大底气',
    '做正确的事，而不是容易的事',
    '留 15 分钟给复盘，一天才算完整',
    '少即是多，专注一件事做好它',
    '生活是自己的，节奏也是自己的',
    '先动起来，答案在路上',
    '对自己温柔，对计划坚定',
    '重要的日子值得被记住',
    '一点一滴的坚持，终会连成星光',
    '今日事今日毕，明日自有明日喜',
    '把日子过成自己喜欢的样子'
  ];

  function ovQuoteHtml() {
    var now = new Date();
    var start = new Date(now.getFullYear(), 0, 1);
    var doy = Math.floor((now - start) / 86400000);
    var q = QUOTES[doy % QUOTES.length];
    return '<svg class="ov-quote-ico" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' +
      /* 原路径是「后引号」尾巴朝下的字形，水平镜像一次得到放在句首的前引号 */
      '<g transform="translate(24,0) scale(-1,1)">' +
      '<path d="M10 7H6a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v1a3 3 0 0 1-3 3v2a5 5 0 0 0 5-5V9a2 2 0 0 0-2-2zm10 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v1a3 3 0 0 1-3 3v2a5 5 0 0 0 5-5V9a2 2 0 0 0-2-2z"/></g></svg>' +
      '<span class="ov-quote-text">' + esc(q) + '</span>';
  }

  /* 快捷录入：单行横滑胶囊（概览不在 dock 里、也没有 FAB，五个模块都要一步直达） */
  function ovQuickHtml() {
    var items = [
      { q: 'todo', label: '待办', lead: true, ico: '<path d="M12 5v14M5 12h14"/>' },
      { q: 'memo', label: '备忘', ico: '<rect x="5" y="3.5" width="14" height="17" rx="2.4"/><path d="M9 8.5h6M9 12.2h6"/>' },
      { q: 'date', label: '事件', ico: '<path d="M12 21s-7.5-4.6-9.3-9A5.4 5.4 0 0 1 12 6.6 5.4 5.4 0 0 1 21.3 12c-1.8 4.4-9.3 9-9.3 9z"/>' },
      { q: 'habit', label: '习惯', ico: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/>' },
      { q: 'diary', label: '回顾', ico: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>' }
    ];
    return '<div class="ov-quick" id="ovQuick">' + items.map(function (it) {
      var lab = quickLabel(it.q);
      return '<button type="button" class="qbtn' + (it.lead ? ' qbtn-lead' : '') + '"' +
        ' data-quick="' + it.q + '" title="' + esc(lab) + '" aria-label="' + esc(lab) + '">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (it.lead ? 2 : 1.8) +
          '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + it.ico + '</svg>' +
        '<span>' + it.label + '</span></button>';
    }).join('') + '</div>';
  }

  /* 完成时刻 → 本地日期键 YYYY-MM-DD（跨时区归一到本地） */
  function isoToLocalDay(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  /* 按时段问候（23:30–05:00 都算「夜深了」，给熬夜的人一句实话） */
  function ovGreeting() {
    var now = new Date();
    var h = now.getHours() + now.getMinutes() / 60;
    if (h < 5 || h >= 23.5) return '夜深了';
    if (h < 9) return '早上好';
    if (h < 12) return '上午好';
    if (h < 14) return '中午好';
    if (h < 18) return '下午好';
    return '晚上好';
  }

  /* 日期行：9 月 17 日 · 周三 · 农历八月初七（农历库缺失或越界时自动省略） */
  function ovDateLine() {
    var t = todayStr();
    var s = esc(mdCN(t)) + ' · ' + esc(weekdayCN(t));
    if (window.Lunar && Lunar.solarToLunar) {
      try {
        var l = Lunar.solarToLunar(t);
        if (l) s += ' · 农历' + esc(Lunar.fullText(l));
      } catch (e) { /* 只留公历 */ }
    }
    return s;
  }

  /* 今日 hero：问候 → 今日完成进度 → 余量状态 → 一言 → 快捷录入 */
  function ovHeroHtml(m) {
    var pct = m.plan ? Math.round(m.doneToday / m.plan * 100) : 0;
    var pend = [];
    if (m.overdue) pend.push(m.overdue + ' 项已过期');
    if (m.todayOpen) pend.push(m.todayOpen + ' 项今天到期');
    if (m.habitUndo) pend.push(m.habitUndo + ' 个习惯没打卡');
    if (!m.diaryWritten) pend.push('一日三问还没写');
    var status = pend.length
      ? '<span class="ov-status is-todo"><i class="ov-status-dot" aria-hidden="true"></i>' + esc(pend.join(' · ')) + '</span>'
      : '<span class="ov-status is-clear"><i class="ov-status-dot" aria-hidden="true"></i>' +
          esc(m.plan || m.doneToday ? '今天的事都收下了' : '今天没有安排，随便记点什么') + '</span>';
    return '<div class="ov-day">' +
      '<div class="ov-day-head">' +
        '<h2 class="ov-hi">' + esc(ovGreeting()) + '，' + esc(displayUser() || '朋友') + '</h2>' +
        '<p class="ov-date">' + ovDateLine() + '</p>' +
      '</div>' +
      '<div class="ov-meter">' +
        '<div class="ov-meter-top">' +
          '<span class="ov-meter-l">今日完成' + (m.plan ? '<em>· ' + pct + '%</em>' : '') + '</span>' +
          '<span class="ov-meter-n"><b>' + m.doneToday + '</b> / ' + m.plan + '</span>' +
        '</div>' +
        '<span class="ov-meter-track" role="img" aria-label="今日完成 ' + m.doneToday + ' 项，计划 ' + m.plan + ' 项">' +
          '<span class="ov-meter-fill" style="width:' + pct + '%"></span></span>' +
        status +
      '</div>' +
      '<div class="ov-quote">' + ovQuoteHtml() + '</div>' +
      ovQuickHtml() +
    '</div>';
  }

  /* 时间线待办排序：优先级高在前，同级新在前；过期组再按到期日近在前 */
  var PRIO_RANK = { high: 3, normal: 2, low: 1 };
  function ovByPrio(a, b) {
    var d = (PRIO_RANK[b.priority] || 2) - (PRIO_RANK[a.priority] || 2);
    return d !== 0 ? d : String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
  }
  function ovByDue(a, b) {
    var d = String(a.due || '').localeCompare(String(b.due || ''));
    return d !== 0 ? d : ovByPrio(a, b);
  }

  /* 时间线骨架件：分组标题（灰字 + 计数 + 尾线）与单行（图标 / 主副文案 / 右侧动作） */
  function tlGroup(label, n, cls) {
    return '<div class="tl-group' + (cls ? ' ' + cls : '') + '">' +
      '<span class="tl-group-l">' + esc(label) + '</span>' +
      (n ? '<span class="tl-group-n">' + n + '</span>' : '') + '</div>';
  }
  function tlRow(o) {
    return '<div class="tl-item tl-' + o.kind + (o.cls ? ' ' + o.cls : '') + '"' +
      (o.goto && o.id
        ? ' data-tl-type="' + o.goto + '" data-tl-id="' + esc(o.id) + '" role="button" tabindex="0"' +
          ' aria-label="' + esc(o.plain || '') + '"'
        : '') + '>' +
      '<span class="tl-ico"' + (o.color ? ' style="color:' + esc(o.color) + '"' : '') + ' aria-hidden="true">' + o.ico + '</span>' +
      '<span class="tl-main">' +
        '<span class="tl-title">' + o.title + '</span>' +
        (o.meta ? '<span class="tl-meta">' + o.meta + '</span>' : '') +
      '</span>' +
      (o.act ? '<span class="tl-act">' + o.act + '</span>' : '') +
    '</div>';
  }
  /* 时间线尾部一行：把没进流的同类条目收成一句入口 */
  function tlMoreRow(text, gotoView) {
    return '<button type="button" class="tl-more" data-goto="' + esc(gotoView) + '">' +
      esc(text) + '<span class="tl-more-go">去看看 →</span></button>';
  }
  var SVG_TL_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5.5 12.5 4 4 9-9"/></svg>';

  /* 待办 → 时间线一行（行内完成 + 点行进详情） */
  function tlTodoRow(t, opts) {
    opts = opts || {};
    var cat = t.category ? DB.getCategory(t.category) : null;
    var rep = repeatLabel(t.repeat);
    var subs = t.subtasks || [];
    var subDone = subs.filter(function (s) { return s.done; }).length;
    var meta = [];
    if (cat) meta.push('<span class="cat-dot" style="background:' + esc(cat.color) + '"></span>' + esc(cat.name));
    if (opts.when) meta.push('<span class="tl-strong">' + esc(opts.when) + '</span>');
    if (rep) meta.push(esc(rep));
    if (subs.length) meta.push('子任务 ' + subDone + '/' + subs.length);
    if (t.desc) meta.push('<span class="tl-desc">' + esc(t.desc.replace(/\s+/g, ' ').slice(0, 24)) + '</span>');
    return tlRow({
      kind: 'todo',
      cls: opts.cls || '',
      ico: PF_ICONS.todo,
      title: esc(t.title),
      plain: t.title,
      meta: meta.join('<span class="tl-sep">·</span>'),
      act: '<button type="button" class="tl-check" data-tl-done="' + esc(t.id) +
        '" title="标记完成" aria-label="完成「' + esc(t.title) + '」">' + SVG_TL_CHECK + '</button>',
      goto: 'todo', id: t.id
    });
  }

  /* 近 7 天（含今天）完成数 */
  function ovTrendData() {
    var now = new Date();
    var keys = [], i;
    for (i = 6; i >= 0; i--) {
      var d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      keys.push({ key: d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()), isToday: i === 0 });
    }
    var map = {};
    DB._data.todo.forEach(function (t) {
      if (t && t.done && t.doneAt) {
        var k = isoToLocalDay(t.doneAt);
        if (k) map[k] = (map[k] || 0) + 1;
      }
    });
    keys.forEach(function (item) { item.n = map[item.key] || 0; });
    return keys;
  }

  /* 分类色点 */
  function catDot(cat) {
    return '<span class="cat-dot" style="background:' + esc(cat ? cat.color : '') + '"></span>';
  }

  /* 本周洞察右栏：待办分类分布；无分类数据时回退到备忘标签 Top */
  function ovDistRows() {
    var cats = DB.listCategories();
    var catMap = {};
    var cnt = {};
    var categorized = 0;
    cats.forEach(function (c) { catMap[c.id] = c; cnt[c.id] = 0; });
    DB._data.todo.forEach(function (t) {
      if (t && t.category && catMap[t.category]) { cnt[t.category]++; categorized++; }
    });
    if (categorized) {
      var rows = cats
        .map(function (c) { return { c: c, n: cnt[c.id] || 0 }; })
        .filter(function (r) { return r.n > 0; })
        .sort(function (a, b) { return b.n - a.n; })
        .slice(0, 6);
      var max = rows[0] ? rows[0].n : 1;
      var html = rows.map(function (r) {
        return '<div class="ov-dist-row">' +
          '<span class="ov-dist-name">' + catDot(r.c) + esc(r.c.name) + '</span>' +
          '<span class="ov-dist-track"><span class="ov-dist-fill" style="background:' + esc(r.c.color) + ';width:' + Math.round(r.n / max * 100) + '%"></span></span>' +
          '<span class="ov-dist-n">' + r.n + '</span></div>';
      }).join('');
      return { title: '待办 · 按分类', body: html, manage: true };
    }
    var tags = DB.memoTags().slice(0, 6);
    if (tags.length) {
      var tmax = tags[0].count || 1;
      var thtml = tags.map(function (t) {
        return '<div class="ov-dist-row">' +
          '<span class="ov-dist-name">' + esc(t.name) + '</span>' +
          '<span class="ov-dist-track"><span class="ov-dist-fill" style="width:' + Math.round(t.count / tmax * 100) + '%"></span></span>' +
          '<span class="ov-dist-n">' + t.count + '</span></div>';
      }).join('');
      return { title: '备忘 · 标签 Top', body: thtml, manage: false };
    }
    return null;
  }

  /* ============================================================
     概览 = 今日时间线
     一屏回答「今天该做什么、做得怎么样」：待办 / 习惯 / 纪念日 /
     一日三问混排进同一条流，按 已过期 → 今天 → 接下来 7 天 分组，
     行内直接完成与打卡，点行进详情。
     数据说明不在本页：见「个人中心 → 设置 → 关于」。
     ============================================================ */
  function renderOverview(animate) {
    var today = todayStr();
    var todos = DB.listTodos('all');
    var open = todos.filter(function (t) { return !t.done; });
    var doneToday = todos.filter(function (t) { return t.done && isoToLocalDay(t.doneAt) === today; }).length;

    var overdue = open.filter(function (t) { return t.due && t.due < today; }).sort(ovByDue);
    var todayOpen = open.filter(function (t) { return t.due === today; }).sort(ovByPrio);
    var soon = open.filter(function (t) {
      var d = t.due ? daysFromToday(t.due) : null;
      return d !== null && d > 0 && d <= 7;
    }).sort(ovByDue);
    /* 既不在今天也不在一周内（含未排期）：不占时间线，收成尾部一行入口 */
    var rest = open.length - overdue.length - todayOpen.length - soon.length;

    var habits = DB.listHabits();
    var habitUndo = habits.filter(function (h) { return !DB.isHabitDone(h.id, today); });
    var habitDone = habits.filter(function (h) { return DB.isHabitDone(h.id, today); });

    var upcoming = DB.upcoming(7);
    var evToday = upcoming.filter(function (ev) { return ev.days === 0; });
    var evSoon = upcoming.filter(function (ev) { return ev.days > 0; });

    var diaryToday = DB.getDiaryByDate(today);
    var diaryDays = DB.diaryStreak();

    /* ---- 今日 hero ---- */
    $('#ovHero').innerHTML = ovHeroHtml({
      plan: todayOpen.length + doneToday,
      doneToday: doneToday,
      todayOpen: todayOpen.length,
      overdue: overdue.length,
      habitUndo: habitUndo.length,
      diaryWritten: !!diaryToday
    });
    chipRailEnhance('ovQuick');

    /* ---- 今日时间线 ---- */
    var html = '';
    if (overdue.length) {
      html += tlGroup('已过期', overdue.length, 'is-bad');
      html += overdue.slice(0, 4).map(function (t) {
        var days = daysFromToday(t.due);
        return tlTodoRow(t, { cls: 'is-overdue', when: '过期 ' + (-days) + ' 天' });
      }).join('');
      if (overdue.length > 4) html += tlMoreRow('还有 ' + (overdue.length - 4) + ' 条过期', 'todo');
    }

    var todayRows = '';
    todayRows += todayOpen.map(function (t) { return tlTodoRow(t, { when: '今天到期' }); }).join('');
    todayRows += habitUndo.map(function (h) {
      var streak = DB.habitStreak(h.id);
      return tlRow({
        kind: 'habit', ico: PF_ICONS.habit, color: h.color,
        title: esc(h.name), plain: h.name,
        meta: esc(streak ? '连续 ' + streak + ' 天' : '今天开始第 1 天'),
        act: habitCheckCtl(h, today),
        goto: 'habit', id: h.id
      });
    }).join('');
    todayRows += evToday.map(function (ev) {
      var tm = typeMeta(ev.type);
      var anniv = anniversaryCount(ev.date);
      var meta = esc(tm.label) + (ev.repeat ? ' · 每年' : ' · 一次性');
      if (anniv !== null && ev.type === 'birthday') meta += ' · ' + anniv + ' 岁';
      else if (anniv !== null) meta += ' · ' + (anniv === 0 ? '第一年' : anniv + ' 周年');
      return tlRow({
        kind: 'date', cls: 'is-hit', ico: PF_ICONS.heart, color: tm.color,
        title: esc(ev.name), plain: ev.name,
        meta: meta,
        act: '<span class="tl-tag is-bad">就是今天</span>',
        goto: 'date', id: ev.id
      });
    }).join('');
    todayRows += diaryToday
      ? tlRow({
          kind: 'diary', ico: PF_ICONS.book,
          title: '一日三问', plain: '一日三问',
          meta: (function () {
            var mo = MOODS[diaryToday.mood] || MOODS.ok;
            return '<span class="cat-dot" style="background:' + mo.color + '"></span>' + esc(mo.label);
          })() +
            (diaryToday.what ? '<span class="tl-sep">·</span><span class="tl-desc">' +
              esc(diaryToday.what.replace(/\s+/g, ' ').slice(0, 12)) + '</span>' : ''),
          act: '<span class="tl-tag">' + esc(diaryDays ? '连续 ' + diaryDays + ' 天' : '已写') + '</span>',
          goto: 'diary', id: diaryToday.id
        })
      : tlRow({
          kind: 'diary', cls: 'is-pending', ico: PF_ICONS.book,
          title: '一日三问', plain: '一日三问',
          meta: '今天还没写' + (diaryDays
            ? '<span class="tl-sep">·</span><span class="tl-strong">连续 ' + diaryDays + ' 天要断了</span>'
            : '<span class="tl-sep">·</span>三分钟记录一下'),
          act: '<button type="button" class="tl-mini" data-quick="diary">去写</button>',
          goto: '', id: ''
        });
    todayRows += habitDone.map(function (h) {
      var streak = DB.habitStreak(h.id);
      return tlRow({
        kind: 'habit', cls: 'is-done', ico: PF_ICONS.done, color: h.color,
        title: esc(h.name), plain: h.name,
        meta: esc(streak ? '连续 ' + streak + ' 天' : '今天已打卡'),
        act: habitCheckCtl(h, today),
        goto: 'habit', id: h.id
      });
    }).join('');

    html += tlGroup('今天', todayOpen.length + habitUndo.length + evToday.length + (diaryToday ? 0 : 1));
    html += todayRows;

    if (soon.length || evSoon.length) {
      html += tlGroup('接下来 7 天', soon.length + evSoon.length);
      html += soon.map(function (t) { return { d: t.due, k: 'todo', o: t }; })
        .concat(evSoon.map(function (ev) { return { d: ev.nextDate, k: 'date', o: ev }; }))
        .sort(function (a, b) { return String(a.d).localeCompare(String(b.d)); })
        .slice(0, 7)
        .map(function (x) {
          var days = daysFromToday(x.d);
          if (x.k === 'todo') return tlTodoRow(x.o, { when: days === 1 ? '明天' : days + ' 天后' });
          var ev = x.o, tm = typeMeta(ev.type);
          return tlRow({
            kind: 'date', ico: PF_ICONS.heart, color: tm.color,
            title: esc(ev.name), plain: ev.name,
            meta: esc(mdCN(ev.nextDate) + ' · ' + weekdayCN(ev.nextDate) + ' · ' + tm.label),
            act: '<span class="tl-tag' + (days <= 3 ? ' is-warn' : '') + '">' + days + ' 天后</span>',
            goto: 'date', id: ev.id
          });
        }).join('');
    }

    if (rest > 0) html += tlMoreRow('另有 ' + rest + ' 条待办未排期或在 7 天后', 'todo');

    if (!html) {
      html = '<div class="tl-empty">' + SVG_BOX +
        '<div class="tl-empty-t">今天没有任何安排</div>' +
        '<div class="tl-empty-s">记一条待办、写一段回顾，或者只是记下此刻的想法</div>' +
        '<div class="tl-empty-acts">' +
          '<button type="button" class="btn btn-primary btn-sm" data-quick="todo">' + SVG_PLUS + '<span>新增待办</span></button>' +
          '<button type="button" class="btn btn-default btn-sm" data-quick="diary"><span>写今日回顾</span></button>' +
        '</div></div>';
    }
    var tl = $('#ovTimeline');
    tl.innerHTML = html;
    staggerList(tl, animate);

    /* ---- 本周：近 7 天趋势 + 分类分布（进度环已并入 hero，两张卡合成一张） ---- */
    var trend = ovTrendData();
    var trendMax = Math.max.apply(null, trend.map(function (x) { return x.n; })) || 1;
    var trendHtml = trend.map(function (x) {
      var h = Math.max(3, Math.round(x.n / trendMax * 64));
      return '<div class="ov-bar-col' + (x.isToday ? ' is-today' : '') + '" title="' + x.key + ' · 完成 ' + x.n + ' 项">' +
        '<span class="ov-bar-n">' + (x.n || '') + '</span>' +
        '<span class="ov-bar" style="height:' + h + 'px"></span>' +
        '<span class="ov-bar-l">' + '日一二三四五六'.charAt(new Date(x.key + 'T00:00:00').getDay()) + '</span></div>';
    }).join('');
    var hasDone = trend.some(function (x) { return x.n > 0; });
    var dist = ovDistRows();
    var weekTotal = trend.reduce(function (a, x) { return a + x.n; }, 0);

    $('#insightGrid').innerHTML =
      '<section class="insight-card ov-week">' +
        '<div class="insight-head"><span>本周</span>' +
          '<span class="ov-week-sum">近 7 天完成 <b data-count="' + weekTotal + '">' + weekTotal + '</b> 项</span></div>' +
        '<div class="ov-week-body">' +
          '<div class="ov-week-col">' +
            '<div class="ov-week-l">近 7 天完成</div>' +
            (hasDone
              ? '<div class="ov-bars">' + trendHtml + '</div>'
              : '<div class="insight-empty">' + SVG_BOX + '近 7 天暂无完成记录<br><span class="insight-empty-sub">完成一项待办后这里会出现小柱子</span></div>') +
          '</div>' +
          '<div class="ov-week-col">' +
            '<div class="ov-week-l"><span>' + (dist ? dist.title : '数据分布') + '</span>' +
              (dist && dist.manage ? '<button type="button" class="btn-link" data-cat-manage>管理分类</button>' : '') + '</div>' +
            (dist
              ? dist.body
              : '<div class="insight-empty">' + SVG_BOX + '还没有分布数据<br><span class="insight-empty-sub">给待办添加分类，或给备忘打上标签</span></div>') +
          '</div>' +
        '</div>' +
        '<div class="ov-week-foot">' +
          '<button type="button" data-goto="memo">备忘 <b>' + DB._data.memo.length + '</b> 条</button>' +
          '<button type="button" data-goto="date">纪念日 <b>' + (DB._data.special_date || []).length + '</b> 个</button>' +
          '<button type="button" data-goto="diary">回顾 <b>' + (DB._data.diary || []).length + '</b> 篇</button>' +
          '<button type="button" data-goto="habit">习惯 <b>' + habits.length + '</b> 个</button>' +
        '</div>' +
      '</section>';
    animateCounters($('#insightGrid'));
  }

  /* ============================================================
     待办视图
     ============================================================ */
  /* 优先级：以星数表示（1 星 低 / 2 星 中 / 3 星 高），保留无障碍文案 */
  var PRIO = {
    low:    { n: 1, label: '低' },
    normal: { n: 2, label: '中' },
    high:   { n: 3, label: '高' }
  };
  var SVG_STAR = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 1L15 9L23 12L15 15L12 23L9 15L1 12L9 9z"/></svg>';

  function priorityStars(p) {
    var cfg = PRIO[p] || PRIO.normal;
    var stars = '';
    for (var i = 0; i < cfg.n; i++) stars += SVG_STAR;
    return '<span class="prio prio-' + cfg.n + '" role="img"' +
      ' title="优先级：' + cfg.label + '" aria-label="优先级：' + cfg.label + '">' +
      stars + '</span>';
  }

  function rowTodo(t) {
    var cat = t.category ? DB.getCategory(t.category) : null;
    var catTag = cat
      ? '<span class="todo-cat" title="分类：' + esc(cat.name) + '"><span class="cat-dot" style="background:' + esc(cat.color) + '"></span>' + esc(cat.name) + '</span>'
      : '';
    var subs = t.subtasks || [];
    var subDone = subs.filter(function (s) { return s.done; }).length;
    var subFlag = subs.length
      ? '<span class="todo-flag" title="子任务进度">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>' +
        subDone + '/' + subs.length + '</span>'
      : '';
    var repTxt = repeatLabel(t.repeat);
    var repFlag = repTxt
      ? '<span class="todo-flag todo-flag-rep" title="重复：' + esc(repTxt) + '，完成后自动生成下一次">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 2l4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/></svg>' +
        esc(repTxt) + '</span>'
      : '';
    var dueCell;
    if (t.due) {
      var days = daysFromToday(t.due);
      var overdue = !t.done && days !== null && days < 0;
      dueCell = '<span' + (overdue ? ' class="text-danger"' : '') + '>' + t.due + '</span>' +
        (overdue ? ' <span class="tag tag-bad">已过期</span>' : (t.done && days !== null && days < 0 ? ' <span class="tag">已完成</span>' : ''));
    } else {
      dueCell = '<span class="muted">无截止</span>';
    }
    return '<tr data-id="' + esc(t.id) + '">' +
      '<td class="col-check">' +
        '<label class="todo-check"><input type="checkbox"' + (t.done ? ' checked' : '') + ' aria-label="标记' + (t.done ? '未完成' : '完成') + '">' +
        '<span class="todo-check-box"><svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 6.5l2.5 2.5L10 3.5"/></svg></span></label>' +
      '</td>' +
      '<td><div class="todo-title' + (t.done ? ' is-done' : '') + '" title="' + esc(t.title) + '">' + esc(t.title) + '</div>' +
        (catTag || repFlag || subFlag || t.desc ? '<div class="todo-meta">' + catTag + repFlag + subFlag + (t.desc ? '<span class="todo-desc" title="' + esc(t.desc) + '">' + esc(t.desc) + '</span>' : '') + '</div>' : '') + '</td>' +
      '<td class="col-priority">' + priorityStars(t.priority) + '</td>' +
      '<td class="col-due">' + dueCell + '</td>' +
      '<td class="code">' + fmtDate(t.createdAt) + '</td>' +
      '<td class="swipe-acts">' +
        '<button type="button" class="swipe-act swipe-arch" data-swipe="arch" aria-label="归档" title="归档">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="4" width="17" height="5" rx="1.2"/><path d="M5.5 9v9.5a1.5 1.5 0 0 0 1.5 1.5h10a1.5 1.5 0 0 0 1.5-1.5V9"/><path d="M10 13h4"/></svg>' +
        '</button>' +
        '<button type="button" class="swipe-act swipe-del" data-swipe="del" aria-label="删除" title="删除">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 6.5h15M9.5 6.5V5a1.4 1.4 0 0 1 1.4-1.4h2.2A1.4 1.4 0 0 1 14.5 5v1.5M6.5 6.5l.8 13a1.6 1.6 0 0 0 1.6 1.5h6.2a1.6 1.6 0 0 0 1.6-1.5l.8-13"/><path d="M10.1 10.5v6.5M13.9 10.5v6.5"/></svg>' +
        '</button>' +
      '</td>' +
    '</tr>';
  }

  function renderTodoCatBar() {
    var bar = $('#todoCatBar');
    if (!bar) return;
    var all = DB.listTodos('all');
    var cats = DB.listCategories();
    var chips = '<button type="button" class="chip' + (!state.todoCat ? ' active' : '') + '" data-cat="">全部<span class="chip-cnt">' + all.length + '</span></button>';
    cats.forEach(function (c) {
      var n = all.filter(function (t) { return t.category === c.id; }).length;
      chips += '<button type="button" class="chip' + (state.todoCat === c.id ? ' active' : '') + '" data-cat="' + esc(c.id) + '">' +
        catDot(c) + esc(c.name) + '<span class="chip-cnt">' + n + '</span></button>';
    });
    var none = all.filter(function (t) { return !t.category; }).length;
    if (none || cats.length) {
      chips += '<button type="button" class="chip' + (state.todoCat === 'none' ? ' active' : '') + '" data-cat="none">未分类<span class="chip-cnt">' + none + '</span></button>';
    }
    /* 与备忘标签条同款：单行横滑收纳 + 固定「全部分类」入口（管理收进浮层） */
    bar.innerHTML =
      '<div class="chip-scroll" id="todoChipScroll">' + chips + '</div>' +
      '<button type="button" class="chip chip-more" data-cat-all title="全部分类" aria-label="查看全部分类">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>' +
        '全部分类<span class="chip-cnt">' + cats.length + '</span></button>';
    chipRailEnhance('todoChipScroll');
  }

  function renderTodos(animate) {
    var body = $('#todoBody');
    var all = DB.listTodos('all');
    var openCnt = all.filter(function (t) { return !t.done; }).length;

    renderTodoCatBar();

    /* 分段器计数 */
    var seg = $('#todoSeg');
    seg.querySelector('[data-cnt="all"]').textContent = String(all.length);
    seg.querySelector('[data-cnt="open"]').textContent = String(openCnt);
    seg.querySelector('[data-cnt="done"]').textContent = String(all.length - openCnt);

    /* 筛选 + 搜索 */
    var list = all;
    if (state.todoFilter === 'open') list = list.filter(function (t) { return !t.done; });
    else if (state.todoFilter === 'done') list = list.filter(function (t) { return !!t.done; });
    if (state.todoCat === 'none') list = list.filter(function (t) { return !t.category; });
    else if (state.todoCat) list = list.filter(function (t) { return t.category === state.todoCat; });

    var q = state.todoSearch.trim().toLowerCase();
    if (q) {
      list = list.filter(function (t) {
        return (t.title + '\n' + (t.desc || '')).toLowerCase().indexOf(q) !== -1;
      });
    }

    var empty = $('#todoEmpty');
    var table = body.closest('table');

    if (!list.length) {
      body.innerHTML = '';
      table.style.display = 'none';
      /* 空态语义区分：搜索词→未匹配；分类/状态筛选→该范围确实为空（引导新增） */
      var sub, catName = null;
      if (state.todoCat === 'none') catName = '未分类';
      else if (state.todoCat) {
        var cat = DB.getCategory(state.todoCat);
        catName = cat ? cat.name : null;
      }
      if (q) {
        empty.innerHTML = emptyHtml(true, '待办');
      } else if (catName) {
        empty.innerHTML = emptyHtml(false, '待办', '「' + esc(catName) + '」分类下还没有待办，添加一项吧', 'todo');
      } else if (state.todoFilter === 'done') {
        empty.innerHTML = emptyHtml(false, '待办', '还没有已完成的待办，勾选后会出现在这里', 'todo');
      } else if (state.todoFilter === 'open') {
        empty.innerHTML = emptyHtml(false, '待办', '没有进行中的待办，全部完成啦～', 'todo');
      } else {
        empty.innerHTML = emptyHtml(false, '待办', '今天没有待办，享受轻松的一天吧～', 'todo');
      }
      empty.hidden = false;
      return;
    }

    table.style.display = '';
    empty.hidden = true;
    body.classList.toggle('tbody-enter', !!animate);
    body.innerHTML = list.map(rowTodo).join('');
  }

  /* 待办表单弹窗 */
  function openTodoForm(item, opts) {
    var isEdit = !!item;
    var pri = item ? item.priority : 'normal';
    /* 新建时预选当前筛选的分类；「未分类」筛选 → 空值；编辑时保持原分类 */
    var curCat;
    if (item) {
      curCat = item.category || '';
    } else if (state.todoCat === 'none') {
      curCat = '';
    } else {
      curCat = state.todoCat || '';
      /* 防御：分类已被删除时回退为未分类 */
      if (curCat && !DB.getCategory(curCat)) curCat = '';
    }
    var cats = DB.listCategories();
    var catOpts = '<option value="">未分类</option>' + cats.map(function (c) {
      return '<option value="' + esc(c.id) + '"' + (curCat === c.id ? ' selected' : '') + '>' +
        esc(c.name) + '</option>';
    }).join('');
    var subList = normSubsForEdit(item ? item.subtasks : []);
    var repDef = item ? item.repeat : null;

    Modal.open({
      dirtyGuard: true,
      title: isEdit ? '编辑待办' : '新增待办',
      afterClose: opts && opts.back, /* 挂 back：取消/X/Esc/遮罩/保存全路径返回详情 */
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        '<div class="field" data-fg="main">' +
          '<label for="f-title">标题<span class="req">*</span></label>' +
          '<input class="form-input" id="f-title" type="text" maxlength="200" value="' + esc(item ? item.title : '') + '" placeholder="要做什么？">' +
        '</div>' +
        '<div class="field desc-field' + (item && item.desc ? '' : ' is-collapsed fg-row') + '" data-fg="main">' +
          '<label for="f-desc">描述</label>' +
          '<textarea class="form-input" id="f-desc" rows="3" maxlength="2000" placeholder="补充说明（可选）">' + esc(item ? item.desc : '') + '</textarea>' +
          '<button type="button" class="desc-toggle" id="f-desc-open">＋ 填写描述</button>' +
        '</div>' +
        '<div class="field fg-row" data-fg="main">' +
          '<label for="f-cat">分类</label>' +
          '<div class="select-wrap"><select class="form-input" id="f-cat">' + catOpts + '</select></div>' +
          (!cats.length
            ? '<div class="field-hint">还没有分类，可在待办列表分类栏「＋ 管理」中创建（可自定义颜色）</div>'
            : '') +
        '</div>' +
        '<div class="field" data-fg="subs">' +
          '<label>子任务<span class="opt">（可选，拆解步骤）</span></label>' +
          '<div class="sub-editor" id="f-subs"></div>' +
          '<div class="sub-add">' +
            '<input class="form-input" id="f-sub-new" type="text" maxlength="100" placeholder="添加步骤，回车确认">' +
            '<button type="button" class="btn btn-default" id="f-sub-add" aria-label="添加子任务">' + SVG_PLUS + '</button>' +
          '</div>' +
        '</div>' +
        '<div class="field fg-row" data-fg="meta">' +
          '<label for="f-repeat">重复</label>' +
          '<div class="select-wrap"><select class="form-input" id="f-repeat">' +
            '<option value="none">不重复</option>' +
            '<option value="daily">每天</option>' +
            '<option value="weekly">每周</option>' +
            '<option value="monthly">每月</option>' +
            '<option value="yearly">每年</option>' +
          '</select></div>' +
          '<div class="field-extra" id="f-repeat-extra"></div>' +
          '<div class="field-hint">完成后将自动创建下一次的待办</div>' +
        '</div>' +
        '<div class="field" data-fg="meta">' +
          '<div class="field-row">' +
            '<div>' +
              '<label for="f-priority">优先级</label>' +
              '<div class="select-wrap"><select class="form-input" id="f-priority">' +
                '<option value="high"' + (pri === 'high' ? ' selected' : '') + '>✦✦✦</option>' +
                '<option value="normal"' + (pri === 'normal' ? ' selected' : '') + '>✦✦</option>' +
                '<option value="low"' + (pri === 'low' ? ' selected' : '') + '>✦</option>' +
              '</select></div>' +
            '</div>' +
            '<div>' +
              '<label for="f-due">截止时间</label>' +
              '<input class="form-input" id="f-due" type="date" value="' + esc(item ? item.due : '') + '">' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        isEdit ? {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('待办', item.title, function () { DB.deleteTodo(item.id); });
          }
        } : null,
        { text: '取消', className: 'btn-default' },
        {
          text: isEdit ? '保存修改' : '添加',
          className: 'btn-primary', primary: true,
          onClick: function () {
            var card = Modal.card;
            var title = $('#f-title', card).value.trim();
            var desc = $('#f-desc', card).value.trim();
            var priority = $('#f-priority', card).value;
            var due = $('#f-due', card).value;
            var category = $('#f-cat', card).value || '';
            var repeat = collectRepeat();
            if (!title) { showFormError('请填写待办标题', 'f-title'); return; }
            if (repeat === undefined) return;
            try {
              if (isEdit) DB.updateTodo(item.id, { title: title, desc: desc, priority: priority, due: due, category: category, subtasks: subList, repeat: repeat });
              else DB.addTodo({ title: title, desc: desc, priority: priority, due: due, category: category, subtasks: subList, repeat: repeat });
            } catch (e) {
              if (e instanceof Errors.QuotaError) { quotaModal(); return; }
              if (e instanceof Errors.ValidationError) { showFormError(e.message); return; }
              toast('操作失败，请重试', 'error'); return;
            }
            Modal.markClean();
            Modal.close();
            toast(isEdit ? '待办已更新' : '待办已添加');
            renderView('todo');
            if (isEdit && !(opts && opts.back)) openTodoDetail(DB.getTodo(item.id)); /* 回到详情（从详情进入时由 afterClose 统一返回） */
          }
        }
      ].filter(Boolean)
    });
    mobFormify();

    /* ---------- 子任务编辑器：按住手柄拖动排序 + 标题常驻行内编辑 ----------
       编辑页不负责「完成」勾选（完成只在列表/详情里做），这里只管内容、顺序、删除；
       已完成的步骤以删除线弱化显示，但标题仍然可以直接改。 */
    var SVG_GRIP = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' +
      '<circle cx="9" cy="5.5" r="1.55"/><circle cx="15" cy="5.5" r="1.55"/>' +
      '<circle cx="9" cy="12" r="1.55"/><circle cx="15" cy="12" r="1.55"/>' +
      '<circle cx="9" cy="18.5" r="1.55"/><circle cx="15" cy="18.5" r="1.55"/></svg>';
    var subsBox = $('#f-subs', Modal.card);

    function renderSubs() {
      subsBox.innerHTML = subList.map(function (s, i) {
        return '<div class="sub-row' + (s.done ? ' is-done' : '') + '" data-i="' + i + '">' +
          '<button type="button" class="sub-handle" aria-label="拖动调整「' + esc(s.title) + '」的顺序" title="按住拖动排序">' + SVG_GRIP + '</button>' +
          '<input class="sub-name" type="text" maxlength="100" value="' + esc(s.title) + '" aria-label="步骤名称">' +
          '<button type="button" class="sub-del" aria-label="删除步骤">' + SVG_TRASH + '</button>' +
        '</div>';
      }).join('');
    }
    function subRows() { return $all('.sub-row', subsBox); }

    function reorderSub(from, to) {
      if (from === to || from < 0 || to < 0) return false;
      to = Math.max(0, Math.min(subList.length - 1, to));
      var it = subList.splice(from, 1)[0];
      subList.splice(to, 0, it);
      renderSubs();
      Modal.markDirty(); /* 顺序也是改动：没有 input/change 事件，得手动置脏 */
      return true;
    }

    subsBox.addEventListener('input', function (e) {
      var inp = e.target.closest('.sub-name');
      if (!inp) return;
      var row = inp.closest('.sub-row');
      var i = +row.getAttribute('data-i');
      if (subList[i]) subList[i].title = inp.value; /* 只写回数据：重绘会打断光标 */
    });
    subsBox.addEventListener('click', function (e) {
      var del = e.target.closest('.sub-del');
      if (!del) return;
      var row = del.closest('.sub-row');
      subList.splice(+row.getAttribute('data-i'), 1);
      renderSubs();
      Modal.markDirty();
    });
    /* 键盘：手柄 ↑/↓ 排序；步骤名里回车只提交当前文本，不能冒到全局去保存整张表单 */
    subsBox.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.closest('.sub-name')) { e.preventDefault(); return; }
      var h = e.target.closest('.sub-handle');
      if (!h || (e.key !== 'ArrowUp' && e.key !== 'ArrowDown')) return;
      e.preventDefault();
      var from = +h.closest('.sub-row').getAttribute('data-i');
      if (reorderSub(from, from + (e.key === 'ArrowUp' ? -1 : 1))) {
        var rows = subRows();
        var next = rows[Math.max(0, Math.min(rows.length - 1, from + (e.key === 'ArrowUp' ? -1 : 1)))];
        if (next) next.querySelector('.sub-handle').focus();
      }
    });

    /* 拖动排序：Pointer Events，触屏与鼠标同一套；只从手柄发起，
       这样行内输入框仍然可以正常点选文字与放置光标 */
    (function bindSubDrag() {
      var d = null;
      subsBox.addEventListener('pointerdown', function (e) {
        var h = e.target.closest('.sub-handle');
        if (!h || (e.pointerType === 'mouse' && e.button !== 0)) return;
        var rows = subRows();
        if (rows.length < 2) return;
        var row = h.closest('.sub-row');
        var rect = row.getBoundingClientRect();
        d = { id: e.pointerId, row: row, rows: rows, pitch: rect.height,
              from: +row.getAttribute('data-i'), to: +row.getAttribute('data-i'), y0: e.clientY };
        e.preventDefault(); /* 不让手柄抢焦点，也不留下选中态 */
        row.classList.add('is-dragging');
        subsBox.classList.add('is-dragging-mode');
        try { h.setPointerCapture(e.pointerId); } catch (err) { /* 老浏览器忽略 */ }
        /* 指针可能一路移出弹窗：起拖时才挂 document 兜底，endDrag 里无条件摘掉 */
        document.addEventListener('pointerup', endDrag);
        document.addEventListener('pointercancel', endDrag);
      });
      subsBox.addEventListener('pointermove', function (e) {
        if (!d || e.pointerId !== d.id) return;
        var dy = e.clientY - d.y0;
        d.row.style.transform = 'translateY(' + dy + 'px) scale(1.015)';
        var to = Math.max(0, Math.min(d.rows.length - 1, d.from + Math.round(dy / d.pitch)));
        if (to === d.to) return;
        d.to = to;
        d.rows.forEach(function (r, k) {
          if (r === d.row) return;
          var shift = 0;
          if (d.from < to && k > d.from && k <= to) shift = -d.pitch;
          else if (d.from > to && k >= to && k < d.from) shift = d.pitch;
          r.style.transform = shift ? 'translateY(' + shift + 'px)' : '';
        });
      });
      function endDrag(e) {
        if (!d || (e && e.pointerId !== d.id)) return;
        var from = d.from, to = d.to;
        d.rows.forEach(function (r) { r.style.transform = ''; });
        d.row.classList.remove('is-dragging');
        subsBox.classList.remove('is-dragging-mode');
        d = null;
        document.removeEventListener('pointerup', endDrag);
        document.removeEventListener('pointercancel', endDrag);
        reorderSub(from, to);
      }
      subsBox.addEventListener('pointerup', endDrag);
      subsBox.addEventListener('pointercancel', endDrag);
    })();

    function addSub() {
      var inp = $('#f-sub-new', Modal.card);
      var title = inp.value.trim();
      if (!title) { inp.focus(); return; }
      if (subList.length >= 20) { showFormError('子任务最多 20 项'); return; }
      subList.push({ id: 's_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: title, done: false });
      inp.value = '';
      renderSubs();
      inp.focus();
    }
    $('#f-sub-add', Modal.card).addEventListener('click', addSub);
    $('#f-sub-new', Modal.card).addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); addSub(); }
    });

    /* ---------- 重复规则 ---------- */
    var WD = ['日', '一', '二', '三', '四', '五', '六'];
    function renderRepeatExtra() {
      var type = $('#f-repeat', Modal.card).value;
      var box = $('#f-repeat-extra', Modal.card);
      if (type === 'weekly') {
        var days = (repDef && repDef.type === 'weekly') ? repDef.days : [];
        box.innerHTML = '<div class="wd-row" id="f-weekdays">' + WD.map(function (w, i) {
          return '<button type="button" class="wd-btn' + (days.indexOf(i) !== -1 ? ' active' : '') + '" data-wd="' + i + '">' + w + '</button>';
        }).join('') + '</div>';
      } else if (type === 'monthly') {
        var dom = (repDef && repDef.type === 'monthly') ? repDef.dom : 1;
        box.innerHTML = '<div class="dom-row">每月 <input class="form-input" id="f-dom" type="number" min="1" max="31" value="' + dom + '"> 号</div>';
      } else {
        box.innerHTML = '';
      }
    }
    $('#f-repeat', Modal.card).addEventListener('change', function () {
      if (this.value !== 'weekly') repDef = null;
      renderRepeatExtra();
    });
    $('#f-repeat-extra', Modal.card).addEventListener('click', function (e) {
      var btn = e.target.closest('.wd-btn');
      if (!btn) return;
      btn.classList.toggle('active');
    });

    /* 描述按需展开：收起态只是一行入口，点开才出现输入井（手机端同时把该行从行式换成堆叠式） */
    $('#f-desc-open', Modal.card).addEventListener('click', function () {
      var f = $('#f-desc', Modal.card).closest('.field');
      f.classList.remove('is-collapsed', 'fg-row');
      f.classList.add('fg-stack');
      $('#f-desc', Modal.card).focus();
    });

    function collectRepeat() {
      var card = Modal.card;
      var type = $('#f-repeat', card).value;
      if (type === 'none') return null;
      if (type === 'weekly') {
        var days = $all('#f-weekdays .wd-btn.active', card).map(function (b) {
          return +b.getAttribute('data-wd');
        });
        if (!days.length) { showFormError('请选择每周重复的星期'); return undefined; }
        return { type: 'weekly', days: days };
      }
      if (type === 'monthly') {
        var dom = parseInt($('#f-dom', card).value, 10);
        if (!(dom >= 1 && dom <= 31)) { showFormError('请填写每月几号（1-31）'); return undefined; }
        return { type: 'monthly', dom: dom };
      }
      return { type: type };
    }

    renderSubs();
    renderRepeatExtra();
    $('#f-repeat', Modal.card).value = (repDef ? repDef.type : 'none');
    renderRepeatExtra();
  }

  /* ============================================================
     待办分类管理
     ============================================================ */
  var CAT_COLORS = ['#111111', '#E24B4A', '#EF9F27', '#97C459', '#5DCAA5', '#378ADD', '#7F77DD', '#D4537E', '#0F6E56', '#888780'];
  var SVG_PENCIL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 3l4 4L8 20l-5 1 1-5z"/></svg>';
  var SVG_TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>';

  /* 自定义颜色入口：未取色时是虚线圈 + 加号（与「新增」同语言），取色后填色并显示勾 */
  function catPaletteHtml(sel, opts) {
    opts = opts || {};
    var html = '';
    CAT_COLORS.forEach(function (c) {
      html += '<button type="button" class="cat-swatch' + (c === sel ? ' is-sel' : '') + '" data-color="' + c +
        '" style="background:' + c + '" aria-label="选择颜色 ' + c + '"></button>';
    });
    if (opts.custom) {
      var isPreset = CAT_COLORS.indexOf(sel) !== -1;
      var cur = /^#[0-9a-fA-F]{6}$/.test(sel || '') ? String(sel).toLowerCase() : '';
      html += '<button type="button" class="cat-swatch cat-swatch-custom' + (isPreset ? '' : ' is-filled is-sel') +
        '" data-custom="1" data-color="' + (isPreset ? '' : sel) + '" aria-label="自定义颜色" title="自定义颜色"' +
        (isPreset ? '' : ' style="background:' + sel + ';color:' + hmInk(sel) + '"') + '>' +
        (isPreset ? SVG_PLUS : HABIT_CHECK) + '</button>' +
        '<span class="cat-custom-hex" id="' + (opts.hexId || 'catCustomHex') + '"' + (isPreset ? ' hidden' : '') + '>' + cur + '</span>';
    }
    return html;
  }

  /* 预设 + 自定义取色的共用绑定：root 是 .cat-palette 容器。
     色值标签按 class 就地找——旧调用点多传的原生取色 input 引用直接忽略 */
  function bindColorPalette(root) {
    if (!root) return;
    var custom = root.querySelector('[data-custom]');
    var hexEl = root.querySelector('.cat-custom-hex');
    function pick(el) {
      $all('.cat-swatch', root).forEach(function (b) { b.classList.toggle('is-sel', b === el); });
    }
    function selColor() {
      var s = root.querySelector('.cat-swatch.is-sel');
      return s ? (s.getAttribute('data-color') || '') : '';
    }
    root.addEventListener('click', function (e) {
      var sw = e.target.closest('.cat-swatch');
      if (!sw) return;
      if (custom && sw === custom) {
        /* 从当前选中色起步：在预设色上微调也顺手 */
        openColorPicker({ color: selColor() || CAT_COLORS[4], onOk: function (c) {
          custom.classList.add('is-filled');
          custom.classList.remove('is-sel');
          custom.setAttribute('data-color', c);
          custom.style.background = c;
          custom.style.color = hmInk(c);
          custom.innerHTML = HABIT_CHECK;
          pick(custom);
          if (hexEl) { hexEl.textContent = c; hexEl.hidden = false; }
        } });
        return;
      }
      pick(sw);
      if (hexEl) hexEl.hidden = true;
    });
  }

  /* ---- 自建取色抽屉：与滚轮选择器同一外壳（.wp-mask / .wp-sheet / .wp-foot）
     黑白语言里只让「颜色本身」有彩色：色块、SV 面板、色相条，其余全是站内灰阶 ---- */
  function hmHex2hsv(hex) {
    var c = hmRgb(hex), r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) {
      if (mx === r) h = 60 * (((g - b) / d) % 6);
      else if (mx === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
    }
    if (h < 0) h += 360;
    return { h: Math.round(h), s: mx ? d / mx : 0, v: mx };
  }
  function hmHsv2hex(h, s, v) {
    var c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c, r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; } else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return hmHex([(r + m) * 255, (g + m) * 255, (b + m) * 255]);
  }

  function openColorPicker(opts) {
    opts = opts || {};
    var mask = document.createElement('div');
    mask.className = 'wp-mask cp-mask';
    mask.innerHTML =
      '<div class="wp-sheet cp-sheet" role="dialog" aria-modal="true" aria-label="自定义颜色">' +
        '<div class="wp-title">自定义颜色</div>' +
        '<div class="cp-stage">' +
          '<span class="cp-chip" id="cpChip">' + HABIT_CHECK + '</span>' +
          '<span class="cp-stage-txt"><b>本周热力档位</b><em>颜色越深，当日打卡次数越多</em></span>' +
          '<span class="cp-ramp" id="cpRamp"><i>1</i><i>2</i><i>3+</i></span>' +
        '</div>' +
        '<div class="cp-sv" id="cpSv" tabindex="0" role="application" aria-label="饱和度与明度面板，方向键微调"><span class="cp-thumb"></span></div>' +
        '<div class="cp-hue" id="cpHue" tabindex="0" role="slider" aria-label="色相，左右方向键调节" aria-valuemin="0" aria-valuemax="360"><span class="cp-thumb"></span></div>' +
        '<div class="cp-hex-row"><span class="cp-hex-k">色值</span>' +
          '<input class="form-input cp-hex" id="cpHex" type="text" maxlength="7" spellcheck="false" autocomplete="off" aria-label="十六进制色值"></div>' +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-cancel">取消</button>' +
          '<button type="button" class="wp-btn wp-btn-ok">确定</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    var sheet = mask.firstChild;
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var bfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收这层 */
    var closed = false;
    var sv = $('#cpSv', sheet), hue = $('#cpHue', sheet), chip = $('#cpChip', sheet),
        ramp = $('#cpRamp', sheet), hexIn = $('#cpHex', sheet);
    var init = /^#[0-9a-fA-F]{3,8}$/.test(opts.color || '') ? opts.color : CAT_COLORS[4];
    var st = hmHex2hsv(init);
    if (st.v < 0.06) st.v = 1;   /* 纯黑起步会锁死明度，给个可见的起点 */
    /* HSV 往返会把精确色算偏一位（#5DCAA5 → #5DCAA6、#B4553F → #b4543f）：
       打开时与手输色值锁成「精确色」，只有真正拖动 / 微调后才交给 HSV 重建 */
    var exact = String(init).toLowerCase();

    function hex() { return exact || hmHsv2hex(st.h, st.s, st.v); }
    function paint(keepTyped) {
      var c = hex();
      sheet.style.setProperty('--cp-h', String(st.h));
      sheet.style.setProperty('--cp-s', String(st.s));
      sheet.style.setProperty('--cp-v', String(st.v));
      chip.style.background = c;
      chip.style.color = hmInk(c);
      /* 预览用的三档与卡片/详情完全同源：亮色由浅到深，暗色由暗到亮 */
      var dark = document.documentElement.getAttribute('data-theme') === 'dark';
      var lt = [hmMix(c, '#FFFFFF', 0.24), hmMix(c, '#FFFFFF', 0.55), c];
      var dk = [hmMix(c, '#15171B', 0.34), hmMix(c, '#15171B', 0.67), hmMix(c, '#FFFFFF', 0.38)];
      $all('i', ramp).forEach(function (n, i) {
        var col = (dark ? dk : lt)[i];
        n.style.background = col;
        n.style.color = hmInk(col);
      });
      if (!keepTyped) hexIn.value = c.toUpperCase();
      hue.setAttribute('aria-valuenow', String(st.h));
      hue.setAttribute('aria-valuetext', c);
    }
    function drag(el, onPos) {
      el.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        if (el.setPointerCapture) { try { el.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ } }
        el.classList.add('is-drag');
        function move(ev) {
          var r = el.getBoundingClientRect();
          if (!r.width || !r.height) return;
          onPos(Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)),
                Math.max(0, Math.min(1, (ev.clientY - r.top) / r.height)));
        }
        function up() {
          el.classList.remove('is-drag');
          el.removeEventListener('pointermove', move);
          el.removeEventListener('pointerup', up);
          el.removeEventListener('pointercancel', up);
        }
        el.addEventListener('pointermove', move);
        el.addEventListener('pointerup', up);
        el.addEventListener('pointercancel', up);
        move(e);
      });
    }
    drag(sv, function (x, y) { exact = ''; st.s = x; st.v = 1 - y; paint(); });
    drag(hue, function (x) { exact = ''; st.h = Math.round(x * 359); paint(); });
    hue.addEventListener('keydown', function (e) {
      var d = e.key === 'ArrowLeft' ? -4 : e.key === 'ArrowRight' ? 4 : 0;
      if (!d) return;
      e.preventDefault();
      exact = '';
      st.h = (st.h + d + 360) % 360;
      paint();
    });
    sv.addEventListener('keydown', function (e) {
      var dx = e.key === 'ArrowLeft' ? -0.05 : e.key === 'ArrowRight' ? 0.05 : 0;
      var dy = e.key === 'ArrowUp' ? 0.05 : e.key === 'ArrowDown' ? -0.05 : 0;
      if (!dx && !dy) return;
      e.preventDefault();
      exact = '';
      st.s = Math.max(0, Math.min(1, st.s + dx));
      st.v = Math.max(0, Math.min(1, st.v + dy));
      paint();
    });
    hexIn.addEventListener('input', function () {
      var v = String(this.value).trim();
      if (v && v.charAt(0) !== '#') v = '#' + v;
      if (!/^#[0-9a-fA-F]{6}$/.test(v)) return;
      var n = hmHex2hsv(v);
      st.h = n.h; st.s = n.s; st.v = n.v < 0.06 ? 1 : n.v;
      exact = v.toLowerCase();   /* 手输的色值原样保留，不让 HSV 往返算偏 */
      paint(true);
    });
    hexIn.addEventListener('blur', function () { paint(); });

    function close() {
      if (closed) return;
      closed = true;
      if (bfr) WbBack.finish(bfr);
      mask.classList.remove('is-open');
      document.removeEventListener('keydown', onKey, true);
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 320);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }
    $('.wp-btn-cancel', sheet).addEventListener('click', close);
    $('.wp-btn-ok', sheet).addEventListener('click', function () {
      var c = hex();
      close();
      if (opts.onOk) opts.onOk(c);
    });
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    mask.addEventListener('pointerdown', function (e) { if (e.target === mask) e.stopPropagation(); });
    document.addEventListener('keydown', onKey, true);
    paint();
  }

  function catCounts() {
    var map = {};
    DB._data.todo.forEach(function (t) { if (t) map[t.category || ''] = (map[t.category || ''] || 0) + 1; });
    return map;
  }

  /* 分类管理改版（2026-09-16）：dd-modal 白卡 + dd-row 发丝线行 + 行内编辑。
     editId：null | '__new'（行尾新建）| 分类 id（该行展开编辑），整卡重绘、事件全委托 */
  /* 分类管理 · 行级直改：点行改名（回车/切行/关抽屉提交，Esc 取消），
     点色点在行下方展开迷你色板、选中即存；尾行「新建分类」点开即打字 */
  function catPaletteStrip(key) {
    return '<div class="mg-palette" data-pal-for="' + esc(key) + '"><div class="cat-palette">' + catPaletteHtml(null) + '</div></div>';
  }
  function catRowEditorHtml(c, key, palOpen, val, dotColor) {
    return '<div class="dd-row mg-row is-editing" data-id="' + esc(key) + '">' +
        '<button type="button" class="cat-dot mg-dot" id="catEditDot" data-cat-dot="' + esc(key) + '" style="background:' + esc(dotColor || (c ? c.color : CAT_COLORS[0])) + '" aria-label="更换分类颜色" title="更换颜色"></button>' +
        '<input class="mg-inline" id="catName" type="text" maxlength="12" placeholder="分类名称，回车保存" value="' + esc(val != null ? val : (c ? c.name : '')) + '" aria-label="分类名称">' +
        (c ? '<span class="dd-v">' + (catCounts()[c.id] || 0) + ' 项</span>' : '') +
        (c ? '<button type="button" class="mg-act mg-act-del" data-cat-del="' + esc(c.id) + '" aria-label="删除分类 ' + esc(c.name) + '" title="删除分类">' + SVG_TRASH + '</button>' : '') +
      '</div>' + (palOpen ? catPaletteStrip(key) : '');
  }
  function catMgrRowsHtml(editId, palId, val, dotColor) {
    var cats = DB.listCategories();
    var cnt = catCounts();
    var html = '';
    if (!cats.length && editId !== '__new') {
      html = '<div class="mg-empty">还没有分类，点下方「新建分类」给待办分个家</div>';
    }
    html += cats.map(function (c) {
      if (c.id === editId) return catRowEditorHtml(c, c.id, palId === c.id, val);
      return '<div class="dd-row mg-row" data-id="' + esc(c.id) + '">' +
        '<button type="button" class="cat-dot mg-dot" data-cat-dot="' + esc(c.id) + '" style="background:' + esc(c.color) + '" aria-label="更换分类颜色" title="更换颜色"></button>' +
        '<span class="dd-k">' + esc(c.name) + '</span>' +
        '<span class="dd-v">' + (cnt[c.id] || 0) + ' 项</span>' +
        '<button type="button" class="mg-act mg-act-del" data-cat-del="' + esc(c.id) + '" aria-label="删除分类 ' + esc(c.name) + '" title="删除分类">' + SVG_TRASH + '</button>' +
        '</div>' + (palId === c.id ? catPaletteStrip(c.id) : '');
    }).join('');
    if (editId === '__new') html += catRowEditorHtml(null, '__new', palId === '__new', val, dotColor);
    else html += '<button type="button" class="dd-row tp-mgr" data-cat-add>' +
      '<span class="dd-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></span>' +
      '<span class="dd-k">新建分类</span></button>';
    return html;
  }

  /* ---- 抽屉把手拖拽：上拉展开列表区、下拉甩关、点按切换高矮 ---- */
  /* 打开时钉住遮罩高度 = 当时的布局视口：键盘导致视口收缩时，
     叠放的下层抽屉不会被底锚联动跳位（闪帧根因之一） */
  function wpPinViewport(mask) {
    if (!window.visualViewport) return;
    mask.style.bottom = 'auto';
    mask.style.height = window.innerHeight + 'px';
  }
  function wireSheetGrab(sheet, dismiss, opts) {
    opts = opts || {};
    var expand = opts.expand !== false, tap = opts.tap !== false;
    var grab = $('.wp-grab', sheet);
    if (!grab) return;
    var list = $('.mg-inner', sheet) || $('.tp-grid', sheet) || $('.cat-list', sheet) || $('.tf-list', sheet);
    var BASE = 0.56, TALL = 0.80;
    var drag = null;
    grab.addEventListener('pointerdown', function (e) {
      if (drag) return;
      var minNow = list ? parseFloat(getComputedStyle(list).minHeight) || 0 : 0;
      drag = { y0: e.clientY, t0: Date.now(), dy: 0, moved: false, min0: minNow };
      grab.classList.add('is-on'); /* 变长走类切换配 CSS 过渡；preventDefault 会吞掉触屏 :active，靠它不稳 */
      sheet.style.transition = 'none';
      if (list) list.style.transition = 'none';
      try { grab.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    });
    grab.addEventListener('pointermove', function (e) {
      if (!drag) return;
      drag.dy = e.clientY - drag.y0;
      if (Math.abs(drag.dy) > 4) drag.moved = true;
      if (drag.dy < 0 && list && expand) {
        var tall = window.innerHeight * TALL;
        list.style.maxHeight = Math.round(Math.min(tall, Math.max(drag.min0, window.innerHeight * BASE) + -drag.dy)) + 'px';
        list.style.minHeight = Math.round(Math.min(tall, drag.min0 + -drag.dy)) + 'px';
      } else if (drag.dy < 0) {
        sheet.style.transform = 'translateY(' + Math.max(-18, drag.dy * 0.12) + 'px)'; /* 全屏态：上拉只留橡皮筋阻尼 */
      } else {
        sheet.style.transform = 'translateY(' + Math.max(0, drag.dy) + 'px)';
      }
    });
    function end() {
      if (!drag) return;
      var dy = drag.dy, dt = Math.max(1, Date.now() - drag.t0), moved = drag.moved;
      drag = null;
      grab.classList.remove('is-on');
      sheet.style.transition = '';
      if (list) list.style.transition = '';
      if (!moved) { /* 点按：高矮切换（全屏抽屉禁用） */ if (!tap) return; if (list) { list.style.maxHeight = ''; list.style.minHeight = ''; } sheet.classList.toggle('is-tall'); return; }
      var up = -dy, vel = Math.abs(dy) / dt;
      if (dy > 0) {
        if (dy > 96 || (dy > 40 && vel > 0.5)) {
          /* 甩关：本家 transform 滑出屏底（内联值盖过类过渡，不会被 close 弹回原位），再走属主收尾 */
          sheet.style.transition = 'transform .26s cubic-bezier(.4, 0, 1, 1)';
          sheet.style.transform = 'translateY(' + (sheet.offsetHeight + 24) + 'px)';
          dismiss();
          return;
        }
        sheet.style.transform = '';
      } else if (expand) {
        if (list) { list.style.maxHeight = ''; list.style.minHeight = ''; }
        sheet.classList.toggle('is-tall', up > 60 || (up > 28 && vel > 0.5));
      } else {
        sheet.style.transform = '';
      }
    }
    grab.addEventListener('pointerup', end);
    grab.addEventListener('pointercancel', end);

    /* ---- 内容区下拉关闭：列表已滚到顶再往下拖 → 跟手把整只抽屉拉下去关掉 ---- */
    if (list) {
      var pd = null;
      list.addEventListener('touchstart', function (e) {
        if (pd || drag) return;
        if (list.scrollTop > 0) return; /* 内容还能上滚，交回原生滚动 */
        if (e.target && e.target.closest && e.target.closest('input,textarea,[contenteditable]')) return; /* 别抢字段的选字/光标 */
        var t = e.touches[0];
        pd = { y0: t.clientY, dy: 0, on: false, t0: Date.now() };
      }, { passive: true });
      list.addEventListener('touchmove', function (e) {
        if (!pd) return;
        var t = e.touches[0];
        pd.dy = t.clientY - pd.y0;
        if (!pd.on) {
          if (pd.dy > 6 && list.scrollTop <= 0) { /* 到顶 + 继续下拉才接管，轻抖/上滑放行 */
            pd.on = true;
            sheet.style.transition = 'none';
            grab.classList.add('is-on');
          } else { return; }
        }
        e.preventDefault();
        list.scrollTop = 0;
        sheet.style.transform = 'translateY(' + Math.max(0, pd.dy) + 'px)';
      }, { passive: false });
      function pend() {
        if (!pd) return;
        var dy = pd.dy, dt = Math.max(1, Date.now() - pd.t0), on = pd.on;
        pd = null;
        grab.classList.remove('is-on');
        if (!on) return;
        sheet.style.transition = '';
        var vel = Math.abs(dy) / dt;
        if (dy > 96 || (dy > 40 && vel > 0.5)) { /* 与把手同款阈值：滑出屏底再走属主收尾 */
          sheet.style.transition = 'transform .26s cubic-bezier(.4, 0, 1, 1)';
          sheet.style.transform = 'translateY(' + (sheet.offsetHeight + 24) + 'px)';
          dismiss();
          return;
        }
        sheet.style.transform = '';
      }
      list.addEventListener('touchend', pend);
      list.addEventListener('touchcancel', pend);
    }
  }

  /* ---- 通用管理抽屉（手机端）：与「全部标签/全部分类」同款 .wp-mask/.wp-sheet 壳 ---- */
  var mgrSheetCtl = null;
  /* 栈顶层序：body 直接子级里最后一只 .wp-mask 才是顶（Esc 只收顶，不连坐下层） */
  function wpIsTopMask(mask) {
    var ms = $all('body > .wp-mask');
    return !!ms.length && ms[ms.length - 1] === mask;
  }
  /* 不触发浏览器原生滚动的聚焦：编辑器展开先画一帧，键盘抬升交给 kbSync 的过渡动画，
     根治「抽屉闪现到更高位置」的跳动 */
  function mgrFocusSoft(el) {
    if (!el) return;
    requestAnimationFrame(function () {
      try { el.focus({ preventScroll: true }); } catch (_) { el.focus(); }
    });
  }
  function openMgrSheet(title, inner, onReady, onClose) {
    if (mgrSheetCtl) return; /* 已有一只管理抽屉，不叠第二只 */
    /* 全屏管理抽屉自身不透明、盖满视口：下层选择抽屉原地留着不泊藏，
       关闭时直接下滑露出，不再复播一次入场；暗底由下层遮罩负责 */
    var mask = document.createElement('div');
    mask.className = document.querySelector('body > .wp-mask') ? 'wp-mask wp-mask-bare' : 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet mgr-sheet mgr-full" role="dialog" aria-modal="true" aria-label="' + esc(title) + '">' +
        '<div class="wp-grab" aria-hidden="true"></div>' +
        '<div class="mf-head">' +
          '<button type="button" class="mf-back" id="mgrBack" aria-label="返回"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m14.5 6-6 6 6 6"/></svg></button>' +
          '<div class="wp-title">' + esc(title) + '</div>' +
          '<button type="button" class="mf-done" id="mgrDone">完成</button>' +
        '</div>' +
        '<div class="mg-inner">' + inner + '</div>' +
      '</div>';
    document.body.appendChild(mask);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var msFr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收管理抽屉 */
    /* 键盘跟随：遮罩直接贴合可视视口（顶到键盘沿），底锚抽屉整体浮到键盘上方；
       再把被编辑的行滚进列表可视区，输入框永远露在键盘之上 */
    var vv = window.visualViewport;
    var sheet = $('.mgr-sheet', mask);
    function kbSync() {
      if (!vv) return;
      var h = Math.round(vv.height), top = Math.max(0, Math.round(vv.offsetTop || 0));
      mask.style.top = top + 'px';
      mask.style.height = h + 'px';
      mask.style.bottom = 'auto';
      var up = window.innerHeight - h - top >= 80;
      sheet.classList.toggle('is-kbd', up);
      if (!up) return;
      var ae = document.activeElement;
      if (ae && ae.classList && ae.classList.contains('mg-inline')) {
        requestAnimationFrame(function () {
          var cont = ae.closest('.mg-inner');
          if (!cont) return;
          var ar = ae.getBoundingClientRect(), cr = cont.getBoundingClientRect();
          if (ar.bottom > cr.bottom - 8) cont.scrollTop += ar.bottom - cr.bottom + 16;
          else if (ar.top < cr.top + 8) cont.scrollTop -= cr.top + 8 - ar.top;
        });
      }
    }
    if (vv) {
      vv.addEventListener('resize', kbSync);
      vv.addEventListener('scroll', kbSync);
    }
    kbSync();
    wireSheetGrab(sheet, function () { close(); }, { expand: false, tap: false });
    function close() {
      if (!mgrSheetCtl || mgrSheetCtl.close !== close) return;
      mgrSheetCtl = null;
      if (sheet._mgrCommit) { try { sheet._mgrCommit(); } catch (e) {} sheet._mgrCommit = null; } /* 关抽屉前兜底提交行内编辑 */
      if (msFr) { WbBack.finish(msFr); msFr = null; }
      if (vv) {
        vv.removeEventListener('resize', kbSync);
        vv.removeEventListener('scroll', kbSync);
      }
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 240);
      if (onClose) onClose(); /* 让底下的选择抽屉刷新（改名/合并/删除后不留旧片） */
    }
    function onKey(e) {
      if (e.key === 'Escape') {
        if (e.target && e.target.tagName === 'INPUT') return; /* 编辑中：Esc 交给行内取消 */
        if (!wpIsTopMask(mask)) return;
        e.preventDefault(); e.stopPropagation(); close();
      }
    }
    document.addEventListener('keydown', onKey, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    $('#mgrDone', mask).addEventListener('click', close);
    $('#mgrBack', mask).addEventListener('click', close);
    mgrSheetCtl = { close: close };
    onReady(sheet, close);
  }

  function bindCatManager(root) {
    var editingId = null;  /* null | '__new' | 分类 id */
    var palId = null;      /* 色板展开在哪一行（与改名可同键并存） */
    var curColor = CAT_COLORS[0];
    var editingVal = null; /* 切色板重绘时保住未提交的输入 */
    var rows = $('#catRows', root);

    function render(focus) {
      $('#catCnt', root).textContent = DB.listCategories().length + ' 个';
      rows.innerHTML = catMgrRowsHtml(editingId, palId, editingVal, curColor);
      if (palId) {
        var sws = $all('.mg-palette[data-pal-for="' + palId + '"] .cat-swatch', rows);
        sws.forEach(function (b) { b.classList.toggle('is-sel', b.getAttribute('data-color') === curColor); });
      }
      if (focus !== false && editingId) mgrFocusSoft($('#catName', rows));
    }
    function commit(cancel) {
      if (!editingId) return true;
      var el = $('#catName', rows);
      var name = el ? el.value.trim() : '';
      var id = editingId;
      editingId = null; palId = null; editingVal = null;
      if (cancel) { render(false); return true; }
      if (id === '__new') {
        if (!name) { render(false); return true; }
        try { DB.addCategory({ name: name, color: curColor }); }
        catch (e) { toast(e instanceof Errors.ValidationError ? e.message : '操作失败，请重试', 'error'); render(false); return false; }
      } else if (name) {
        try { DB.updateCategory(id, { name: name }); }
        catch (e) { toast(e instanceof Errors.ValidationError ? e.message : '操作失败，请重试', 'error'); render(false); return false; }
      }
      render(false);
      refreshBehind();
      return true;
    }
    root._mgrCommit = function () { commit(false); };

    rows.addEventListener('click', function (e) {
      if (e.target.closest('#catName')) return;
      var add = e.target.closest('[data-cat-add]');
      if (add) { if (commit(false)) { editingId = '__new'; curColor = CAT_COLORS[0]; render(true); } return; }
      var dot = e.target.closest('[data-cat-dot]');
      if (dot) {
        var dk = dot.getAttribute('data-cat-dot');
        if (dk !== editingId) { if (!commit(false)) return; }
        else editingVal = ($('#catName', rows) || {}).value || '';
        if (dk !== '__new' && dk !== editingId) { var cd = DB.getCategory(dk); curColor = cd ? cd.color : CAT_COLORS[0]; }
        palId = (palId === dk) ? null : dk;
        if (dk === editingId || dk === '__new') { render(true); } else { render(false); }
        return;
      }
      var sw = e.target.closest('.cat-swatch');
      if (sw) {
        var pk = e.target.closest('[data-pal-for]');
        var key = pk ? pk.getAttribute('data-pal-for') : null;
        var color = sw.getAttribute('data-color');
        if (!key) return;
        if (key === '__new') { curColor = color; render(true); return; }
        var nm = key === editingId && $('#catName', rows) ? $('#catName', rows).value.trim() : '';
        try { DB.updateCategory(key, nm ? { color: color, name: nm } : { color: color }); }
        catch (err) { toast(err instanceof Errors.ValidationError ? err.message : '操作失败，请重试', 'error'); return; }
        editingId = null; palId = null; editingVal = null;
        render(false); refreshBehind();
        return;
      }
      var del = e.target.closest('[data-cat-del]');
      if (del) {
        if (!commit(false)) return;
        var c = DB.getCategory(del.getAttribute('data-cat-del'));
        if (!c) return;
        confirmModal({
          title: '删除分类',
          message: '删除分类「' + esc(c.name) + '」？其下 ' + (catCounts()[c.id] || 0) + ' 项待办将移回「未分类」。',
          okText: '删除',
          danger: true,
          onOk: function () {
            DB.removeCategory(c.id);
            if (state.todoCat === c.id) state.todoCat = '';
            refreshBehind();
            render(false); /* 原位刷新，不再关卡重开 */
          }
        });
        return;
      }
      var row = e.target.closest('.mg-row[data-id]');
      if (!row) return;
      var id = row.getAttribute('data-id');
      if (id === editingId) return;
      if (!commit(false)) return;
      editingId = id; palId = null; editingVal = null;
      var cat = DB.getCategory(id);
      curColor = cat ? cat.color : CAT_COLORS[0];
      render(true);
    });
    rows.addEventListener('keydown', function (e) {
      if (e.target.id !== 'catName') return;
      if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); commit(false); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); commit(true); }
    });
    render(false);
  }

  function openCatManager(opts) {
    opts = opts || {};
    var inner =
      '<div class="dd-row tb-head"><span class="dd-ico">' + CAT_MGR_ICO + '</span>' +
        '<span class="dd-k">全部分类</span><span class="dd-v" id="catCnt"></span></div>' +
      '<div id="catRows"></div>';
    if (wbCoarse()) {
      openMgrSheet('分类管理', inner, function (sheet) { bindCatManager(sheet); }, opts.onSheetClose);
      return;
    }
    Modal.open({
      title: '分类管理',
      cls: 'dd-modal',
      body: '<div class="dd-group">' + inner + '</div>',
      actions: [
        { text: '完成', className: 'btn-primary', primary: true, onClick: function () { Modal.close(); renderAll(); } }
      ]
    });
    bindCatManager(Modal.card);
  }

  /* ============================================================
     标签管理（行级直改 · 样板）：点行即改，名称变常驻行内输入，
     回车/切行提交、Esc 取消、关抽屉兜底提交；行尾只留删除。
     ============================================================ */
  var TAG_ICO_SVG = '<span class="dd-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.4"/></svg></span>';

  function tagMgrRowsHtml(renaming) {
    var tags = DB.memoTags();
    if (!tags.length) {
      return '<div class="mg-empty">还没有标签，在备忘里输入标签后就会出现在这里</div>';
    }
    return tags.map(function (t) {
      var del = '<button type="button" class="mg-act mg-act-del" data-tag-del="' + esc(t.name) + '" aria-label="删除标签 ' + esc(t.name) + '" title="删除标签">' + SVG_TRASH + '</button>';
      if (t.name === renaming) {
        return '<div class="dd-row mg-row is-editing" data-tag="' + esc(t.name) + '">' +
          '<input class="mg-inline" id="tagNew" type="text" maxlength="16" value="' + esc(t.name) + '" aria-label="重命名标签，回车保存">' +
          '<span class="dd-v">' + t.count + ' 条</span>' + del + '</div>';
      }
      return '<div class="dd-row mg-row" data-tag="' + esc(t.name) + '">' +
        '<span class="tag">' + esc(t.name) + '</span>' +
        '<span class="dd-v">' + t.count + ' 条</span>' + del + '</div>';
    }).join('');
  }

  function bindTagManager(root) {
    var renaming = null;
    var rows = $('#tagRows', root);

    function render(focus) {
      var tags = DB.memoTags();
      $('#tagCnt', root).textContent = tags.length + ' 个';
      rows.innerHTML = tagMgrRowsHtml(renaming);
      if (focus !== false) mgrFocusSoft($('#tagNew', rows));
    }
    function commit(cancel) {
      if (!renaming) return;
      var from = renaming;
      var el = $('#tagNew', rows);
      var to = el ? el.value.trim() : '';
      renaming = null; /* 先清标志，防 Enter+blur 双提交 */
      if (!cancel && to && to !== from) {
        try { DB.renameTag(from, to); }
        catch (e) { toast(e.message || '操作失败，请重试', 'error'); render(false); return; }
        if (state.memoTags.indexOf(from) !== -1) {
          state.memoTags = state.memoTags.map(function (t) { return t === from ? to : t; });
        }
        render(false);
        refreshBehind();
        toast('已应用：' + from + ' → ' + to);
        return;
      }
      render(false);
    }
    root._mgrCommit = function () { commit(false); }; /* 关抽屉兜底：未回车也提交 */

    rows.addEventListener('click', function (e) {
      var del = e.target.closest('[data-tag-del]');
      if (del) {
        commit(false); /* 切去删除前先提交当前编辑 */
        var name = del.getAttribute('data-tag-del');
        confirmModal({
          title: '删除标签',
          message: '从所有备忘中移除标签「' + esc(name) + '」？备忘本身不会被删除。',
          okText: '删除',
          danger: true,
          onOk: function () {
            DB.deleteTag(name);
            state.memoTags = state.memoTags.filter(function (t) { return t !== name; });
            refreshBehind();
            render(false); /* 原位刷新，不再关卡重开 */
          }
        });
        return;
      }
      if (e.target.closest('#tagNew')) return;
      var row = e.target.closest('.mg-row[data-tag]');
      if (!row) return;
      var tag = row.getAttribute('data-tag');
      if (tag === renaming) return;
      commit(false);
      renaming = tag;
      render(true);
    });
    rows.addEventListener('keydown', function (e) {
      if (e.target.id !== 'tagNew') return;
      if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); commit(false); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); commit(true); }
    });
    render(false);
  }

  function openTagManager(opts) {
    opts = opts || {};
    var inner =
      '<div class="dd-row tb-head">' + TAG_ICO_SVG +
        '<span class="dd-k">全部标签</span><span class="dd-v" id="tagCnt"></span></div>' +
      '<div id="tagRows"></div>' +
      '<div class="tb-tip">点一下标签名即可改名，回车保存；改成已有标签名会自动合并</div>';
    if (wbCoarse()) {
      openMgrSheet('标签管理', inner, function (sheet) { bindTagManager(sheet); }, opts.onSheetClose);
      return;
    }
    Modal.open({
      title: '标签管理',
      cls: 'dd-modal',
      body: '<div class="dd-group">' + inner + '</div>',
      actions: [
        { text: '完成', className: 'btn-primary', primary: true, onClick: function () { Modal.close(); renderAll(); } }
      ]
    });
    bindTagManager(Modal.card);
  }

  /* ============================================================
     标签条横滑增强 + 全部标签浮层
     ============================================================ */
  function tagBarFade(sc) {
    var over = sc.scrollWidth - sc.clientWidth;
    sc.classList.toggle('tgf-l', sc.scrollLeft > 2);
    sc.classList.toggle('tgf-r', over > 2 && sc.scrollLeft < over - 2);
  }
  var tagBarResizeBound = false;
  function chipRailEnhance(scId) {
    var sc = document.getElementById(scId);
    if (!sc) return;
    if (!tagBarResizeBound) {
      tagBarResizeBound = true;
      window.addEventListener('resize', function () {
        ['memoChipScroll', 'todoChipScroll', 'dateChipScroll', 'ovQuick'].forEach(function (i) {
          var s = document.getElementById(i); if (s) tagBarFade(s);
        });
      });
    }
    /* 有选中标签时把它滚到可视区中部（未溢出不打扰） */
    var act = sc.querySelector('.chip.active');
    var over = sc.scrollWidth - sc.clientWidth;
    if (act && act !== sc.querySelector('.chip') && over > 0) {
      sc.scrollLeft = Math.max(0, Math.min(over, act.offsetLeft - (sc.clientWidth - act.offsetWidth) / 2));
    }
    tagBarFade(sc);
    sc.addEventListener('scroll', function () { tagBarFade(sc); }, { passive: true });
    /* 桌面鼠标滚轮：纵向滚动转横滑 */
    sc.addEventListener('wheel', function (e) {
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX) && sc.scrollWidth > sc.clientWidth) {
        e.preventDefault();
        sc.scrollLeft += e.deltaY;
      }
    }, { passive: false });
  }

  function tagPickHtml() {
    var tags = DB.memoTags();
    if (!tags.length) return '<div class="tag-pick-empty">还没有标签，在备忘里输入标签后即可在这里筛选</div>';
    return tags.map(function (t) {
      return '<button type="button" class="chip' + (state.memoTags.indexOf(t.name) !== -1 ? ' active' : '') + '" data-tag="' + esc(t.name) + '">' +
        esc(t.name) + '<span class="chip-cnt">' + t.count + '</span></button>';
    }).join('');
  }
  function openTagPicker() {
    if (wbCoarse()) { openTagPickerSheet(); return; }
    Modal.open({
      title: '全部标签',
      cls: 'dd-modal',
      body:
        '<div class="dd-group">' +
          '<div class="tag-pick-head" id="tpHead">' +
            '<span class="tag-pick-cap">点击筛选，再点取消，可多选</span>' +
            '<button type="button" class="btn-link" id="tpClear">清空已选</button>' +
          '</div>' +
          '<div class="tag-pick" id="tagPick">' + tagPickHtml() + '</div>' +
          '<button type="button" class="dd-row tp-mgr" id="tpMgr">' +
            '<span class="dd-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.4"/></svg></span>' +
            '<span class="dd-k">重命名 / 合并 / 删除标签</span>' +
            '<span class="tp-chev" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg></span>' +
          '</button>' +
        '</div>'
    });
    var grid = $('#tagPick', Modal.card);
    var head = $('#tpHead', Modal.card);
    function sync() {
      grid.innerHTML = tagPickHtml();
      head.classList.toggle('no-sel', !state.memoTags.length);
      renderMemos();
    }
    head.classList.toggle('no-sel', !state.memoTags.length);
    grid.addEventListener('click', function (e) {
      var chip = e.target.closest('.chip[data-tag]');
      if (!chip) return;
      var t = chip.getAttribute('data-tag');
      var i = state.memoTags.indexOf(t);
      if (i === -1) state.memoTags.push(t); else state.memoTags.splice(i, 1);
      sync();
    });
    $('#tpClear', Modal.card).addEventListener('click', function () {
      if (!state.memoTags.length) return;
      state.memoTags = [];
      sync();
    });
    $('#tpMgr', Modal.card).addEventListener('click', function () { openTagManager(); });
  }

  /* 手机端「全部标签」：与滚轮时间选择器同款底部抽屉（.wp-mask/.wp-sheet 一套
     骨架与动效参数），网格区 56vh 比滚轮窗更高；筛选实时生效，点穿遮罩/返回可关 */
  var tpSheetOpen = false;
  function openTagPickerSheet() {
    if (tpSheetOpen) return;
    tpSheetOpen = true;
    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet tp-sheet" role="dialog" aria-modal="true" aria-label="全部标签">' +
        '<div class="wp-grab" aria-hidden="true"></div>' +
        '<div class="wp-title">全部标签</div>' +
        '<div class="tp-grid" id="tpsGrid">' + tagPickHtml() + '</div>' +
        '<button type="button" class="tf-row tps-mgr" id="tpsMgr">' +
          '<span class="dd-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z"/><circle cx="7.5" cy="7.5" r="1.4"/></svg></span>' +
          '<span class="tf-name">重命名 / 合并 / 删除标签</span>' +
          '<span class="tp-chev" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg></span>' +
        '</button>' +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-cancel" id="tpsClear">清空已选</button>' +
          '<button type="button" class="wp-btn wp-btn-ok" id="tpsDone">完成</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var tpsFr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收标签筛选 */
    wpPinViewport(mask);
    wireSheetGrab($('.wp-sheet', mask), function () { close(); });

    var grid = $('#tpsGrid', mask);
    var clearBtn = $('#tpsClear', mask);
    function sync() {
      grid.innerHTML = tagPickHtml();
      clearBtn.classList.toggle('is-off', !state.memoTags.length);
      renderMemos(); /* 抽屉只占下半屏，列表筛选在背后实时可见 */
    }
    clearBtn.classList.toggle('is-off', !state.memoTags.length);

    function close() {
      if (!tpSheetOpen) return;
      tpSheetOpen = false;
      if (tpsFr) { WbBack.finish(tpsFr); tpsFr = null; }
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 240);
    }
    function onKey(e) { if (e.key === 'Escape') { if (!wpIsTopMask(mask)) return; e.preventDefault(); e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });

    grid.addEventListener('click', function (e) {
      var chip = e.target.closest('.chip[data-tag]');
      if (!chip) return;
      var t = chip.getAttribute('data-tag');
      var i = state.memoTags.indexOf(t);
      if (i === -1) state.memoTags.push(t); else state.memoTags.splice(i, 1);
      sync();
    });
    clearBtn.addEventListener('click', function () {
      if (!state.memoTags.length) return;
      state.memoTags = [];
      sync();
    });
    $('#tpsDone', mask).addEventListener('click', close);
    $('#tpsMgr', mask).addEventListener('click', function () {
      /* 管理抽屉直接叠在本抽屉之上（透明遮罩，单层上移动画），关闭管理后回本抽屉并刷新 */
      openTagManager({ onSheetClose: sync });
    });
  }

  /* ============================================================
     全部分类（待办）：与备忘标签同款浮层，单选、点一下即筛选
     ============================================================ */
  var CAT_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7"/></svg>';
  var CAT_MGR_ICO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h7.5M16.5 8H20M4 16h2.5M11 16h9"/><circle cx="14" cy="8" r="2.2"/><circle cx="8.5" cy="16" r="2.2"/></svg>';
  var CAT_CHEV = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg>';

  function catPickHtml() {
    var all = DB.listTodos('all');
    var cats = DB.listCategories();
    function row(val, dot, name, n) {
      var on = state.todoCat === val;
      return '<button type="button" class="tf-row' + (on ? ' is-sel' : '') + '" data-cat="' + esc(val) + '">' +
        dot + '<span class="tf-name">' + esc(name) + '</span>' +
        '<span class="tf-cnt">' + n + '</span>' +
        (on ? '<span class="tf-check">' + CAT_CHECK + '</span>' : '') + '</button>';
    }
    var html = row('', '<span class="tf-dot tf-dot-all"></span>', '全部', all.length);
    cats.forEach(function (c) {
      html += row(c.id, '<span class="tf-dot" style="background:' + esc(c.color) + '"></span>', c.name,
        all.filter(function (t) { return t.category === c.id; }).length);
    });
    html += row('none', '<span class="tf-dot tf-dot-all"></span>', '未分类',
      all.filter(function (t) { return !t.category; }).length);
    return html;
  }
  function catMgrRow(id, desk) {
    var inner = '<span class="dd-ico">' + CAT_MGR_ICO + '</span>' +
      '<span class="' + (desk ? 'dd-k' : 'tf-name') + '">新建 / 改名 / 删除分类</span>' +
      '<span class="tp-chev" aria-hidden="true">' + CAT_CHEV + '</span>';
    return desk
      ? '<button type="button" class="dd-row tp-mgr" id="' + id + '">' + inner + '</button>'
      : '<button type="button" class="tf-row tps-mgr" id="' + id + '">' + inner + '</button>';
  }
  function bindCatPick(listEl, onPick) {
    listEl.addEventListener('click', function (e) {
      var row = e.target.closest('.tf-row[data-cat]');
      if (!row) return;
      state.todoCat = row.getAttribute('data-cat');
      renderTodos(); /* 内部会重画分类条 + 列表，背后实时可见 */
      listEl.innerHTML = catPickHtml();
      if (onPick) onPick();
    });
  }

  function openCatPicker() {
    if (wbCoarse()) { openCatPickerSheet(); return; }
    Modal.open({
      title: '全部分类',
      cls: 'dd-modal',
      body:
        '<div class="dd-group">' +
          '<div class="tf-list cat-list" id="catPick">' + catPickHtml() + '</div>' +
          catMgrRow('catMgrDesk', true) +
        '</div>'
    });
    bindCatPick($('#catPick', Modal.card));
    $('#catMgrDesk', Modal.card).addEventListener('click', function () { openCatManager(); });
  }

  var catSheetOpen = false;
  function openCatPickerSheet() {
    if (catSheetOpen) return;
    catSheetOpen = true;
    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet tp-sheet" role="dialog" aria-modal="true" aria-label="全部分类">' +
        '<div class="wp-grab" aria-hidden="true"></div>' +
        '<div class="wp-title">全部分类</div>' +
        '<div class="tf-list cat-list" id="catSheetList">' + catPickHtml() + '</div>' +
        catMgrRow('catSheetMgr') +
        '<div class="wp-foot">' +
          '<button type="button" class="wp-btn wp-btn-ok" id="catSheetDone">完成</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(mask);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var csFr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收分类筛选 */
    wpPinViewport(mask);
    wireSheetGrab($('.wp-sheet', mask), function () { close(); });

    var list = $('#catSheetList', mask);
    function close() {
      if (!catSheetOpen) return;
      catSheetOpen = false;
      if (csFr) { WbBack.finish(csFr); csFr = null; }
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 240);
    }
    function onKey(e) { if (e.key === 'Escape') { if (!wpIsTopMask(mask)) return; e.preventDefault(); e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    bindCatPick(list);
    $('#catSheetDone', mask).addEventListener('click', close);
    $('#catSheetMgr', mask).addEventListener('click', function () {
      /* 同标签抽屉：管理叠开，关闭后刷新选择列表（分类可能已改名/删除） */
      openCatManager({ onSheetClose: function () { list.innerHTML = catPickHtml(); } });
    });
  }

  /* ============================================================
     备忘视图
     ============================================================ */
  var SVG_PIN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/></svg>';

  function rowMemo(m) {
    var tags = (m.tags || []).map(function (t) {
      return '<span class="tag">' + esc(t) + '</span>';
    }).join('');
    var time = '创建于 ' + fmtDateTime(m.createdAt);
    if (m.updatedAt && m.updatedAt !== m.createdAt) {
      time += ' · 更新于 ' + fmtDateTime(m.updatedAt);
    }
    return '<article class="memo-card' + (m.pinned ? ' is-pinned' : '') + '" data-id="' + esc(m.id) + '">' +
      '<div class="memo-head">' +
        '<h3 class="memo-title" title="' + esc(m.title) + '">' + esc(m.title) + '</h3>' +
        '<button type="button" class="memo-pin' + (m.pinned ? ' on' : '') + '" data-memo-pin="' + esc(m.id) + '" aria-label="' + (m.pinned ? '取消置顶' : '置顶') + '" title="' + (m.pinned ? '取消置顶' : '置顶') + '">' + SVG_PIN + '</button>' +
      '</div>' +
      '<div class="memo-content">' + esc(m.content || '（无内容）') + '</div>' +
      (tags ? '<div class="memo-tags">' + tags + '</div>' : '') +
      '<div class="memo-foot">' + (m.pinned ? '<span class="pin-mark">置顶</span> · ' : '') + time + '</div>' +
    '</article>';
  }

  function renderMemos(animate) {
    var list = DB.listMemos();

    /* 标签筛选条：单行横滑（收纳溢出标签）+ 固定「全部标签」浮层入口 */
    var tags = DB.memoTags();
    var bar = $('#memoTagBar');
    var chips = '<button type="button" class="chip' + (!state.memoTags.length ? ' active' : '') + '" data-tag="">全部<span class="chip-cnt">' + list.length + '</span></button>';
    tags.forEach(function (t) {
      chips += '<button type="button" class="chip' + (state.memoTags.indexOf(t.name) !== -1 ? ' active' : '') + '" data-tag="' + esc(t.name) + '">' +
        esc(t.name) + '<span class="chip-cnt">' + t.count + '</span></button>';
    });
    bar.innerHTML =
      '<div class="chip-scroll" id="memoChipScroll">' + chips + '</div>' +
      '<button type="button" class="chip chip-more" data-tag-all title="全部标签" aria-label="查看全部标签">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>' +
        '全部标签<span class="chip-cnt">' + tags.length + '</span></button>';
    chipRailEnhance('memoChipScroll');

    if (state.memoTags.length) {
      list = list.filter(function (m) {
        return state.memoTags.some(function (t) { return (m.tags || []).indexOf(t) !== -1; });
      });
    }
    var q = state.memoSearch.trim().toLowerCase();
    if (q) {
      list = list.filter(function (m) {
        return (m.title + '\n' + (m.content || '') + '\n' + (m.tags || []).join(' ')).toLowerCase().indexOf(q) !== -1;
      });
    }

    var grid = $('#memoGrid');
    staggerList(grid, animate);
    var empty = $('#memoEmpty');
    if (!list.length) {
      grid.innerHTML = '';
      if (q) {
        empty.innerHTML = emptyHtml(true, '备忘');
      } else if (state.memoTags.length) {
        empty.innerHTML = emptyHtml(false, '备忘', '所选标签下还没有备忘，新建一条并打上标签吧', 'memo');
      } else {
        empty.innerHTML = emptyHtml(false, '备忘', '还没有备忘，把灵感随手记下来吧', 'memo');
      }
      empty.hidden = false;
      return;
    }
    empty.hidden = true;
    grid.innerHTML = list.map(rowMemo).join('');
  }

  /* 备忘表单弹窗（Markdown 编辑 / 预览双模式 + 置顶） */
  function openMemoForm(item, opts) {
    var isEdit = !!item;

    Modal.open({
      dirtyGuard: true,
      title: isEdit ? '编辑备忘' : '新建备忘',
      afterClose: opts && opts.back, /* 挂 back：取消/X/Esc/遮罩/保存全路径返回详情 */
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        '<div class="field" data-fg="t">' +
          '<label for="f-title">标题<span class="req">*</span></label>' +
          '<input class="form-input" id="f-title" type="text" maxlength="200" value="' + esc(item ? item.title : '') + '" placeholder="备忘标题">' +
        '</div>' +
        '<div class="field" data-fg="c">' +
          '<div class="md-field-head">' +
            '<label for="f-content">内容</label>' +
            '<div class="seg md-seg" role="tablist">' +
              '<button type="button" class="active" data-mdtab="edit">编辑</button>' +
              '<button type="button" data-mdtab="preview">预览</button>' +
            '</div>' +
          '</div>' +
          '<textarea class="form-input" id="f-content" rows="7" maxlength="20000" placeholder="支持 Markdown：# 标题 · - 列表 · **加粗**">' + esc(item ? item.content : '') + '</textarea>' +
          '<div class="md-body" id="f-mdprev" hidden></div>' +
        '</div>' +
        '<div class="field" data-fg="m">' +
          '<label for="f-tags">标签</label>' +
          '<input class="form-input" id="f-tags" type="text" maxlength="200" value="' + esc(item ? (item.tags || []).join(', ') : '') + '" placeholder="逗号分隔，如：灵感, 工作">' +
        '</div>' +
        '<label class="check-line" data-fg="m"><input type="checkbox" id="f-pin"' + (item && item.pinned ? ' checked' : '') + '><span>置顶显示</span></label>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        isEdit ? {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('备忘', item.title, function () { DB.deleteMemo(item.id); });
          }
        } : null,
        { text: '取消', className: 'btn-default' },
        {
          text: isEdit ? '保存修改' : '创建',
          className: 'btn-primary', primary: true,
          onClick: function () {
            var card = Modal.card;
            var title = $('#f-title', card).value.trim();
            var content = $('#f-content', card).value;
            var tags = $('#f-tags', card).value
              .split(/[,，、\s]+/)
              .map(function (s) { return s.trim(); })
              .filter(Boolean);
            var pinned = $('#f-pin', card).checked;
            if (!title) { showFormError('请填写备忘标题', 'f-title'); return; }
            try {
              if (isEdit) DB.updateMemo(item.id, { title: title, content: content, tags: tags, pinned: pinned });
              else DB.addMemo({ title: title, content: content, tags: tags, pinned: pinned });
            } catch (e) {
              if (e instanceof Errors.QuotaError) { quotaModal(); return; }
              if (e instanceof Errors.ValidationError) { showFormError(e.message); return; }
              toast('操作失败，请重试', 'error'); return;
            }
            Modal.markClean();
            Modal.close();
            toast(isEdit ? '备忘已更新' : '备忘已创建');
            renderView('memo');
            if (isEdit && !(opts && opts.back)) openMemoDetail(DB.getMemo(item.id)); /* 回到详情（从详情进入时由 afterClose 统一返回） */
          }
        }
      ].filter(Boolean)
    });
    mobFormify();

    /* Markdown 编辑 / 预览切换 */
    var ta = $('#f-content', Modal.card);
    var prev = $('#f-mdprev', Modal.card);
    $all('.seg [data-mdtab]', Modal.card).forEach(function (tab) {
      tab.addEventListener('click', function () {
        $all('.seg [data-mdtab]', Modal.card).forEach(function (t) { t.classList.toggle('active', t === tab); });
        var mode = tab.getAttribute('data-mdtab');
        if (mode === 'preview') {
          prev.hidden = false;
          ta.hidden = true;
          var render = function () { prev.innerHTML = mdToHtml(ta.value) || '<span class="md-empty-hint">（暂无内容）</span>'; };
          if (typeof window.marked !== 'undefined' && window.marked.parse) {
            render();
          } else {
            /* 组件未就绪：提示加载中并惰性重载，失败再显示原文 */
            prev.innerHTML = '<p class="md-warn">正在加载 Markdown 渲染组件…</p>';
            ensureMarked(function (ok) { render(); });
          }
        } else {
          prev.hidden = true;
          ta.hidden = false;
          ta.focus();
        }
      });
    });
  }

  /* ============================================================
     重要日子视图
     ============================================================ */
  function rowDate(ev) {
    var days = ev.days;
    var soon = days !== null && days >= 0 && days <= 7;
    var isToday = days === 0;
    var past = days !== null && days < 0;

    /* 三层信息：名称（类型圆点）/ 属性文字 / 时间语境；右侧数字区与标签不重复语义 */
    var tm = typeMeta(ev.type);
    var attrs = [tm.label];
    attrs.push(ev.repeat ? '每年重复' : '一次性');
    if (ev.lunar) attrs.push('农历');
    var anniv = anniversaryCount(ev.date);
    if (anniv !== null) attrs.push(ev.type === 'birthday' ? anniv + ' 岁' : (anniv === 0 ? '第一年' : anniv + ' 周年'));

    var thisYear = String(new Date().getFullYear());
    var when;
    if (ev.repeat) {
      var nl = ev.lunar && window.Lunar ? Lunar.solarToLunar(ev.nextDate) : null;
      var nextTxt = nl ? '农历' + Lunar.fullText(nl)
        : (String(ev.nextDate).slice(0, 4) === thisYear ? mdCN(ev.nextDate) : fmtDate(ev.nextDate));
      when = '下次 ' + nextTxt + ' · ' + weekdayCN(ev.nextDate);
    } else if (past) {
      when = fmtDate(ev.date) + ' · ' + weekdayCN(ev.date);
    } else {
      var fl = ev.lunar && window.Lunar ? Lunar.solarToLunar(ev.date) : null;
      when = fmtDate(ev.date) + ' · ' + weekdayCN(ev.date) + (fl ? ' · 农历' + Lunar.fullText(fl) : '');
    }

    var num, label, cls = '';
    if (days === null) { num = '—'; label = '日期无效'; }
    else if (isToday) { num = '0'; label = '就是今天'; cls = ' is-today'; }
    else if (days > 0) { num = String(days); label = '天后'; }
    else { num = String(-days); label = '天前'; }

    return '<article class="date-card' + (soon ? ' is-soon' : '') + (past ? ' is-past' : '') + cls + '" data-id="' + esc(ev.id) + '">' +
      '<div class="date-info">' +
        '<div class="date-title"><span class="dd-dot" style="background:' + esc(tm.color) + '"></span><span class="date-name">' + esc(ev.name) + '</span></div>' +
        '<div class="date-attrs">' + attrs.join(' · ') + '</div>' +
        '<div class="date-when">' + when + '</div>' +
        (ev.note ? '<div class="date-note" title="' + esc(ev.note) + '">' + esc(ev.note) + '</div>' : '') +
      '</div>' +
      '<div class="date-count">' +
        '<div><span class="count-num">' + num + '</span><span class="count-unit">天</span></div>' +
        '<div class="count-label">' + label + '</div>' +
        (ev.showSince && ev.since !== null && !past ? '<div class="count-since">至今 ' + ev.since + ' 天</div>' : '') +
      '</div>' +
    '</article>';
  }

  function renderDates(animate) {
    var list = DB.listSpecial();

    /* 兼容历史持久化的 'all' → '' */
    if (state.dateFilter === 'all') state.dateFilter = '';
    renderDateTypeBar();

    var fType = state.dateFilter, filterName = '', active = false;
    if (fType === 'birthday' || fType === 'anniversary') {
      list = list.filter(function (e) { return e.type === fType; });
      filterName = typeMeta(fType).label; active = true;
    } else if (fType) {
      var ct = DB.getEventType(fType);
      if (ct) { list = list.filter(function (e) { return e.type === fType; }); filterName = ct.name; active = true; }
      else { state.dateFilter = ''; renderDateTypeBar(); }
    }

    var q = state.dateSearch.trim().toLowerCase();
    if (q) {
      list = list.filter(function (e) {
        return (e.name + '\n' + (e.note || '')).toLowerCase().indexOf(q) !== -1;
      });
    }

    var wrap = $('#dateList');
    staggerList(wrap, animate);
    var empty = $('#dateEmpty');
    if (!list.length) {
      wrap.innerHTML = '';
      if (q) {
        empty.innerHTML = emptyHtml(true, '纪念日');
      } else if (active) {
        empty.innerHTML = emptyHtml(false, '纪念日', '「' + esc(filterName) + '」下还没有日子，添加一个吧', 'date');
      } else {
        empty.innerHTML = emptyHtml(false, '纪念日', '近期没有值得纪念的日子，添加一个吧', 'date');
      }
      empty.hidden = false;
      return;
    }
    empty.hidden = true;
    wrap.innerHTML = list.map(rowDate).join('');
  }

  /* 类型筛选条：与待办分类 / 备忘标签同款 —— 单行横滑 chip + 固定「全部类型」浮层入口 */
  function renderDateTypeBar() {
    var bar = $('#dateTypeBar');
    if (!bar) return;
    var all = DB.listSpecial();
    var types = eventTypes();
    var cnt = eventTypeCounts();
    var chips = '<button type="button" class="chip' + (!state.dateFilter ? ' active' : '') + '" data-type="">全部<span class="chip-cnt">' + all.length + '</span></button>';
    types.forEach(function (t) {
      chips += '<button type="button" class="chip' + (state.dateFilter === t.val ? ' active' : '') + '" data-type="' + esc(t.val) + '">' +
        catDot({ color: t.color }) + esc(t.name) + '<span class="chip-cnt">' + (cnt[t.val] || 0) + '</span></button>';
    });
    bar.innerHTML =
      '<div class="chip-scroll" id="dateChipScroll">' + chips + '</div>' +
      '<button type="button" class="chip chip-more" data-type-all title="全部类型" aria-label="查看全部类型">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>' +
        '全部类型<span class="chip-cnt">' + types.length + '</span></button>';
    chipRailEnhance('dateChipScroll');
  }

  /* 全部类型：与待办分类 / 备忘标签同款浮层，单选、点一下即筛选；管理入口新建/改名/上色/删除自定义类型 */
  var TYPE_ICO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9h16M4 15h16M8 5v14M16 5v14"/></svg>';
  var TYPE_CHEV = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg>';

  function typePickHtml() {
    var all = DB.listSpecial();
    var cnt = eventTypeCounts();
    function row(val, dot, name, n) {
      var on = state.dateFilter === val;
      return '<button type="button" class="tf-row' + (on ? ' is-sel' : '') + '" data-type="' + esc(val) + '">' +
        dot + '<span class="tf-name">' + esc(name) + '</span><span class="tf-cnt">' + n + '</span>' +
        (on ? '<span class="tf-check">' + CAT_CHECK + '</span>' : '') + '</button>';
    }
    var html = row('', '<span class="tf-dot tf-dot-all"></span>', '全部', all.length);
    eventTypes().forEach(function (t) {
      html += row(t.val, '<span class="tf-dot" style="background:' + esc(t.color) + '"></span>', t.name, cnt[t.val] || 0);
    });
    return html;
  }
  function typeMgrRow(id) {
    return '<button type="button" class="tf-row tps-mgr" id="' + id + '">' +
      '<span class="dd-ico">' + TYPE_ICO + '</span><span class="tf-name">新建 / 改名 / 删除类型</span>' +
      '<span class="tp-chev" aria-hidden="true">' + TYPE_CHEV + '</span></button>';
  }
  function bindTypePick(listEl) {
    listEl.addEventListener('click', function (e) {
      var row = e.target.closest('.tf-row[data-type]');
      if (!row) return;
      state.dateFilter = row.getAttribute('data-type');
      renderDates();
      listEl.innerHTML = typePickHtml();
    });
  }
  function openTypePicker() {
    if (wbCoarse()) { openTypeSheet(); return; }
    Modal.open({
      title: '全部类型',
      cls: 'dd-modal',
      body:
        '<div class="dd-group">' +
          '<div class="tf-list" id="typePick">' + typePickHtml() + '</div>' +
          '<button type="button" class="dd-row tp-mgr" id="typeMgrDesk"><span class="dd-ico">' + TYPE_ICO + '</span>' +
            '<span class="dd-k">新建 / 改名 / 删除类型</span><span class="tp-chev" aria-hidden="true">' + TYPE_CHEV + '</span></button>' +
        '</div>'
    });
    bindTypePick($('#typePick', Modal.card));
    $('#typeMgrDesk', Modal.card).addEventListener('click', function () { openTypeManager(); });
  }
  var typeSheetOpen = false;
  function openTypeSheet() {
    if (typeSheetOpen) return;
    typeSheetOpen = true;
    var mask = document.createElement('div');
    mask.className = 'wp-mask';
    mask.innerHTML =
      '<div class="wp-sheet tp-sheet" role="dialog" aria-modal="true" aria-label="全部类型">' +
        '<div class="wp-grab" aria-hidden="true"></div>' +
        '<div class="wp-title">全部类型</div>' +
        '<div class="tf-list" id="typeSheetList">' + typePickHtml() + '</div>' +
        typeMgrRow('typeSheetMgr') +
        '<div class="wp-foot"><button type="button" class="wp-btn wp-btn-ok" id="typeSheetDone">完成</button></div>' +
      '</div>';
    document.body.appendChild(mask);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    var tfsFr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收类型筛选 */
    wpPinViewport(mask);
    wireSheetGrab($('.wp-sheet', mask), function () { close(); });
    var list = $('#typeSheetList', mask);
    function close() {
      if (!typeSheetOpen) return;
      typeSheetOpen = false;
      if (tfsFr) { WbBack.finish(tfsFr); tfsFr = null; }
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 240);
    }
    function onKey(e) { if (e.key === 'Escape') { if (!wpIsTopMask(mask)) return; e.preventDefault(); e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    mask.addEventListener('pointerdown', function (e) { if (e.target === mask) e.stopPropagation(); });
    bindTypePick(list);
    $('#typeSheetDone', mask).addEventListener('click', close);
    $('#typeSheetMgr', mask).addEventListener('click', function () {
      /* 管理抽屉叠开在本抽屉之上（透明顶罩），关闭管理后刷新类型列表 */
      openTypeManager({ onSheetClose: function () { list.innerHTML = typePickHtml(); } });
    });
  }

  /* 类型管理 · 行级直改（同分类管理）：内置生日/纪念日只读；自定义类型点行改名、
     点色点展开迷你色板选中即存；尾行「新建类型」点开即打字，回车落库 */
  function typePaletteStrip(key) {
    return '<div class="mg-palette" data-pal-for="' + esc(key) + '"><div class="cat-palette">' + catPaletteHtml(null) + '</div></div>';
  }
  function typeRowEditorHtml(t, key, palOpen, val, dotColor) {
    var cnt = eventTypeCounts();
    return '<div class="dd-row mg-row is-editing" data-id="' + esc(key) + '">' +
        '<button type="button" class="cat-dot mg-dot" id="typeEditDot" data-type-dot="' + esc(key) + '" style="background:' + esc(dotColor || (t ? t.color : CAT_COLORS[0])) + '" aria-label="更换类型颜色" title="更换颜色"></button>' +
        '<input class="mg-inline" id="typeName" type="text" maxlength="12" placeholder="类型名称，回车保存" value="' + esc(val != null ? val : (t ? t.name : '')) + '" aria-label="类型名称">' +
        (t ? '<span class="dd-v">' + (cnt[t.id] || 0) + ' 条</span>' : '') +
        (t ? '<button type="button" class="mg-act mg-act-del" data-type-del="' + esc(t.id) + '" aria-label="删除类型 ' + esc(t.name) + '" title="删除类型">' + SVG_TRASH + '</button>' : '') +
      '</div>' + (palOpen ? typePaletteStrip(key) : '');
  }
  function typeMgrRowsHtml(editId, palId, val, dotColor) {
    var customs = DB.listEventTypes();
    var cnt = eventTypeCounts();
    var html = '<div class="dd-row mg-row mg-row-builtin">' +
      catDot({ color: '#FE2C55' }) + '<span class="dd-k">生日</span><span class="dd-v">' + (cnt.birthday || 0) + ' 条</span>' +
      '<span class="tag mg-builtin-tag">内置</span></div>' +
      '<div class="dd-row mg-row mg-row-builtin">' +
      catDot({ color: '#10B981' }) + '<span class="dd-k">纪念日</span><span class="dd-v">' + (cnt.anniversary || 0) + ' 条</span>' +
      '<span class="tag mg-builtin-tag">内置</span></div>';
    if (!customs.length && editId !== '__new') html += '<div class="mg-empty">还没有自定义类型，点下方「新建类型」给重要日子多分几类</div>';
    html += customs.map(function (t) {
      if (t.id === editId) return typeRowEditorHtml(t, t.id, palId === t.id, val, dotColor);
      return '<div class="dd-row mg-row" data-id="' + esc(t.id) + '">' +
        '<button type="button" class="cat-dot mg-dot" data-type-dot="' + esc(t.id) + '" style="background:' + esc(t.color) + '" aria-label="更换类型颜色" title="更换颜色"></button>' +
        '<span class="dd-k">' + esc(t.name) + '</span>' +
        '<span class="dd-v">' + (cnt[t.id] || 0) + ' 条</span>' +
        '<button type="button" class="mg-act mg-act-del" data-type-del="' + esc(t.id) + '" aria-label="删除类型 ' + esc(t.name) + '" title="删除类型">' + SVG_TRASH + '</button>' +
        '</div>' + (palId === t.id ? typePaletteStrip(t.id) : '');
    }).join('');
    if (editId === '__new') html += typeRowEditorHtml(null, '__new', palId === '__new', val, dotColor);
    else html += '<button type="button" class="dd-row tp-mgr" data-type-add>' +
      '<span class="dd-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg></span>' +
      '<span class="dd-k">新建类型</span></button>';
    return html;
  }

  function bindTypeManager(root) {
    var editingId = null;
    var palId = null;
    var curColor = CAT_COLORS[0];
    var editingVal = null;
    var rows = $('#typeRows', root);

    function render(focus) {
      $('#typeCnt', root).textContent = DB.listEventTypes().length + ' 个';
      rows.innerHTML = typeMgrRowsHtml(editingId, palId, editingVal, curColor);
      if (palId) {
        $all('.mg-palette[data-pal-for="' + palId + '"] .cat-swatch', rows).forEach(function (b) {
          b.classList.toggle('is-sel', b.getAttribute('data-color') === curColor);
        });
      }
      if (focus !== false && editingId) mgrFocusSoft($('#typeName', rows));
    }
    function commit(cancel) {
      if (!editingId) return true;
      var el = $('#typeName', rows);
      var name = el ? el.value.trim() : '';
      var id = editingId;
      editingId = null; palId = null; editingVal = null;
      if (cancel) { render(false); return true; }
      if (id === '__new') {
        if (!name) { render(false); return true; }
        try { DB.addEventType({ name: name, color: curColor }); }
        catch (e) { toast(e instanceof Errors.ValidationError ? e.message : '操作失败，请重试', 'error'); render(false); return false; }
      } else if (name) {
        try { DB.updateEventType(id, { name: name }); }
        catch (e) { toast(e instanceof Errors.ValidationError ? e.message : '操作失败，请重试', 'error'); render(false); return false; }
      }
      render(false);
      refreshBehind();
      return true;
    }
    root._mgrCommit = function () { commit(false); };

    rows.addEventListener('click', function (e) {
      if (e.target.closest('#typeName')) return;
      var add = e.target.closest('[data-type-add]');
      if (add) { if (commit(false)) { editingId = '__new'; curColor = CAT_COLORS[0]; render(true); } return; }
      var dot = e.target.closest('[data-type-dot]');
      if (dot) {
        var dk = dot.getAttribute('data-type-dot');
        if (dk !== editingId) { if (!commit(false)) return; }
        else editingVal = ($('#typeName', rows) || {}).value || '';
        if (dk !== '__new' && dk !== editingId) { var cd = DB.getEventType(dk); curColor = cd ? cd.color : CAT_COLORS[0]; }
        palId = (palId === dk) ? null : dk;
        render((dk === editingId || dk === '__new') ? true : false);
        return;
      }
      var sw = e.target.closest('.cat-swatch');
      if (sw) {
        var pk = e.target.closest('[data-pal-for]');
        var key = pk ? pk.getAttribute('data-pal-for') : null;
        var color = sw.getAttribute('data-color');
        if (!key) return;
        if (key === '__new') { curColor = color; render(true); return; }
        var nm = key === editingId && $('#typeName', rows) ? $('#typeName', rows).value.trim() : '';
        try { DB.updateEventType(key, nm ? { color: color, name: nm } : { color: color }); }
        catch (err) { toast(err instanceof Errors.ValidationError ? err.message : '操作失败，请重试', 'error'); return; }
        editingId = null; palId = null; editingVal = null;
        render(false); refreshBehind();
        return;
      }
      var del = e.target.closest('[data-type-del]');
      if (del) {
        if (!commit(false)) return;
        var id = del.getAttribute('data-type-del');
        var t = DB.getEventType(id);
        if (!t) return;
        var used = eventTypeCounts()[id] || 0;
        confirmModal({
          title: '删除类型',
          message: '删除类型「' + esc(t.name) + '」？' + (used ? '其下 ' + used + ' 条事件将回落为「自定义事件」显示。' : ''),
          okText: '删除', danger: true,
          onOk: function () {
            DB.removeEventType(id);
            if (state.dateFilter === id) state.dateFilter = '';
            refreshBehind();
            render(false); /* 原位刷新，不再关卡重开 */
          }
        });
        return;
      }
      var row = e.target.closest('.mg-row[data-id]');
      if (!row) return;
      var rid = row.getAttribute('data-id');
      if (rid === editingId) return;
      if (!commit(false)) return;
      editingId = rid; palId = null; editingVal = null;
      var et = DB.getEventType(rid);
      curColor = et ? et.color : CAT_COLORS[0];
      render(true);
    });
    rows.addEventListener('keydown', function (e) {
      if (e.target.id !== 'typeName') return;
      if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); commit(false); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); commit(true); }
    });
    render(false);
  }
  function openTypeManager(opts) {
    opts = opts || {};
    var inner =
      '<div class="dd-row tb-head"><span class="dd-ico">' + TYPE_ICO + '</span>' +
        '<span class="dd-k">全部类型</span><span class="dd-v" id="typeCnt"></span></div>' +
      '<div id="typeRows"></div>';
    if (wbCoarse()) { openMgrSheet('类型管理', inner, function (sheet) { bindTypeManager(sheet); }, opts.onSheetClose); return; }
    Modal.open({
      title: '类型管理', cls: 'dd-modal',
      body: '<div class="dd-group">' + inner + '</div>',
      actions: [{ text: '完成', className: 'btn-primary', primary: true, onClick: function () { Modal.close(); renderAll(); } }]
    });
    bindTypeManager(Modal.card);
  }

  /* 类型下拉选项：内置生日 / 纪念日 + 已有自定义类型 */
  function dateTypeOptionsHtml(selected) {
    var h = '<option value="birthday"' + (selected === 'birthday' ? ' selected' : '') + '>生日</option>' +
            '<option value="anniversary"' + (selected === 'anniversary' ? ' selected' : '') + '>纪念日</option>';
    var customs = DB.listEventTypes();
    if (customs.length) {
      h += '<optgroup label="自定义类型">' + customs.map(function (c) {
        return '<option value="' + esc(c.id) + '"' + (selected === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>';
      }).join('') + '</optgroup>';
    }
    return h;
  }

  /* 纪念日表单弹窗 */
  function openDateForm(item, opts) {
    var isEdit = !!item;
    var type = item ? item.type : 'birthday';
    var repeat = item ? item.repeat : true;
    var lunar = item ? !!item.lunar : false;
    var showSince = item ? !!item.showSince : false;
    var mob = wbCoarse();

    function submitForm() {
      var card = Modal.card;
      var name = $('#f-name', card).value.trim();
      var typeV = $('#f-type', card).value;
      var date = $('#f-date', card).value;
      var rep = $('#f-repeat', card).checked;
      var lun = $('#f-lunar', card).checked;
      var swSince = $('#f-show-since', card).checked;
      var note = $('#f-note', card).value.trim();
      if (!name) { showFormError('请填写事件名称', 'f-name'); return; }
      if (!date) { showFormError('请选择日期', 'f-date'); return; }
      try {
        if (isEdit) DB.updateSpecial(item.id, { name: name, type: typeV, date: date, repeat: rep, lunar: lun, showSince: swSince, note: note });
        else DB.addSpecial({ name: name, type: typeV, date: date, repeat: rep, lunar: lun, showSince: swSince, note: note });
      } catch (e) {
        if (e instanceof Errors.QuotaError) { quotaModal(); return; }
        if (e instanceof Errors.ValidationError) { showFormError(e.message); return; }
        toast('操作失败，请重试', 'error'); return;
      }
      Modal.markClean();
      Modal.close();
      toast(isEdit ? '事件已更新' : '事件已添加');
      renderView('date');
      if (isEdit && !(opts && opts.back)) openDateDetail(DB.getSpecial(item.id)); /* 回到详情（从详情进入时由 afterClose 统一返回） */
    }
    function doDelete() {
            confirmDelete('事件', item.name, function () { DB.deleteSpecial(item.id); });
    }

    var body =
      '<div class="fg-card">' +
        '<div class="field fg-row">' +
          '<label for="f-name">名称<span class="req">*</span></label>' +
          '<input class="form-input" id="f-name" type="text" maxlength="100" value="' + esc(item ? item.name : '') + '" placeholder="如：妈妈生日 / 结婚纪念日">' +
        '</div>' +
        '<div class="field fg-row">' +
          '<label for="f-type">类型</label>' +
          '<div class="select-wrap"><select class="form-input" id="f-type">' + dateTypeOptionsHtml(type) + '</select></div>' +
        '</div>' +
        '<div class="field fg-row">' +
          '<label for="f-date">日期<span class="req">*</span></label>' +
          '<input class="form-input" id="f-date" type="date" value="' + esc(item ? item.date : '') + '">' +
        '</div>' +
      '</div>' +
      '<div class="fg-card">' +
        '<div class="field fg-switch">' +
          '<label class="switch-row">' +
            '<span>' +
              '<span class="switch-label">每年重复</span>' +
              '<div class="switch-desc">按周年自动计算下一次日期</div>' +
            '</span>' +
            '<span class="status-switch">' +
              '<input type="checkbox" id="f-repeat"' + (repeat ? ' checked' : '') + '>' +
              '<span class="switch-slider"></span>' +
            '</span>' +
          '</label>' +
        '</div>' +
        '<div class="field fg-switch">' +
          '<label class="switch-row">' +
            '<span>' +
              '<span class="switch-label">过农历</span>' +
              '<div class="switch-desc">每年按农历周期换算下次日期（如农历生日）</div>' +
            '</span>' +
            '<span class="status-switch">' +
              '<input type="checkbox" id="f-lunar"' + (lunar ? ' checked' : '') + '>' +
              '<span class="switch-slider"></span>' +
            '</span>' +
          '</label>' +
        '</div>' +
        '<div class="field fg-switch">' +
          '<label class="switch-row">' +
            '<span>' +
              '<span class="switch-label">显示至今天数</span>' +
              '<div class="switch-desc">在卡片上显示从该日期起到今天共多少天</div>' +
            '</span>' +
            '<span class="status-switch">' +
              '<input type="checkbox" id="f-show-since"' + (showSince ? ' checked' : '') + '>' +
              '<span class="switch-slider"></span>' +
            '</span>' +
          '</label>' +
        '</div>' +
      '</div>' +
      '<div class="fg-card">' +
        '<div class="field fg-row">' +
          '<label for="f-note">备注</label>' +
          '<input class="form-input" id="f-note" type="text" maxlength="500" value="' + esc(item ? item.note : '') + '" placeholder="其他说明（可选）">' +
        '</div>' +
      '</div>' +
      '<div class="form-error" id="formError" role="alert"></div>';

    Modal.open({
      dirtyGuard: true,
      title: isEdit ? '编辑事件' : '新增事件',
      afterClose: opts && opts.back, /* 挂 back：取消/X/Esc/遮罩/保存全路径返回详情 */
      headAction: mob ? { icon: true, text: isEdit ? '保存' : '添加', onClick: submitForm } : null,
      body: body,
      actions: [
        isEdit ? { text: '删除', className: 'btn-danger', align: 'left', onClick: doDelete } : null,
        { text: '取消', className: 'btn-default' },
        { text: isEdit ? '保存修改' : '添加', className: 'btn-primary', primary: true, onClick: submitForm }
      ].filter(Boolean)
    });
    mobFormify();
    /* 自定义类型的「新建 / 改名 / 上色 / 删除」统一收进工具栏「全部类型」浮层，
       这里只负责在类型下拉里选一个现成类型（内置 + 已建自定义）。 */
  }

  /* ============================================================
     删除确认
     ============================================================ */
  function confirmDelete(noun, name, fn, msg) {
    confirmModal({
      title: '删除' + noun,
      icon: 'trash',
      danger: true,
      /* 手机端抽屉叠在详情 / 编辑之上：删除成功后才收起底下那张卡 */
      closeUnderlying: true,
      /* 对象名单独成行：手机上一眼看清「要删的是哪一个」 */
      headline: '「<b>' + esc(name) + '</b>」',
      message: msg || '移入回收站，30 天内可恢复。',
      okText: '删除',
      onOk: function () {
        try { fn(); }
        catch (e) { handleMutationError(e); return false; }
        toast('已移入回收站');
        renderView(state.view);
      }
    });
  }

  /* ============================================================
     备份导入 / 导出（纯客户端：不依赖服务器与网络，本地模式同样可用）
     ============================================================ */
  /* 导出文件名：登录态用账号名，本地模式用昵称（数据文件同名语义） */
  function exportBaseName() {
    if (LOGIN_AUTHED) return loginUser() || 'workbench';
    var p = (window.WorkbenchDB && WorkbenchDB.getProfile) ? WorkbenchDB.getProfile() : null;
    return p ? p.slug : 'workbench';
  }

  function doExport() {
    var json;
    try {
      json = JSON.stringify(DB.exportData());
    } catch (e) {
      toast('导出失败：数据序列化异常', 'error');
      return;
    }
    try {
      /* App 内 WebView 没有下载管理器，Blob 直下会静默失败：先交给原生桥 */
      if (window.KlogNative && window.KlogNative.isApp &&
          window.KlogNative.saveBackup(json, exportBaseName() + '-Klog备份-' + todayStr() + '.json')) return;
      var blob = new Blob([json], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = exportBaseName() + '-Klog备份-' + todayStr() + '.json';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      toast('备份已导出');
    } catch (e) {
      toast('导出失败，请重试', 'error');
    }
  }

  function doImport(file) {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      toast('文件过大（备份上限 8MB）', 'error');
      return;
    }
    var fr = new FileReader();
    fr.onload = function () {
      try {
        DB.importData(String(fr.result));
      } catch (e) {
        if (e instanceof Errors.QuotaError) { quotaModal(); return; }
        toast(e && e.message ? e.message : '备份内容不是有效的工作台数据', 'error');
        return;
      }
      toast('导入成功，正在刷新…');
      setTimeout(function () { location.reload(); }, 700);
    };
    fr.onerror = function () { toast('读取备份文件失败，请重试', 'error'); };
    fr.readAsText(file, 'utf-8');
  }

  /* ============================================================
     习惯打卡 · 打卡热力（习惯色四档 · 卡片只给本周 7 格，周/月/年翻页收进详情弹窗）
     ============================================================ */
  var HM_WD = ['一', '二', '三', '四', '五', '六', '日']; /* 周一起始 */

  /* 当日次数 → 档位：0 空白 / 1 浅 / 2 中 / ≥3 深（深浅由习惯色派生） */
  function hmLv(n) { return 'hm-l' + (n <= 0 ? 0 : n === 1 ? 1 : n === 2 ? 2 : 3); }

  /* ---- 由习惯色派生四档（含格内数字墨色） ---- */
  var HM_FALLBACK = '#279E49'; /* 拿不到合法颜色时的兜底绿 */
  function hmRgb(hex) {
    var h = String(hex || '').replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h.slice(0, 6), 16);
    return isNaN(n) ? [39, 158, 73] : [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function hmHex(rgb) {
    return '#' + rgb.map(function (v) {
      v = Math.max(0, Math.min(255, Math.round(v)));
      return (v < 16 ? '0' : '') + v.toString(16);
    }).join('');
  }
  /* 与基色按 pct 线性混色（等价 color-mix in srgb，但结果可预测，便于同帧算墨色） */
  function hmMix(c, base, pct) {
    var a = hmRgb(c), b = hmRgb(base);
    return hmHex(a.map(function (v, i) { return b[i] + (v - b[i]) * pct; }));
  }
  /* WCAG 相对亮度：决定格内数字用深墨还是白墨（黑/深蓝等深色格自动翻白） */
  function hmLum(hex) {
    var s = hmRgb(hex).map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * s[0] + 0.7152 * s[1] + 0.0722 * s[2];
  }
  function hmInk(hex) { return hmLum(hex) > 0.4 ? '#141414' : '#FFFFFF'; }

  /* 一次写出亮/暗两套档位 + 各自墨色：CSS 按 [data-theme] 取用，切主题无需重渲染。
     亮色 = 白底逐级加深（本色为最深档）；暗色 = 台面逐级加亮（避免黑习惯色在暗底上消失） */
  function hmVars(color) {
    var c = /^#[0-9a-fA-F]{3,8}$/.test(color || '') ? color : HM_FALLBACK;
    var lt = [hmMix(c, '#FFFFFF', 0.24), hmMix(c, '#FFFFFF', 0.55), c];
    var dk = [hmMix(c, '#15171B', 0.34), hmMix(c, '#15171B', 0.67), hmMix(c, '#FFFFFF', 0.38)];
    var out = '';
    [lt, dk].forEach(function (set, k) {
      var suf = k ? 'd' : '';
      set.forEach(function (col, i) {
        out += '--hm-' + 'abc'.charAt(i) + suf + ':' + col + ';--hm-k' + 'abc'.charAt(i) + suf + ':' + hmInk(col) + ';';
      });
    });
    return out;
  }
  function hmRampStyle(h) { return ' style="' + hmVars(h && h.color) + '"'; }

  function hmKey(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function hmAdd(d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); }
  function hmMonday(d) { return hmAdd(d, -((d.getDay() + 6) % 7)); }
  function hmTip(key, n) { return mdCN(key) + ' ' + weekdayCN(key) + ' · ' + (n ? n + ' 次' : '未打卡'); }

  /* 区间统计：次数合计 + 覆盖天数 */
  function hmSum(map, keys) {
    var sum = 0, days = 0;
    keys.forEach(function (k) { var n = map[k] || 0; sum += n; if (n) days++; });
    return { sum: sum, days: days };
  }
  function hmDayKeys(start, span) {
    var out = [];
    for (var i = 0; i < span; i++) out.push(hmKey(hmAdd(start, i)));
    return out;
  }
  function hmSumLine(map, start, span) {
    var s = hmSum(map, hmDayKeys(start, span));
    return '共 <b>' + s.sum + '</b> 次 · 覆盖 <b>' + s.days + '</b> 天';
  }

  /* 单元格：格子内直接标次数（已过未打造间隔号，未来留空），深浅按四档。
     data-hm-key 让打卡后能原位刷新这一格，不必重建整块面板 */
  function hmCell(d, n, opts) {
    var key = hmKey(d), today = todayStr(), future = key > today;
    var cls = 'hm-cell' + (opts && opts.cls ? ' ' + opts.cls : '') + ' ' + hmLv(n) +
      (key === today ? ' is-today' : '') + (future ? ' is-future' : '');
    return '<span class="' + cls + '" data-hm-key="' + key + '" title="' + esc(hmTip(key, n)) + '">' +
      (opts && opts.count ? '<b class="hm-v">' + (n ? n : (future ? '' : '<i class="hm-dot"></i>')) + '</b>' : '') +
      '</span>';
  }

  /* 周 / 月视图的星期标头 */
  function hmWeekHead() {
    return '<div class="hm-wkrow">' + HM_WD.map(function (w) { return '<span>' + w + '</span>'; }).join('') + '</div>';
  }

  /* 一周 7 格（卡片与详情周视图共用） */
  function hmWeekGrid(h, mon, big) {
    var map = DB.habitCountMap(h.id);
    var cells = '';
    for (var i = 0; i < 7; i++) {
      var d = hmAdd(mon, i), n = map[hmKey(d)] || 0;
      cells += '<span class="hm-col">' + hmCell(d, n, { cls: 'hm-sq' + (big ? ' hm-sq-lg' : ''), count: true }) +
        '<em>' + HM_WD[i] + '</em></span>';
    }
    return '<div class="hm-week">' + cells + '</div>';
  }

  /* 月视图：当月日期网格，前置空白补齐星期位置 */
  function hmMonthGrid(h, y, m) {
    var map = DB.habitCountMap(h.id);
    var first = new Date(y, m, 1);
    var total = new Date(y, m + 1, 0).getDate();
    var cells = '';
    for (var i = 0; i < (first.getDay() + 6) % 7; i++) cells += '<span class="hm-cell hm-day is-pad" aria-hidden="true"></span>';
    for (var d = 1; d <= total; d++) {
      var day = new Date(y, m, d), key = hmKey(day), n = map[key] || 0;
      var today = key === todayStr();
      cells += '<span class="hm-cell hm-day ' + hmLv(n) + (today ? ' is-today' : '') + (key > todayStr() ? ' is-future' : '') +
        '" data-hm-key="' + key + '" data-hm-tip="' + esc(hmTip(key, n)) + '" title="' + esc(hmTip(key, n)) + '">' + d + '</span>';
    }
    return hmWeekHead() + '<div class="hm-grid7">' + cells + '</div>';
  }

  /* 年视图：连续日期网格（周一→周日 7 行、按周成列），横向可滚、默认停在最近一周 */
  function hmYearGrid(h, y) {
    var map = DB.habitCountMap(h.id);
    var mon = hmMonday(new Date(y, 0, 1));
    var weeks = Math.ceil(((new Date(y, 11, 31) - mon) / 86400000 + 1) / 7);
    var cols = '', labs = '';
    for (var c = 0; c < weeks; c++) {
      var lab = '';
      for (var r = 0; r < 7; r++) {
        var d = hmAdd(mon, c * 7 + r);
        if (d.getFullYear() !== y) { cols += '<span class="hm-cell hm-dot-c is-pad" aria-hidden="true"></span>'; continue; }
        if (d.getDate() === 1) lab = String(d.getMonth() + 1);
        var yk = hmKey(d), yn = map[yk] || 0, tt = hmTip(yk, yn), tk = todayStr();
        cols += '<span class="hm-cell hm-dot-c ' + hmLv(yn) + (yk === tk ? ' is-today' : '') +
          (yk > tk ? ' is-future' : '') + '" data-hm-key="' + yk + '" data-hm-tip="' + esc(tt) + '" title="' + esc(tt) + '"></span>';
      }
      labs += '<i>' + lab + '</i>';
    }
    return '<div class="hm-year">' +
      '<div class="hm-ylab" aria-hidden="true"><span>一</span><span></span><span>三</span><span></span><span>五</span><span></span><span>日</span></div>' +
      '<div class="hm-year-scroll"><div class="hm-year-inner">' +
        '<div class="hm-mlab">' + labs + '</div><div class="hm-ygrid">' + cols + '</div>' +
      '</div></div></div>';
  }

  function hmTabs(view) {
    var names = { week: '周', month: '月', year: '年' }, out = '';
    Object.keys(names).forEach(function (k) {
      out += '<button type="button" class="hm-tab' + (k === view ? ' active' : '') + '" role="tab"' +
        ' aria-selected="' + (k === view ? 'true' : 'false') + '" data-hm-view="' + k + '">' + names[k] + '</button>';
    });
    return '<div class="seg hm-seg" role="tablist" aria-label="热力视图">' + out + '</div>';
  }

  function hmLegend() {
    var it = [['hm-l0', '未打卡'], ['hm-l1', '1 次'], ['hm-l2', '2 次'], ['hm-l3', '3 次以上']];
    return '<div class="hm-legend">' + it.map(function (x) {
      return '<span class="hm-lg-item"><i class="hm-cell ' + x[0] + '"></i>' + x[1] + '</span>';
    }).join('') + '</div>';
  }

  /* 当期区间：面板渲染与原位刷新共用同一套算式 */
  function hmPeriod(st) {
    var view = st.view, at = st.at, now = new Date(), start, span, cur;
    if (view === 'week') { start = hmMonday(at); span = 7; cur = hmMonday(now).getTime() === start.getTime(); }
    else if (view === 'month') {
      start = new Date(at.getFullYear(), at.getMonth(), 1);
      span = new Date(at.getFullYear(), at.getMonth() + 1, 0).getDate();
      cur = now.getFullYear() === start.getFullYear() && now.getMonth() === start.getMonth();
    } else {
      start = new Date(at.getFullYear(), 0, 1);
      span = Math.round((new Date(at.getFullYear() + 1, 0, 1) - start) / 86400000);
      cur = now.getFullYear() === start.getFullYear();
    }
    var end = hmAdd(start, span - 1);
    var range = view === 'week' ? (mdCN(hmKey(start)) + ' – ' + mdCN(hmKey(end)))
      : view === 'month' ? (start.getFullYear() + ' 年 ' + (start.getMonth() + 1) + ' 月') : (start.getFullYear() + ' 年');
    return { view: view, start: start, span: span, end: end, cur: cur, range: range };
  }

  /* 原位刷新：打卡后只改格子档位 / 数字 / 提示 / 统计行。
     重建整块面板会重放级联入场，底下的「编辑 / 删除」跟着跳位——看着就是闪和卡 */
  function hmRefresh(panel, h, st) {
    var map = DB.habitCountMap(h.id), tk = todayStr();
    $all('[data-hm-key]', panel).forEach(function (n) {
      var key = n.getAttribute('data-hm-key');
      if (key > tk) return;                       /* 未来格不参与刷新 */
      var cnt = map[key] || 0, tip = hmTip(key, cnt);
      n.classList.remove('hm-l0', 'hm-l1', 'hm-l2', 'hm-l3');
      n.classList.add(hmLv(cnt));
      n.setAttribute('title', tip);
      if (n.hasAttribute('data-hm-tip')) n.setAttribute('data-hm-tip', tip);
      var v = n.querySelector('.hm-v');
      if (v) v.innerHTML = cnt ? String(cnt) : '<i class="hm-dot"></i>';
    });
    var p = hmPeriod(st), summ = $('.hm-summ', panel);
    if (summ) summ.innerHTML = hmSumLine(map, p.start, p.span) + (p.view === 'year' ? ' · 全年热力' : '');
  }

  /* 热力面板（详情弹窗内）：Tab + 左右翻页 + 当期网格 + 图例 */
  function hmPanelHtml(h, st) {
    var p = hmPeriod(st), map = DB.habitCountMap(h.id);
    return hmTabs(p.view) +
      '<div class="hm-nav">' +
        '<button type="button" class="dp-nav" data-hm-step="-1" aria-label="上一页">' + '‹' + '</button>' +
        '<span class="hm-range hm-swap">' + p.range +
          (p.cur ? '<i class="hm-cur">' + (p.view === 'week' ? '本周' : p.view === 'month' ? '本月' : '今年') + '</i>'
                 : '<button type="button" class="hm-back" data-hm-step="0">回到' + (p.view === 'week' ? '本周' : p.view === 'month' ? '本月' : '今年') + '</button>') +
        '</span>' +
        '<button type="button" class="dp-nav" data-hm-step="1" aria-label="下一页"' + (p.cur ? ' disabled' : '') + '>' + '›' + '</button>' +
      '</div>' +
      '<div class="hm-summ hm-swap">' + hmSumLine(map, p.start, p.span) + (p.view === 'year' ? ' · 全年热力' : '') + '</div>' +
      /* 当期网格单独包一层：切视图 / 翻页只对这块做方向性入场 */
      '<div class="hm-body">' + (p.view === 'week' ? hmWeekGrid(h, p.start, true)
        : p.view === 'month' ? hmMonthGrid(h, p.start.getFullYear(), p.start.getMonth())
        : hmYearGrid(h, p.start.getFullYear())) + '</div>' +
      hmLegend();
  }

  /* 卡片用：只给本周 7 格（横向周一 → 周日，深浅 = 当日次数），历史看详情弹窗 */
  function habitWeekHeat(h) {
    var map = DB.habitCountMap(h.id);
    var mon = hmMonday(new Date());
    return '<div class="hb-heat"' + hmRampStyle(h) + '>' +
      '<div class="hb-heat-head"><span class="hb-heat-title">本周热力</span>' +
        '<span class="hb-heat-sum">' + hmSumLine(map, mon, 7) + '</span></div>' +
      hmWeekGrid(h, mon, false) +
    '</div>';
  }

  /* 打卡控件（今日列表 / 概览 / 详情共用）：
     未打卡 = 单个「打卡」；已打卡 = 「减一次」+ 带当日累计次数的勾选钮（单日可多次） */
  function habitCheckCtl(h, date, idAttr) {
    var n = DB.habitCount(h.id, date);
    var on = n > 0;
    return (on ? '<button type="button" class="hb-minus" data-habit-undo="' + esc(h.id) +
        '" title="减一次" aria-label="减一次打卡">' + HB_MINUS + '</button>' : '') +
      '<button type="button" class="habit-toggle-btn' + (on ? ' on' : '') + '"' +
        (idAttr ? ' id="' + idAttr + '"' : '') + ' data-habit-toggle="' + esc(h.id) + '"' +
        (on ? ' data-habit-clear="1"' : '') +
        ' aria-pressed="' + on + '" title="' +
          (on ? '今日 ' + n + ' 次 · 短按再加一次，长按取消今天' : '打卡') + '">' +
        (on ? HABIT_CHECK + '<span class="hb-times">' + n + '</span>' : '打卡') + '</button>';
  }

  /* 三处列表（习惯页今日打卡 / 概览时间线 / 习惯详情）共用一套：
     短按主钮 = 加一次，小钮 − = 减一次，长按主钮 = 把今天全部取消。
     长按完成后必须吞掉浏览器补发的那次 click，否则「清零」立刻又被加回 1 次。 */
  var HB_HOLD_MS = 500;
  var hbHold = { timer: 0, until: 0, btn: null, x: 0, y: 0 };
  function hbCancel() {
    if (hbHold.timer) { clearTimeout(hbHold.timer); hbHold.timer = 0; }
    if (hbHold.btn) { hbHold.btn.classList.remove('is-holding'); hbHold.btn = null; }
  }
  function hbClearToday(hid) {
    var today = todayStr(), guard = 0;
    /* 逐次退到 0（undoCheckIn 归零会留一条 n=0 的墓碑行，防止云端把这次取消并回来），上限防死循环 */
    while (DB.isHabitDone(hid, today) && guard++ < 60) DB.undoCheckIn(hid, today);
  }
  function bindHabitCheck(root, after) {
    if (!root) return;
    root.addEventListener('pointerdown', function (e) {
      var b = e.target.closest('[data-habit-clear]');
      if (!b) return;
      hbCancel();
      hbHold.btn = b; hbHold.x = e.clientX; hbHold.y = e.clientY;
      b.classList.add('is-holding');
      var hid = b.getAttribute('data-habit-toggle');
      hbHold.timer = setTimeout(function () {
        hbHold.timer = 0;
        hbHold.until = Date.now();
        hbCancel();
        hbClearToday(hid);
        if (window.KlogNative) { window.KlogNative.haptic('medium'); }
        else if (navigator.vibrate) { try { navigator.vibrate(8); } catch (err) { /* 不支持就静默 */ } }
        after();
        renderCounts();
      }, HB_HOLD_MS);
    });
    /* 手指滑出 / 按得太久又移动 → 当成误触，取消长按 */
    root.addEventListener('pointermove', function (e) {
      if (!hbHold.timer) return;
      if (Math.abs(e.clientX - hbHold.x) > 10 || Math.abs(e.clientY - hbHold.y) > 10) hbCancel();
    }, { passive: true });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (t) {
      root.addEventListener(t, hbCancel);
    });
    root.addEventListener('contextmenu', function (e) {
      if (e.target.closest('[data-habit-clear]')) e.preventDefault(); /* 安卓长按菜单 */
    });
    root.addEventListener('click', function (e) {
      if (hbHold.until && Date.now() - hbHold.until < 800) {
        hbHold.until = 0;
        e.stopPropagation();
        e.preventDefault();
      }
    }, true);
    root.addEventListener('click', function (e) {
      var plus = e.target.closest('[data-habit-toggle]');
      var minus = e.target.closest('[data-habit-undo]');
      if (!plus && !minus) return;
      var hid = (plus || minus).getAttribute(plus ? 'data-habit-toggle' : 'data-habit-undo');
      if (plus) DB.checkInHabit(hid, todayStr()); else DB.undoCheckIn(hid, todayStr());
      after();
      renderCounts();
      var nb = root.querySelector('[data-habit-toggle="' + hid + '"]');
      if (nb) nb.classList.add('btn-pop');
      var sm = nb && nb.parentNode.querySelector('.streak-mark');
      if (sm) sm.classList.add('fade-in');
    });
  }

  /* 翻页：整期前/后推（0 = 回到本期） */
  function hmStep(st, dir) {
    if (!dir) { st.at = new Date(); return st; }
    var a = st.at;
    if (st.view === 'week') st.at = hmAdd(hmMonday(a), dir * 7);
    else if (st.view === 'month') st.at = new Date(a.getFullYear(), a.getMonth() + dir, 1);
    else st.at = new Date(a.getFullYear() + dir, 0, 1);
    return st;
  }

  function habitCard(h) {
    var streak = DB.habitStreak(h.id);
    var rate = DB.habitMonthRate(h.id);
    return '<article class="habit-card" data-id="' + esc(h.id) + '">' +
      '<div class="habit-head">' +
        '<span class="cat-dot" style="background:' + esc(h.color) + '"></span>' +
        '<h3 class="habit-name">' + esc(h.name) + '</h3>' +
        '<span class="habit-ops">' +
          '<button type="button" class="cat-act" data-habit-edit="' + esc(h.id) + '" aria-label="编辑 ' + esc(h.name) + '" title="编辑">' + SVG_PENCIL + '</button>' +
          '<button type="button" class="cat-act cat-act-del" data-habit-del="' + esc(h.id) + '" aria-label="删除 ' + esc(h.name) + '" title="删除">' + SVG_TRASH + '</button>' +
        '</span>' +
      '</div>' +
      '<div class="habit-meta">' +
        '<span class="habit-streak">连续 <b>' + streak + '</b> 天</span>' +
        '<span class="habit-rate">本月完成 <b>' + rate + '%</b></span>' +
      '</div>' +
      habitWeekHeat(h) +
    '</article>';
  }

  function renderHabits(animate) {
    var habits = DB.listHabits();
    var today = todayStr();

    $('#habitTodayDate').textContent = mdCN(today) + ' ' + weekdayCN(today);

    var doneCnt = habits.filter(function (h) { return DB.isHabitDone(h.id, today); }).length;
    /* 完成度提示挂在标题右侧；一个习惯都没有时不显示，避免「已完成 0/0」这种噪声 */
    var cntEl = $('#habitCountInfo');
    cntEl.textContent = '已完成 ' + doneCnt + '/' + habits.length;
    cntEl.hidden = !habits.length;

    /* 今日打卡列表 */
    var listEl = $('#habitTodayList');
    if (habits.length) {
      listEl.innerHTML = habits.map(function (h) {
        var n = DB.habitCount(h.id, today);
        return '<div class="habit-today-row">' +
          '<span class="cat-dot" style="background:' + esc(h.color) + '"></span>' +
          '<span class="row-title">' + esc(h.name) + '</span>' +
          (n ? '<span class="streak-mark">连续 ' + DB.habitStreak(h.id) + ' 天</span>' : '') +
          habitCheckCtl(h, today) +
        '</div>';
      }).join('');
    } else {
      listEl.innerHTML = '<div class="ov-empty">还没有习惯，创建第一个吧</div>';
    }

    /* 习惯卡片 + 热力图 */
    var grid = $('#habitGrid');
    staggerList(grid, animate);
    var empty = $('#habitEmpty');
    if (!habits.length) {
      grid.innerHTML = '';
      empty.innerHTML = emptyHtml(false, '习惯', '从一个每天坚持的小事开始', 'habit');
      empty.hidden = false;
      return;
    }
    empty.hidden = true;
    grid.innerHTML = habits.map(habitCard).join('');
    if (animate) grid.classList.remove('tbody-enter');
  }

  function openHabitForm(item, opts) {
    var isEdit = !!item;
    var curColor = item ? item.color : CAT_COLORS[4]; /* 默认蓝 */

    Modal.open({
      dirtyGuard: true,
      title: isEdit ? '编辑习惯' : '新增习惯',
      afterClose: opts && opts.back, /* 挂 back：取消/X/Esc/遮罩/保存全路径返回详情 */
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        '<div class="field" data-fg="hb">' +
          '<label for="hb-name">习惯名称<span class="req">*</span></label>' +
          '<input class="form-input" id="hb-name" type="text" maxlength="20" value="' + esc(item ? item.name : '') + '" placeholder="如：每天喝 8 杯水 / 读书 30 分钟">' +
        '</div>' +
        '<div class="field" data-fg="hb">' +
          '<label>颜色</label>' +
          '<div class="cat-palette" id="hb-palette">' +
            catPaletteHtml(curColor, { custom: true, inputId: 'hb-custom', hexId: 'hb-custom-hex' }) +
          '</div>' +
        '</div>' +
        '<div class="field-hint">每天可多次打卡（点一下加一次），自动统计连续天数与本月完成率；颜色用于本周热力与详情热力图的深浅档位</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        isEdit ? {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
            /* 与其余模块同一删除链：确认抽屉叠在编辑页之上，
               删除成功后才由 closeUnderlying 收起这张卡（不能提前 Modal.close） */
            confirmDelete('习惯', item.name, function () { DB.removeHabit(item.id); },
              '打卡记录一并移入回收站，30 天内可恢复。');
          }
        } : null,
        { text: '取消', className: 'btn-default' },
        {
          text: isEdit ? '保存修改' : '创建',
          className: 'btn-primary', primary: true,
          onClick: function () {
            var card = Modal.card;
            var name = $('#hb-name', card).value.trim();
            var color = $('#hb-palette .cat-swatch.is-sel', card);
            var colorVal = (color && color.getAttribute('data-color')) || curColor;
            if (!name) { showFormError('请填写习惯名称', 'hb-name'); return; }
            try {
              if (isEdit) DB.updateHabit(item.id, { name: name, color: colorVal });
              else DB.addHabit({ name: name, color: colorVal });
            } catch (e) {
              if (e instanceof Errors.ValidationError) { showFormError(e.message); return; }
              toast('操作失败，请重试', 'error'); return;
            }
            Modal.markClean();
            Modal.close();
            toast(isEdit ? '习惯已更新' : '习惯已创建');
            renderAll();
            if (isEdit && !(opts && opts.back)) openHabitDetail(DB.getHabit(item.id)); /* 回到详情（从详情进入时由 afterClose 统一返回） */
          }
        }
      ].filter(Boolean)
    });
    mobFormify();

    bindColorPalette($('#hb-palette', Modal.card), $('#hb-custom', Modal.card), $('#hb-custom-hex', Modal.card));
  }

  /* ============================================================
     日记 / 每日回顾
     ============================================================ */
  var MOODS = {
    great: { label: '很好', color: '#639922' },
    good:  { label: '较好', color: '#5DCAA5' },
    ok:    { label: '一般', color: '#888780' },
    low:   { label: '较低', color: '#EF9F27' },
    bad:   { label: '糟糕', color: '#E24B4A' }
  };

  function moodChip(m) {
    var c = MOODS[m] || MOODS.ok;
    return '<span class="mood-chip"><span class="cat-dot" style="background:' + c.color + '"></span>' + c.label + '</span>';
  }

  /* ============================================================
     日记配图 · 一日三问「今日剪贴簿」
     ------------------------------------------------------------
     · 选图后一律走 canvas 重绘两级：最长边 1600px（全屏预览够清）
       + 400px（胶片条/网格缩略），JPEG 0.8 / 0.72；重绘顺带按 EXIF 转正、
       把手机直出的 3~8MB 收敛到几百 KB，再交数据层暂存与上云。
     · 编辑态 = 方形网格（4 列，最多 9 张）：不横向滚动，故格子可安心
       touch-action:none，长按拖动排序才可靠；点 × 摘除、点图进全屏预览。
     · 详情态 = 横向胶片条（只读滑动），点任意一张进全屏预览；
       「仅存本机」的小圆点在详情里点按即补传。
     ============================================================ */
  var DI_MAX = 9;                              /* 与数据层 DIARY_IMG_MAX 同规则 */
  var DI_FULL_SIDE = 1600, DI_FULL_Q = 0.8;
  var DI_THUMB_SIDE = 400, DI_THUMB_Q = 0.72;
  var DI_CAM_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9A2.6 2.6 0 0 1 5.6 6.4h1.1a2 2 0 0 0 1.7-.95l.44-.75A1.6 1.6 0 0 1 10.73 4h2.54a1.6 1.6 0 0 1 1.35.7l.44.75a2 2 0 0 0 1.7.95h1.1A2.6 2.6 0 0 1 21 9v8.4a2.6 2.6 0 0 1-2.6 2.6H5.6A2.6 2.6 0 0 1 3 17.4Z"/><circle cx="12" cy="13.2" r="3.5"/></svg>';
  var DI_ADD_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M12 6.5v11M6.5 12h11"/></svg>';
  var DI_X_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/></svg>';

  /* 网格/胶片里显示的那一层：有缩略图用缩略图，回退主图 */
  function diViewSrc(im) { return (im && (im.t || im.u)) || ''; }

  /* 一篇里「仅存本机、还没上云」的张数（登录态才有意义） */
  function diLocalCount(list) {
    var n = 0, i;
    for (i = 0; i < (list || []).length; i++) {
      if (list[i] && !DB.IMAGES.isCloud(list[i].u)) n++;
    }
    return n;
  }

  /* 列表卡片角标：相机 + 张数，另存本机时点后跟一个小圆点 */
  function diBadgeHtml(list) {
    var n = (list || []).length;
    if (!n) return '';
    var local = diLocalCount(list);
    return '<span class="diary-imgs"' + (local ? ' title="' + local + ' 张仅存本机"' : '') + '>' +
      DI_CAM_SVG + '<b>' + n + '</b>' + (local ? '<i class="diary-imgs-local"></i>' : '') + '</span>';
  }

  /* 编辑态网格：mode='edit' 才有摘除钮与加片格；两者都可点图预览 */
  function diGridHtml(list, mode) {
    var cells = (list || []).map(function (im, i) {
      return '<figure class="dg-cell" data-i="' + i + '">' +
          '<img src="' + esc(diViewSrc(im)) + '" alt="" draggable="false">' +
          (mode === 'edit' ? '<button type="button" class="dg-del" aria-label="移除第 ' + (i + 1) + ' 张">' + DI_X_SVG + '</button>' : '') +
          (DB.IMAGES.isCloud(im.u) || mode === 'detail' ? '' : '<span class="dg-local" aria-hidden="true"></span>') +
        '</figure>';
    }).join('');
    if (mode === 'edit' && (list || []).length < DI_MAX) {
      cells += '<button type="button" class="dg-add" aria-label="添加图片（还可加 ' + (DI_MAX - (list || []).length) + ' 张）">' +
        DI_ADD_SVG + '<span>加片</span></button>';
    }
    return cells || (mode === 'edit' ? '<button type="button" class="dg-add" aria-label="添加图片">' + DI_ADD_SVG + '<span>加片</span></button>' : '');
  }

  /* 详情态胶片条：横向滑动，边缘渐隐由 tagBarFade 按滚动位置挂类 */
  function diFilmHtml(list) {
    var cells = (list || []).map(function (im, i) {
      return '<figure class="dg-cell' + (DB.IMAGES.isCloud(im.u) ? '' : ' is-local') + '" data-i="' + i + '">' +
          '<img src="' + esc(diViewSrc(im)) + '" alt="" draggable="false">' +
          (DB.IMAGES.isCloud(im.u) ? '' : '<button type="button" class="dg-local-dot" aria-label="该图仅存本机，点按上传"><span></span></button>') +
        '</figure>';
    }).join('');
    return '<div class="dg-film" id="ddFilmScroll"><div class="dg-film-track">' + cells + '</div></div>';
  }

  /* 按最长边等比重绘 → JPEG data URI（顺带完成 EXIF 转正与体量收敛） */
  function diScaled(img, maxSide, q) {
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    if (!w || !h) return '';
    var k = Math.min(1, maxSide / Math.max(w, h));
    var cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
    var cv = document.createElement('canvas');
    cv.width = cw; cv.height = ch;
    var cx = cv.getContext('2d');
    cx.fillStyle = '#ffffff';                 /* PNG 透明底转 JPEG 时不要变黑块 */
    cx.fillRect(0, 0, cw, ch);
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(img, 0, 0, cw, ch);
    try { return cv.toDataURL('image/jpeg', q); } catch (e) { return ''; }
  }

  /* 一枚文件 → {u,t} 暂存引用（Promise；读不出则 resolve(null)） */
  function diCompress(file) {
    return new Promise(function (resolve) {
      var url = '';
      try { url = window.URL.createObjectURL(file); } catch (e) { resolve(null); return; }
      var img = new Image();
      var settle = function (val) {
        try { window.URL.revokeObjectURL(url); } catch (e) { /* 忽略 */ }
        resolve(val);
      };
      img.onload = function () {
        var u = diScaled(img, DI_FULL_SIDE, DI_FULL_Q);
        if (!u) { settle(null); return; }
        settle({ u: u, t: diScaled(img, DI_THUMB_SIDE, DI_THUMB_Q) || u });
      };
      img.onerror = function () { settle(null); };
      img.src = url;
    });
  }

  /* 编辑态网格的交互：点加片 → 相册多选；点 × 摘除；点图预览；长按拖动排序
     （上云由调用方在「保存」后触发：编辑期图片只是草稿，尚未落库） */
  function wireDiGrid(strip, getArr, setArr) {
    var card = Modal.card;
    if (!card) return;
    var fileInput = $('#d-img-file', card);

    function repaint() {
      strip.innerHTML = diGridHtml(getArr(), 'edit');
      strip.classList.toggle('has-local', diLocalCount(getArr()) > 0);
      var hint = $('#d-img-hint', card);
      if (hint) {
        var n = getArr().length, loc = diLocalCount(getArr());
        if (!n) hint.textContent = '一天最多 ' + DI_MAX + ' 张，长按可拖动排序';
        else if (!DB.CLOUD_ENABLED) hint.textContent = n + ' / ' + DI_MAX + ' · 仅存本机';
        else hint.textContent = n + ' / ' + DI_MAX + (loc ? ' · ' + loc + ' 张待上云' : ' · 已同步');
      }
    }

    /* 长按（触屏）/ 按住移动（鼠标）→ 拖动排序；未移动则不重绘，tap 仍走预览 */
    var drag = null, armTimer = 0, justDragged = 0;

    function beginDrag(cell, px, py, pointerId) {
      drag = { cell: cell, sx: px, sy: py, x: px, y: py, moved: false };
      cell.classList.add('is-drag');
      strip.classList.add('is-drag');
      try { cell.setPointerCapture(pointerId); } catch (err) { /* 忽略：仍可跟手 */ }
    }
    function swapTo(cell, x, y) {
      var cells = $all('.dg-cell', strip), i, r, t;
      for (i = 0; i < cells.length; i++) {
        t = cells[i];
        if (t === cell) continue;
        r = t.getBoundingClientRect();
        if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
        if (x > r.left + r.width / 2) strip.insertBefore(cell, t.nextSibling);
        else strip.insertBefore(cell, t);
        return;
      }
    }
    function commitDrag() {
      if (!drag) return;
      var cell = drag.cell, moved = drag.moved;
      clearTimeout(armTimer);
      strip.classList.remove('is-drag');
      if (cell) { cell.classList.remove('is-drag'); cell.style.transform = ''; }
      drag = null;
      if (!moved) return;                     /* 只是点了一下：交给 click 处理 */
      justDragged = Date.now();               /* 松手后浏览器仍会补一次 click，抑制掉 */
      setTimeout(function () { justDragged = 0; }, 350);
      /* DOM 顺序即最终顺序（加片格不是 .dg-cell，天然被跳过） */
      var arr = getArr().slice(), next = [];
      $all('.dg-cell', strip).forEach(function (c) {
        var idx = parseInt(c.getAttribute('data-i'), 10);
        if (!isNaN(idx) && arr[idx]) next.push(arr[idx]);
      });
      if (next.length === arr.length) { setArr(next); Modal.markDirty(); }
      repaint();
    }

    strip.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      var cell = e.target.closest ? e.target.closest('.dg-cell') : null;
      if (!cell || (e.target.closest && e.target.closest('.dg-del'))) return;
      clearTimeout(armTimer);
      drag = { pending: true, cell: cell, x0: e.clientX, y0: e.clientY, mouse: e.pointerType === 'mouse', pid: e.pointerId };
      if (drag.mouse) return;                 /* 鼠标：移动 4px 再起拖 */
      var snap = drag;
      armTimer = setTimeout(function () {     /* 触屏：按住不动 240ms 起拖 */
        if (drag !== snap || !snap.pending) return;
        drag = null;
        beginDrag(snap.cell, snap.x0, snap.y0, snap.pid);
      }, 240);
    });

    strip.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
      if (drag.pending) {
        if (!drag.mouse) {
          if (Math.abs(dx) + Math.abs(dy) > 10) { clearTimeout(armTimer); drag = null; }  /* 已是滚动/点击意图 */
          return;
        }
        if (Math.abs(dx) + Math.abs(dy) < 4) return;
        var snap = drag;
        drag = null;
        beginDrag(snap.cell, snap.x0, snap.y0, snap.pid);
      }
      if (!drag || !drag.cell) return;
      drag.x = e.clientX; drag.y = e.clientY;
      drag.moved = true;
      drag.cell.style.transform = 'translate(' + (e.clientX - drag.sx) + 'px,' + (e.clientY - drag.sy) + 'px) scale(1.05)';
      swapTo(drag.cell, e.clientX, e.clientY);
    });

    ['pointerup', 'pointercancel'].forEach(function (ev) {
      strip.addEventListener(ev, commitDrag);
    });
    window.addEventListener('blur', commitDrag);

    /* 点加片格 → 相册多选 */
    strip.addEventListener('click', function (e) {
      if (drag || justDragged) return;
      var add = e.target.closest ? e.target.closest('.dg-add') : null;
      if (add) { if (fileInput) fileInput.click(); return; }
      var del = e.target.closest ? e.target.closest('.dg-del') : null;
      if (del) {
        var cell = del.closest('.dg-cell');
        var idx = cell ? parseInt(cell.getAttribute('data-i'), 10) : NaN;
        if (!isNaN(idx)) {
          var arr = getArr().slice();
          arr.splice(idx, 1);
          setArr(arr);
          repaint();
          Modal.markDirty();
        }
        return;
      }
      var pic = e.target.closest ? e.target.closest('.dg-cell') : null;
      if (pic) openImageViewer(getArr(), parseInt(pic.getAttribute('data-i'), 10) || 0, { source: strip });
    });

    if (fileInput) {
      fileInput.addEventListener('change', function () {
        var files = Array.prototype.slice.call(fileInput.files || []);
        fileInput.value = '';
        if (!files.length) return;
        var room = DI_MAX - getArr().length;
        if (room <= 0) { toast('一天最多贴 ' + DI_MAX + ' 张'); return; }
        var cut = files.length > room;
        files = files.slice(0, room);
        strip.classList.add('is-busy');
        var arr = getArr().slice();
        files.reduce(function (chain, f) {
          return chain.then(function () {
            return diCompress(f).then(function (im) { if (im) { arr.push(im); setArr(arr.slice()); repaint(); } });
          });
        }, Promise.resolve()).then(function () {
          strip.classList.remove('is-busy');
          Modal.markDirty();
          if (cut) toast('一天最多贴 ' + DI_MAX + ' 张，多余的未添加');
        });
      });
    }
    return repaint;
  }

  /* ============================================================
     全屏图片预览层（日记配图 / 日后其他图片共用）
     ------------------------------------------------------------
     站内唯一的一层「看图台」：整屏黑底自 body 挂出（不走 Modal，避免顶掉底下的
     详情弹窗），因此必须自己接 WbBack —— 侧滑/浏览器返回先收这一层，
     收完回到原来的位置（详情或编辑表单），不跳出应用。
     手势：左右跟手切图（越界回弹）· 双击/双指缩放（放大后可平移）· 下拉过阈值关闭。
     桌面另有 ← / → 键与 hover 才显的翻页箭头。
     ============================================================ */
  var IV_MIN_SCALE = 1, IV_MAX_SCALE = 4;
  var IV_SWIPE_PX = 56, IV_SWIPE_VEL = 0.35, IV_DISMISS_PX = 110;

  function openImageViewer(images, start, meta) {
    var list = (images || []).filter(function (im) { return im && im.u; });
    if (!list.length) return;
    var i = Math.max(0, Math.min(list.length - 1, start || 0));

    var mask = document.createElement('div');
    mask.className = 'iv-mask';
    mask.innerHTML =
      '<div class="iv" role="dialog" aria-modal="true" aria-label="图片预览">' +
        '<div class="iv-bar">' +
          '<button type="button" class="iv-x" aria-label="关闭预览">' + DI_X_SVG + '</button>' +
          '<div class="iv-meta">' +
            '<span class="iv-cnt"></span>' +
            ((meta && meta.title) ? '<span class="iv-title">' + esc(meta.title) + '</span>' : '') +
          '</div>' +
          '<span class="iv-flag"></span>' +
        '</div>' +
        '<div class="iv-stage"><figure class="iv-fig"><img class="iv-img" alt="" draggable="false"></figure></div>' +
        (list.length > 1
          ? '<button type="button" class="iv-nav iv-prev" aria-label="上一张"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5"/></svg></button>' +
            '<button type="button" class="iv-nav iv-next" aria-label="下一张"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.5 5.5 16 12l-6.5 6.5"/></svg></button>'
          : '') +
      '</div>';
    document.body.appendChild(mask);

    var stage = $('.iv-stage', mask), fig = $('.iv-fig', mask), pic = $('.iv-img', mask);
    var cntEl = $('.iv-cnt', mask), flagEl = $('.iv-flag', mask);
    var closed = false, animating = false, ready = false;
    var s = IV_MIN_SCALE, tx = 0, ty = 0;

    requestAnimationFrame(function () { mask.classList.add('is-open'); });

    var bfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收看图台 */

    function close() {
      if (closed) return;
      closed = true;
      if (bfr) { WbBack.finish(bfr); bfr = null; }
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      mask.classList.add('is-closing');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 260);
    }

    /* ---------- 变换落笔 ---------- */
    function apply() {
      fig.style.transform = (s === IV_MIN_SCALE && !tx && !ty)
        ? '' : 'translate(' + tx + 'px,' + ty + 'px) scale(' + s + ')';
    }
    function bounds() {
      var r = pic.getBoundingClientRect(), st = stage.getBoundingClientRect();
      return {
        x: Math.max(0, (r.width - st.width) / 2 + 8),
        y: Math.max(0, (r.height - st.height) / 2 + 8)
      };
    }
    function clampPan() {
      if (s <= IV_MIN_SCALE + 0.01) { tx = 0; ty = 0; s = Math.max(IV_MIN_SCALE, s); return; }
      var b = bounds();
      tx = Math.max(-b.x, Math.min(b.x, tx));
      ty = Math.max(-b.y, Math.min(b.y, ty));
    }
    function setScale(next, cx, cy) {
      var st = stage.getBoundingClientRect();
      var px = (cx == null ? st.left + st.width / 2 : cx) - st.left - st.width / 2;
      var py = (cy == null ? st.top + st.height / 2 : cy) - st.top - st.height / 2;
      var s2 = Math.max(IV_MIN_SCALE, Math.min(IV_MAX_SCALE, next));
      var u = (px - tx) / s, v = (py - ty) / s;    /* 以「指点」为锚：缩放后该点仍停在原处 */
      s = s2;
      tx = px - u * s; ty = py - v * s;
      clampPan();
      apply();
      mask.classList.toggle('is-zoomed', s > IV_MIN_SCALE + 0.01);
    }

    /* ---------- 换图 ---------- */
    function show() {
      var im = list[i];
      ready = false;
      pic.onload = function () { ready = true; s = IV_MIN_SCALE; tx = ty = 0; apply(); mask.classList.remove('is-zoomed'); };
      pic.src = im.u;
      cntEl.textContent = (i + 1) + ' / ' + list.length;
      flagEl.textContent = DB.IMAGES.isCloud(im.u) ? '' : '仅存本机';
      mask.classList.toggle('is-first', i === 0);
      mask.classList.toggle('is-last', i === list.length - 1);
      /* 预取相邻两张：滑动切图时不出现白屏 */
      [i - 1, i + 1].forEach(function (k) {
        if (k < 0 || k >= list.length) return;
        var pre = new Image();
        pre.src = list[k].u;
      });
    }
    function bounce(dir) {
      fig.style.transition = 'transform .26s var(--ease-float)';
      fig.style.transform = 'translateX(' + (-dir * 22) + 'px)';
      setTimeout(function () { if (!closed) { fig.style.transition = ''; apply(); } }, 200);
    }
    function go(delta) {
      if (animating || list.length < 2) return;
      var next = i + delta;
      if (next < 0 || next >= list.length) { bounce(delta); return; }
      animating = true;
      fig.style.transition = 'transform .17s ease, opacity .17s ease';
      fig.style.opacity = '.2';
      fig.style.transform = 'translateX(' + (-delta * 28) + 'vw)';
      setTimeout(function () {
        if (closed) { animating = false; return; }
        i = next; show();
        fig.style.transition = 'none';
        fig.style.transform = 'translateX(' + (delta * 28) + 'vw)';
        requestAnimationFrame(function () {
          if (closed) { animating = false; return; }
          fig.style.transition = 'transform .24s var(--ease-float), opacity .24s ease';
          fig.style.transform = '';
          fig.style.opacity = '';
          setTimeout(function () { animating = false; if (!closed) fig.style.transition = ''; }, 260);
        });
      }, 165);
    }

    /* ---------- 手势：跟手滑动 / 缩放 / 下拉关 ---------- */
    var pts = {}, count = 0, gx = 0, gy = 0, panBase = null, pinch = null, slide = null;
    var lastTapAt = 0, lastTapX = 0, lastTapY = 0, downAt = 0;

    function resetFollow() {
      fig.style.transition = '';
      if (s <= IV_MIN_SCALE + 0.01) { slide = null; s = IV_MIN_SCALE; tx = ty = 0; apply(); mask.classList.remove('is-zoomed'); }
    }
    stage.addEventListener('pointerdown', function (e) {
      if (closed || animating) return;
      pts[e.pointerId] = { x: e.clientX, y: e.clientY };
      count++;
      try { stage.setPointerCapture(e.pointerId); } catch (err) { /* 忽略 */ }
      var ids = Object.keys(pts);
      if (ids.length >= 2) {                    /* 第二指落下 → 转成缩放 */
        var a = pts[ids[0]], b = pts[ids[1]];
        pinch = { d0: Math.max(24, Math.hypot(a.x - b.x, a.y - b.y)), s0: s,
                  mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
        slide = null; panBase = null;
        fig.style.transition = 'none';
        return;
      }
      downAt = Date.now();
      gx = e.clientX; gy = e.clientY;
      slide = (s <= IV_MIN_SCALE + 0.01) ? { dx: 0, dy: 0, axis: '', t0: downAt, x0: gx, y0: gy } : null;
      panBase = (s > IV_MIN_SCALE + 0.01) ? { tx: tx, ty: ty, x: gx, y: gy } : null;
      fig.style.transition = 'none';
    });
    stage.addEventListener('pointermove', function (e) {
      if (!pts[e.pointerId]) return;
      pts[e.pointerId] = { x: e.clientX, y: e.clientY };
      var ids = Object.keys(pts);
      if (pinch && ids.length >= 2) {
        var a = pts[ids[0]], b = pts[ids[1]];
        var d = Math.max(24, Math.hypot(a.x - b.x, a.y - b.y));
        setScale(pinch.s0 * (d / pinch.d0), (a.x + b.x) / 2, (a.y + b.y) / 2);
        return;
      }
      if (panBase) {
        tx = panBase.tx + (e.clientX - panBase.x);
        ty = panBase.ty + (e.clientY - panBase.y);
        clampPan(); apply();
        return;
      }
      if (!slide) return;
      slide.dx = e.clientX - slide.x0;
      slide.dy = e.clientY - slide.y0;
      if (!slide.axis && Math.abs(slide.dx) + Math.abs(slide.dy) > 8) {
        slide.axis = Math.abs(slide.dx) >= Math.abs(slide.dy) ? 'x' : 'y';
      }
      if (slide.axis === 'x') {
        var atEdge = (slide.dx > 0 && i === 0) || (slide.dx < 0 && i === list.length - 1);
        fig.style.transform = 'translateX(' + (atEdge ? slide.dx * 0.35 : slide.dx) + 'px)';
        if (!atEdge) fig.style.opacity = String(Math.max(0.45, 1 - Math.abs(slide.dx) / (stage.clientWidth || 1) * 1.1));
      } else if (slide.axis === 'y') {
        fig.style.transform = 'translateY(' + slide.dy + 'px) scale(' + Math.max(0.86, 1 - Math.abs(slide.dy) / 1600) + ')';
        mask.style.setProperty('--iv-fade', String(Math.max(0, 1 - Math.abs(slide.dy) / 320)));
      }
    });
    function lift(e) {
      if (!pts[e.pointerId]) return;
      delete pts[e.pointerId];
      count = Math.max(0, count - 1);
      if (Object.keys(pts).length >= 1 && pinch) { pinch = null; resetFollow(); return; }
      pinch = null; panBase = null;
      var sl = slide; slide = null;
      fig.style.transition = '';
      mask.style.removeProperty('--iv-fade');
      if (sl && sl.axis === 'y') {
        if (Math.abs(sl.dy) > IV_DISMISS_PX) { close(); return; }
        apply();
        return;
      }
      if (sl && sl.axis === 'x') {
        var dt = Math.max(1, Date.now() - sl.t0);
        var vel = Math.abs(sl.dx) / dt;
        if (Math.abs(sl.dx) > IV_SWIPE_PX || (vel > IV_SWIPE_VEL && Math.abs(sl.dx) > 24)) {
          apply();
          go(sl.dx < 0 ? 1 : -1);
          return;
        }
        apply();
        return;
      }
      /* 单点轻抬：双击 = 在点击处 1x ⇄ 2.6x */
      if (count === 0 && !sl) {
        var now = Date.now();
        if (now - lastTapAt < 320 && Math.abs(e.clientX - lastTapX) < 28 && Math.abs(e.clientY - lastTapY) < 28) {
          lastTapAt = 0;
          fig.style.transition = 'transform .26s var(--ease-float)';
          setScale(s > IV_MIN_SCALE + 0.01 ? IV_MIN_SCALE : 2.6, e.clientX, e.clientY);
          setTimeout(function () { if (!closed) fig.style.transition = ''; }, 280);
          return;
        }
        lastTapAt = now; lastTapX = e.clientX; lastTapY = e.clientY;
        if (s <= IV_MIN_SCALE + 0.01 && Date.now() - downAt < 260) {
          var st = stage.getBoundingClientRect();
          if (e.clientY - st.top > st.height - 76 || e.clientY - st.top < 64) close();   /* 上下留白区轻点即关 */
        }
      }
    }
    stage.addEventListener('pointerup', lift);
    stage.addEventListener('pointercancel', lift);

    /* ---------- 键盘 / 按钮 / 遮罩 ---------- */
    function onKey(e) {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); go(-1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); go(1); }
    }
    document.addEventListener('keydown', onKey, true);
    $('.iv-x', mask).addEventListener('click', close);
    var prev = $('.iv-prev', mask), nxt = $('.iv-next', mask);
    if (prev) prev.addEventListener('click', function () { go(-1); });
    if (nxt) nxt.addEventListener('click', function () { go(1); });
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });

    show();
    return { close: close, index: function () { return i; }, count: function () { return list.length; } };
  }

  function renderDiary(animate) {
    var list = DB.listDiary();
    var q = state.diarySearch.trim().toLowerCase();
    if (q) {
      list = list.filter(function (d) {
        return (d.date + ' ' + (d.what || '') + ' ' + (d.gain || '') + ' ' + (d.plan || '')).toLowerCase().indexOf(q) !== -1;
      });
    }
    var wrap = $('#diaryList');
    staggerList(wrap, animate);
    var empty = $('#diaryEmpty');
    if (!list.length) {
      wrap.innerHTML = '';
      empty.innerHTML = emptyHtml(DB.listDiary().length > 0, '回顾', '写下今天的三件事，让每天都有回响', 'diary');
      empty.hidden = false;
      return;
    }
    empty.hidden = true;
    wrap.innerHTML = list.map(function (d) {
      var secs = [['今天做了什么', d.what], ['有什么收获', d.gain], ['明天计划', d.plan]]
        .filter(function (p) { return p[1]; })
        .map(function (p) {
          return '<div class="diary-sec"><span class="diary-k">' + p[0] + '</span><span class="diary-v">' + esc(p[1]) + '</span></div>';
        }).join('');
      return '<article class="diary-card" data-id="' + esc(d.id) + '">' +
        '<div class="diary-head">' +
          '<div class="diary-date"><b>' + mdCN(d.date) + '</b><span>' + weekdayCN(d.date) + '</span></div>' +
          '<div class="diary-head-r">' + diBadgeHtml(d.images) + moodChip(d.mood) + '</div>' +
        '</div>' +
        '<div class="diary-body">' + (secs || '<span class="diary-v muted">（未填写内容）</span>') + '</div>' +
      '</article>';
    }).join('');
  }

  function openDiaryForm(item, opts) {
    /* 无参调用 = 今天；今天已有回顾则直接进入编辑 */
    var isEdit = !!item;
    if (!isEdit) {
      var ex = DB.getDiaryByDate(todayStr());
      if (ex) { item = ex; isEdit = true; }
    }
    var moodVal = item ? item.mood : 'ok';

    Modal.open({
      dirtyGuard: true,
      cls: 'diary-form',
      title: isEdit ? '编辑回顾 · ' + mdCN(item.date) : '写今日回顾',
      afterClose: opts && opts.back, /* 挂 back：取消/X/Esc/遮罩/保存全路径返回详情 */
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        '<div class="field-row field-diary-head" data-fg="head">' +
          '<div class="field"><label for="d-date">日期</label>' +
            '<input class="form-input" id="d-date" type="date" value="' + esc(item ? item.date : todayStr()) + '"></div>' +
          '<div class="field field-grow"><label>心情</label>' +
            '<div class="mood-row" id="d-mood">' +
              Object.keys(MOODS).map(function (k) {
                return '<button type="button" class="mood-btn' + (k === moodVal ? ' active' : '') + '" data-mood="' + k + '">' +
                  '<span class="cat-dot" style="background:' + MOODS[k].color + '"></span>' + MOODS[k].label + '</button>';
              }).join('') +
            '</div></div>' +
        '</div>' +
        '<div class="field" data-fg="what"><label>今天做了什么？</label>' +
          '<textarea class="form-input" id="d-what" rows="2" maxlength="2000" placeholder="记录今天完成的事…">' + esc(item ? item.what : '') + '</textarea>' +
          '<div class="ov-diary-cta diary-bring"><button type="button" class="btn-link" id="d-bring">＋ 带入今日完成的待办</button><button type="button" class="btn-link" id="d-bring-h">＋ 带入今日打卡</button><span class="field-hint" id="d-done-hint"></span></div>' +
        '</div>' +
        '<div class="field" data-fg="gain"><label>有什么收获？</label>' +
          '<textarea class="form-input" id="d-gain" rows="2" maxlength="2000" placeholder="新知、感悟、进步…">' + esc(item ? item.gain : '') + '</textarea></div>' +
        '<div class="field" data-fg="plan"><label>明天计划？</label>' +
          '<textarea class="form-input" id="d-plan" rows="2" maxlength="2000" placeholder="列出明天最重要的 1-3 件事">' + esc(item ? item.plan : '') + '</textarea></div>' +
        '<div class="field fg-stack" data-fg="images"><label>今日图片</label>' +
          '<div class="dg-grid" id="d-imgs"></div>' +
          '<input type="file" id="d-img-file" accept="image/*" multiple hidden>' +
          '<div class="field-hint" id="d-img-hint"></div>' +
        '</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        isEdit ? {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('日记', item.date, function () { DB.deleteDiary(item.id); });
          }
        } : null,
        { text: '取消', className: 'btn-default' },
        {
          text: isEdit ? '保存修改' : '保存',
          className: 'btn-primary', primary: true,
          onClick: function () {
            var card = Modal.card;
            var date = $('#d-date', card).value;
            var moodBtn = $('#d-mood .mood-btn.active', card);
            var mood = moodBtn ? moodBtn.getAttribute('data-mood') : 'ok';
            var what = $('#d-what', card).value;
            var gain = $('#d-gain', card).value;
            var plan = $('#d-plan', card).value;
            if (!date) { showFormError('请选择日期', 'd-date'); return; }
            var existed = DB.getDiaryByDate(date);
            if (existed && (!item || existed.id !== item.id)) {
              showFormError('该日期已有回顾，请在列表中打开那篇编辑');
              return;
            }
            try { var savedRec = DB.saveDiary({ date: date, mood: mood, what: what, gain: gain, plan: plan, images: diImgs }); }
            catch (e) {
              if (e instanceof Errors.ValidationError) { showFormError(e.message); return; }
              toast('操作失败，请重试', 'error'); return;
            }
            /* 图片先随正文落到本机，再逐张转成服务器文件引用（本地模式内部自判跳过） */
            if (savedRec) DB.IMAGES.flush(savedRec.id);
            Modal.markClean();
            Modal.close();
            toast('回顾已保存');
            renderView(state.view === 'diary' ? 'diary' : state.view);
            if (isEdit && !(opts && opts.back)) { var saved = DB.listDiary().find(function (x) { return x.id === item.id; }); if (saved) openDiaryDetail(saved); } /* 回到详情（从详情进入时由 afterClose 统一返回） */
          }
        }
      ].filter(Boolean)
    });
    mobFormify();

    /* 今日图片：草稿数组随表单存活，保存时才落库（其间编辑动作只置脏，不写云） */
    var diImgs = (item && Array.isArray(item.images)) ? item.images.slice() : [];
    var diStrip = $('#d-imgs', Modal.card);
    if (diStrip) {
      var paintDiGrid = wireDiGrid(diStrip, function () { return diImgs; }, function (v) { diImgs = v; });
      paintDiGrid();
    }

    /* 心情单选 */
    $('#d-mood', Modal.card).addEventListener('click', function (e) {
      var b = e.target.closest('.mood-btn');
      if (!b) return;
      $all('#d-mood .mood-btn', Modal.card).forEach(function (x) { x.classList.toggle('active', x === b); });
    });

    /* 带入今日完成的待办 */
    $('#d-bring', Modal.card).addEventListener('click', function () {
      var today = todayStr();
      var doneList = DB._data.todo.filter(function (t) {
        return t.done && !t.archived && t.doneAt && isoToLocalDay(t.doneAt) === today;
      });
      var hint = $('#d-done-hint', Modal.card);
      if (!doneList.length) { hint.textContent = '今天暂无已完成的待办'; return; }
      var ta = $('#d-what', Modal.card);
      var text = doneList.map(function (t) { return '· ' + t.title; }).join('\n');
      ta.value = ta.value.trim() ? (ta.value.replace(/\s+$/, '') + '\n' + text) : text;
      hint.textContent = '已带入 ' + doneList.length + ' 项';
    });
    $('#d-bring-h', Modal.card).addEventListener('click', function () {
      var date = $('#d-date', Modal.card).value || todayStr();
      var habits = DB.listHabits();
      var doneHabits = habits.filter(function (h) { return DB.isHabitDone(h.id, date); });
      /* 单日可多次打卡：超过 1 次的习惯名后标 ×次数 */
      var doneNames = doneHabits.map(function (h) {
        var n = DB.habitCount(h.id, date);
        return h.name + (n > 1 ? '×' + n : '');
      });
      var hint = $('#d-done-hint', Modal.card);
      if (!doneNames.length) { hint.textContent = '该日没有打卡记录'; return; }
      var ta = $('#d-what', Modal.card);
      var times = doneHabits.reduce(function (s, h) { return s + DB.habitCount(h.id, date); }, 0);
      var line = '· 今日打卡：' + doneNames.join('、') + '（' + doneHabits.length + '/' + habits.length + ' 项 · ' + times + ' 次）';
      var re = /· 今日打卡：[^\n]*/;
      var v = ta.value;
      /* 幂等：已带过则原位刷新该行，不重复堆叠 */
      ta.value = re.test(v) ? v.replace(re, line) : (v.trim() ? v.replace(/\s+$/, '') + '\n' + line : line);
      hint.textContent = '已带入 ' + doneNames.length + ' 个打卡';
    });
  }

  /* ============================================================
     回收站
     ============================================================ */
  var TRASH_TYPE_LABEL = { todo: '待办', memo: '备忘', special_date: '事件', habit: '习惯', diary: '日记' };

  function trashItemTitle(e) {
    var it = e.item || {};
    return it.title || it.name || (it.date ? (mdCN(it.date) + ' 的回顾') : '（无标题）');
  }

  function trashRowsHtml() {
    var list = DB.listTrash();
    return list.length
      ? list.map(function (e) {
          return '<div class="trash-row" data-id="' + esc(e.id) + '">' +
            '<div class="tr-main">' +
              '<div class="trash-title" title="' + esc(trashItemTitle(e)) + '">' + esc(trashItemTitle(e)) + '</div>' +
              '<div class="tr-meta"><span class="tag">' + (TRASH_TYPE_LABEL[e.type] || e.type) + '</span>' +
                '<span class="trash-time">' + fmtDate(e.deletedAt) + ' 删除</span></div>' +
            '</div>' +
            '<div class="tr-acts">' +
              '<button type="button" class="btn btn-default btn-sm" data-trash-restore="' + esc(e.id) + '">恢复</button>' +
              '<button type="button" class="cat-act cat-act-del" data-trash-purge="' + esc(e.id) + '" aria-label="彻底删除" title="彻底删除">' + SVG_TRASH + '</button>' +
            '</div></div>';
        }).join('')
      : '<div class="cat-row-empty">回收站是空的</div>';
  }

  function openTrashBin(opts) {
    opts = opts || {};
    var TB_HEAD_ICO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l.9 12.2a1 1 0 0 0 1 .8h7.2a1 1 0 0 0 1-.8L17.5 7"/></svg>';
    Modal.open({
      title: '回收站',
      cls: 'dd-modal', /* 灰底画布 + 白色圆角卡，与待办/习惯详情同一语言 */
      pullClose: true, /* 移动端：内容滚到顶后下拉即关（走正常 close 返回个人中心） */
      body:
        '<div class="dd-group tb-card">' +
          '<div class="dd-row tb-head"><span class="dd-ico">' + TB_HEAD_ICO + '</span><span class="dd-k">已删除内容 · 保留 30 天后自动清除</span><span class="dd-v"><span class="chip-cnt" id="trashCnt">' + DB.listTrash().length + ' 项</span></span></div>' +
          '<div class="trash-rows" id="trashRows">' + trashRowsHtml() + '</div>' +
        '</div>',
      afterClose: opts.back, /* 从个人中心进入：X / 遮罩 / Esc / 完成后均原位返回 */
      actions: [
        {
          text: '清空回收站', className: 'btn-danger', align: 'left',
          onClick: function () {
            if (!DB.listTrash().length) { Modal.close(); return; }
            /* 不提前关卡：手机端抽屉叠在回收站之上；
               旧写法先 Modal.close(true) 再 onOk 里 return false，
               会让抽屉永远关不掉（cfSheet 把 false 当作「校验失败，留在原地」） */
            confirmModal({
              title: '清空回收站',
              message: '将彻底删除全部条目，<b>不可恢复</b>。',
              okText: '清空',
              danger: true,
              onOk: function () {
                var n = DB.emptyTrash();
                toast('已清空 ' + n + ' 项');
                renderView(state.view);
                /* 原位重开回收站：两端都能看到「回收站是空的」，路径不断链 */
                openTrashBin(opts);
              }
            });
          }
        },
        { text: '完成', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); renderAll(); } }
      ]
    });
    mobDetailify(); /* 移动端：完成转通栏胶囊、清空降为红字行 */

    var rows = $('#trashRows', Modal.card);
    function syncTrashCnt() { var c = $('#trashCnt', Modal.card); if (c) c.textContent = DB.listTrash().length + ' 项'; }
    rows.addEventListener('click', function (e) {
      var rs = e.target.closest('[data-trash-restore]');
      if (rs) {
        if (DB.restoreTrash(rs.getAttribute('data-trash-restore'))) {
          toast('已恢复');
          renderAll();
          rows.innerHTML = trashRowsHtml();
          syncTrashCnt();
        }
        return;
      }
      var pg = e.target.closest('[data-trash-purge]');
      if (pg) {
        DB.purgeTrash(pg.getAttribute('data-trash-purge'));
        rows.innerHTML = trashRowsHtml();
        syncTrashCnt();
        toast('已彻底删除');
      }
    });
  }

  /* ---- 已归档（个人中心统一归档区） ---- */
  function openArchiveBin(opts) {
    opts = opts || {};
    function archRowsHtml() {
      var list = DB.listArchived();
      return list.length
        ? list.map(function (t) {
            return '<div class="trash-row" data-id="' + esc(t.id) + '">' +
              '<div class="tr-main">' +
                '<div class="trash-title" title="' + esc(t.title) + '">' + esc(t.title) + '</div>' +
                '<div class="tr-meta"><span class="tag">待办</span>' +
                  '<span class="trash-time">' + fmtDate(t.archivedAt || t.createdAt) + ' 归档</span></div>' +
              '</div>' +
              '<div class="tr-acts">' +
                '<button type="button" class="btn btn-default btn-sm" data-arch-restore="' + esc(t.id) + '">恢复</button>' +
                '<button type="button" class="cat-act cat-act-del" data-arch-del="' + esc(t.id) + '" aria-label="删除" title="删除">' + SVG_TRASH + '</button>' +
              '</div></div>';
          }).join('')
        : '<div class="cat-row-empty">暂无归档 · 在待办列表左滑卡片即可归档</div>';
    }
    var ARCH_HEAD_ICO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="4" rx="1"/><path d="M5 8.5V19a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8.5"/><path d="M10 12.5h4"/></svg>';
    function refreshRows() {
      var box = $('#archRows', Modal.card);
      if (box) box.innerHTML = archRowsHtml();
      var c = $('#archCnt', Modal.card);
      if (c) c.textContent = DB.listArchived().length + ' 条';
    }
    Modal.open({
      title: '已归档',
      cls: 'dd-modal', /* 灰底画布 + 白色圆角卡，与待办/习惯详情同一语言 */
      pullClose: true, /* 移动端：内容滚到顶后下拉即关（走正常 close 返回个人中心） */
      body:
        '<div class="dd-group tb-card">' +
          '<div class="dd-row tb-head"><span class="dd-ico">' + ARCH_HEAD_ICO + '</span><span class="dd-k">归档的待办</span><span class="dd-v"><span class="chip-cnt" id="archCnt">' + DB.listArchived().length + ' 条</span></span></div>' +
          '<div class="trash-rows" id="archRows">' + archRowsHtml() + '</div>' +
          '<div class="tb-tip">归档不进入列表与统计；「恢复」回到待办，「删除」进回收站（30 天可找回）。</div>' +
        '</div>',
      afterClose: opts.back, /* 从个人中心进入：关闭均原位返回并恢复浏览位置 */
      actions: [
        { text: '完成', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); renderAll(); } }
      ]
    });
    mobDetailify(); /* 移动端：完成转通栏胶囊 */
    $('#archRows', Modal.card).addEventListener('click', function (e) {
      var rs = e.target.closest('[data-arch-restore]');
      if (rs) {
        try { DB.unarchiveTodo(rs.getAttribute('data-arch-restore')); } catch (err) { handleMutationError(err); return; }
        toast('已恢复到待办列表');
        renderAll();
        refreshRows();
        return;
      }
      var dl = e.target.closest('[data-arch-del]');
      if (dl) {
        try { DB.deleteTodo(dl.getAttribute('data-arch-del')); } catch (err) { handleMutationError(err); return; }
        toast('已移入回收站');
        renderAll();
        refreshRows();
      }
    });
  }

  /* ============================================================
     桌面提醒 + 自动备份（页面活跃期间运行）
     ============================================================ */
  function remindEnabled() {
    try { return localStorage.getItem('wb_reminder') !== '0'; } catch (e) { return true; }
  }
  function autoBackupEnabled() {
    try { return localStorage.getItem('wb_autobackup') !== '0'; } catch (e) { return true; }
  }

  function updateRemindHint() {
    var el = $('#pf-remind-hint');
    if (!el || ($('#modalMask') && $('#modalMask').hidden)) return;
    var perm = window.Notification ? Notification.permission : 'denied';
    if (!remindEnabled()) { el.textContent = '已关闭桌面提醒'; return; }
    el.textContent = perm === 'granted'
      ? '已授权桌面通知，页面打开期间每日汇总一次'
      : perm === 'denied'
        ? '通知权限被浏览器拒绝，请在浏览器设置中允许'
        : '尚未授权：开启后浏览器会询问是否允许通知';
  }

  function requestRemindPermission() {
    if (!window.Notification) { toast('当前浏览器不支持桌面通知', 'warn'); return; }
    if (Notification.permission === 'default') {
      Notification.requestPermission().then(function () { updateRemindHint(); });
    }
  }

  /* 每分钟检查一次；每天只发一条汇总（今日到期 + 逾期），localStorage 防重 */
  function remindTick() {
    if (!remindEnabled()) return;
    if (!window.Notification || Notification.permission !== 'granted') return;
    if (!DB._data) return;
    var today = todayStr();
    var key = 'wb_notified_' + today;
    try {
      if (localStorage.getItem(key)) return;
      localStorage.setItem(key, '1');
    } catch (e) { return; }
    var todayDue = 0, overdue = 0;
    DB._data.todo.forEach(function (t) {
      if (t && !t.done && t.due) {
        if (t.due === today) todayDue++;
        else if (t.due < today) overdue++;
      }
    });
    if (!todayDue && !overdue) return;
    var lines = [];
    if (todayDue) lines.push('今日到期 ' + todayDue + ' 项');
    if (overdue) lines.push('已逾期 ' + overdue + ' 项');
    var n = new Notification('待办提醒 · ' + APP_NAME, { body: lines.join('，'), tag: 'wb-daily' });
    n.onclick = function () {
      window.focus();
      if (state.view !== 'todo') switchView('todo');
    };
  }
  function initReminder() {
    /* App 内：提醒排进系统闹钟（锁屏、离线、进程被杀都照响），无需页面轮询 */
    if (window.KlogNative && window.KlogNative.isApp) { window.KlogNative.sync('init'); return; }
    remindTick();
    setInterval(remindTick, 60000);
  }

  /* 每日首开静默备份到服务器（backups/，保留最近 7 份；仅登录态，本地模式无服务器存储） */
  function autoBackup(force) {
    try {
      if (!DB.CLOUD_ENABLED) return;
      var today = todayStr();
      if (!force) {
        if (!autoBackupEnabled()) return;
        if (localStorage.getItem('wb_lastbackup') === today) return;
      }
      if (!DB._data) return;
      var d = DB._data;
      if (!d.todo.length && !d.memo.length && !d.special_date.length && !d.diary.length) return;
      fetch('api/backup.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(DB.exportData())
      }).then(function (r) { return r.json(); }).then(function (res) {
        if (res && res.ok) {
          try { localStorage.setItem('wb_lastbackup', today); } catch (e) { /* 忽略 */ }
        }
      }).catch(function () { /* 失败静默，明天或下次开启重试 */ });
    } catch (e) { /* 忽略 */ }
  }
  function initAutoBackup() { autoBackup(false); }

  /* 快捷键：Ctrl/Cmd+N 新增当前模块项；Ctrl/Cmd+S 保存当前弹窗 */
  function initShortcuts() {
    document.addEventListener('keydown', function (e) {
      if (!(e.ctrlKey || e.metaKey)) return;
      var k = (e.key || '').toLowerCase();
      if (k === 'n') {
        e.preventDefault();
        if ($('#modalMask') && !$('#modalMask').hidden) return; /* 弹窗中不抢焦点 */
        var fn = FAB_ACTIONS[state.view] || openTodoForm;
        fn();
      } else if (k === 's') {
        e.preventDefault();
        var mask = $('#modalMask');
        if (!mask || mask.hidden) return;
        var btn = $('#modalFoot [data-primary]');
        if (btn) btn.click();
      }
    });
  }

  /* ============================================================
     详情弹窗：点击卡片/行 = 查看 + 内联操作；编辑走表单
     ============================================================ */
  function openEditForm(type, id) {
    if (type === 'todo') openTodoForm(DB.getTodo(id));
    else if (type === 'memo') openMemoForm(DB.getMemo(id));
    else if (type === 'date') openDateForm(DB.getSpecial(id));
    else if (type === 'habit') openHabitForm(DB.getHabit(id));
    else if (type === 'diary') { var d = DB.listDiary(); for (var i = 0; i < d.length; i++) if (d[i].id === id) { openDiaryForm(d[i]); return; } }
  }

  function detailKV(k, v) {
    return v ? '<div class="detail-kv"><span class="diary-k">' + k + '</span><span class="detail-v">' + v + '</span></div>' : '';
  }

  /* ---- 待办详情（子任务可直接勾选完成） ---- */
  function openTodoDetail(item) {
    var cat = item.category ? DB.getCategory(item.category) : null;
    var subs = item.subtasks || [];
    var subDone = subs.filter(function (x) { return x.done; }).length;
    var priStars = item.priority === 'high' ? '✦✦✦' : item.priority === 'low' ? '✦' : '✦✦';
    var rep = repeatLabel(item.repeat);
    /* 与备忘/事件详情同一套 dd-row 图标行语言：局部图标 + row() 助手 */
    function ico(p) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
    }
    function row(i, k, v) {
      return '<div class="dd-row"><span class="dd-ico">' + i + '</span><span class="dd-k">' + k + '</span><span class="dd-v">' + v + '</span></div>';
    }
    var TD_ICO = {
      flag: '<path d="M6 21V4"/><path d="M6 4.5h11l-2.2 3.5L17 11.5H6"/>',
      cal: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 9.5h17M8 3.2V6.5M16 3.2V6.5"/>',
      tag: '<path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.83 0L4 13.24A2 2 0 0 1 3.4 11.83V5.4A2 2 0 0 1 5.4 3.4h6.43a2 2 0 0 1 1.41.58l7.2 7.2a2 2 0 0 1 0 2.83z"/><circle cx="8" cy="8" r="1.3"/>',
      rep: '<path d="M17 2.5L20.5 6 17 9.5"/><path d="M3.5 11.5V10a4 4 0 0 1 4-4H20.5"/><path d="M7 21.5L3.5 18 7 14.5"/><path d="M20.5 12.5V14a4 4 0 0 1-4 4H3.5"/>',
      clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
      list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.6" cy="6" r="1.1"/><circle cx="4.6" cy="12" r="1.1"/><circle cx="4.6" cy="18" r="1.1"/>'
    };
    var dueRow = '';
    if (item.due) {
      var dfd = daysFromToday(item.due);
      var tag = dfd < 0 ? '<span class="tag tag-bad">过期 ' + (-dfd) + ' 天</span>'
        : dfd === 0 ? '<span class="tag tag-warn">今天</span>'
        : '<span class="tag">' + dfd + ' 天后</span>';
      dueRow = row(ico(TD_ICO.cal), '截止', fmtDate(item.due) + ' ' + weekdayCN(item.due) + ' ' + tag);
    }
    var subRows = subs.map(function (x) {
      return '<label class="sub-row' + (x.done ? ' is-done' : '') + '" data-sid="' + esc(x.id) + '">' +
        '<input type="checkbox" class="dt-sub-check"' + (x.done ? ' checked' : '') + '>' +
        '<span class="sub-title">' + esc(x.title) + '</span></label>';
    }).join('');

    Modal.open({
      title: '待办详情',
      cls: 'dd-modal', /* 灰底画布 + 白色圆角卡，与备忘/事件/回顾详情同一语言 */
      chain: true, /* 入场方向统一：详情页一律自下而上浮入（见 workbench.css「.dd-modal.chain-in → cascadeIn」收口），不随打开路径忽上忽下 */
      body:
        '<div class="dd-hero td-hero">' +
          '<div class="td-hero-row">' +
            '<label class="todo-check"><input type="checkbox" id="dt-done"' + (item.done ? ' checked' : '') + '>' +
            '<span class="todo-check-box"><svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 6.5l2.5 2.5L10 3.5"/></svg></span></label>' +
            '<div class="td-title' + (item.done ? ' is-done' : '') + '" id="dt-title">' + esc(item.title) + '</div>' +
          '</div>' +
        '</div>' +
        (item.desc ? '<div class="dd-group td-desc-group"><div class="td-desc">' + esc(item.desc) + '</div></div>' : '') +
        '<div class="dd-group td-info">' +
          row(ico(TD_ICO.flag), '优先级', priStars) +
          dueRow +
          (cat ? row(ico(TD_ICO.tag), '分类', '<span class="td-cat"><span class="cat-dot" style="background:' + esc(cat.color) + '"></span>' + esc(cat.name) + '</span>') : '') +
          (rep ? row(ico(TD_ICO.rep), '重复', esc(rep)) : '') +
          row(ico(TD_ICO.clock), '创建于', fmtDateTime(item.createdAt)) +
        '</div>' +
        (subs.length
          ? '<div class="dd-group td-subs">' +
              '<div class="dd-row td-sub-head"><span class="dd-ico">' + ico(TD_ICO.list) + '</span><span class="dd-k">子任务</span><span class="dd-v"><span class="chip-cnt" id="dt-subcnt">' + subDone + '/' + subs.length + '</span></span></div>' +
              '<div class="sub-editor td-sub-editor" id="dt-subs">' + subRows + '</div>' +
            '</div>'
          : ''),
      actions: [
        {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('待办', item.title, function () { DB.deleteTodo(item.id); });
          }
        },
        { text: '取消', className: 'btn-default' },
        { text: '编辑', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); openTodoForm(DB.getTodo(item.id), { back: function () { var nd = DB.getTodo(item.id); if (nd) openTodoDetail(nd); } }); } }
      ]
    });
    mobDetailify();

    /* 把数据层的父子联动/快照回滚同步到弹窗内子任务勾选与进度（无需刷新）。
       opts.stagger=true：父级联动的瀑布式逐行动效（自上而下依次勾/依次取消）；否则立即同步 */
    var subAnimSeq = 0;
    function syncDetailSubs(t, opts) {
      var box = $('#dt-subs', Modal.card);
      if (!box) return;
      var list = t.subtasks || [];
      var rows = $all('.sub-row', box);
      var stagger = !!(opts && opts.stagger) &&
        !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
      var seq = ++subAnimSeq;
      var step = rows.length > 8 ? 45 : 85;
      rows.forEach(function (row, idx) {
        var apply = function () {
          var sid = row.getAttribute('data-sid');
          var s = null;
          for (var i = 0; i < list.length; i++) { if (list[i] && list[i].id === sid) { s = list[i]; break; } }
          var on = !!(s && s.done);
          var inp = row.querySelector('input');
          if (inp && inp.checked !== on) {
            inp.checked = on;
            if (stagger) {
              inp.classList.remove('sub-pop'); row.classList.remove('sub-flash');
              void inp.offsetWidth; /* 强制回流以重启动画 */
              inp.classList.add('sub-pop'); row.classList.add('sub-flash');
            }
          }
          row.classList.toggle('is-done', on);
        };
        if (stagger && idx > 0) {
          setTimeout(function () { if (seq === subAnimSeq) apply(); }, idx * step);
        } else {
          apply();
        }
      });
      var dn = list.filter(function (x) { return x.done; }).length;
      var cnt = $('#dt-subcnt', Modal.card), flag = $('#dt-subflag', Modal.card);
      if (cnt) cnt.textContent = dn + '/' + list.length;
      if (flag) flag.textContent = dn + '/' + list.length;
    }

    $('#dt-done', Modal.card).addEventListener('change', function () {
      var nd = this.checked;
      try { DB.updateTodo(item.id, { done: nd }); } catch (e) { handleMutationError(e); return; }
      var fresh = DB.getTodo(item.id);
      if (fresh) item = fresh;
      $('#dt-title', Modal.card).classList.toggle('is-done', !!item.done);
      syncDetailSubs(item, { stagger: true });
      renderView(state.view);
      if (nd) toast('已完成' + (item.repeat ? '，已生成下一次' : ''));
    });
    /* 点标题 / 整块英雄白卡 = 一键完成；勾选框自身走原生切换，跳过以免二次取反 */
    var hero = $('.td-hero', Modal.card);
    if (hero) hero.addEventListener('click', function (e) {
      if (e.target.closest('.todo-check')) return;
      var cb = $('#dt-done', Modal.card);
      if (!cb) return;
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event('change', { bubbles: true }));
    });
    var subsBox = $('#dt-subs', Modal.card);
    if (subsBox) {
      subsBox.addEventListener('change', function (e) {
        var cb = e.target.closest('.dt-sub-check');
        if (!cb) return;
        var sid = cb.closest('.sub-row').getAttribute('data-sid');
        var cur = DB.getTodo(item.id);
        var list = (cur.subtasks || []).map(function (x) {
          return x.id === sid ? { id: x.id, title: x.title, done: cb.checked } : x;
        });
        var wasDone = !!(cur && cur.done);
        try { DB.updateTodo(item.id, { subtasks: list }); } catch (err) { handleMutationError(err); return; }
        var fresh = DB.getTodo(item.id);
        if (fresh) {
          item = fresh;
          var mainCb = $('#dt-done', Modal.card);
          if (mainCb && mainCb.checked !== !!fresh.done) mainCb.checked = !!fresh.done;
          $('#dt-title', Modal.card).classList.toggle('is-done', !!fresh.done);
          syncDetailSubs(fresh);
          /* 唯一的完成提示：子任务全部完成 → 待办完成；反向重开静默 */
          if (!wasDone && fresh.done) toast('已完成' + (fresh.repeat ? '，已生成下一次' : ''));
        }
        renderView(state.view);
      });
    }
  }

  /* ---- 备忘详情（Markdown 渲染正文 + 置顶） ---- */
  function openMemoDetail(item) {
    var tags = (item.tags || []).map(function (t) { return '<span class="tag">' + esc(t) + '</span>'; }).join('');
    function ico(p) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
    }
    function row(i, k, v) {
      return '<div class="dd-row"><span class="dd-ico">' + i + '</span><span class="dd-k">' + k + '</span><span class="dd-v">' + v + '</span></div>';
    }
    var edited = item.updatedAt && item.updatedAt !== item.createdAt;
    Modal.open({
      title: '备忘详情',
      cls: 'dd-modal', /* 灰底画布 + 白色圆角卡（与事件详情同一语言） */
      body:
        '<div class="dd-hero">' +
          '<div class="md-hero-top">' +
            '<div class="dd-hero-name">' + esc(item.title) + '</div>' +
            '<button type="button" class="memo-pin' + (item.pinned ? ' on' : '') + '" id="dt-pin" aria-pressed="' + (item.pinned ? 'true' : 'false') + '" aria-label="置顶" title="' + (item.pinned ? '取消置顶' : '置顶') + '">' + SVG_PIN + '</button>' +
          '</div>' +
          (tags ? '<div class="memo-tags md-hero-tags">' + tags + '</div>' : '') +
        '</div>' +
        '<div class="dd-group md-doc">' +
          '<div class="md-body" id="dt-mdbody" data-mid="' + esc(item.id) + '">' + (mdToHtml(item.content) || '<span class="md-empty-hint">（无内容）</span>') + '</div>' +
        '</div>' +
        '<div class="dd-group">' +
          row(ico('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'), '创建于', fmtDateTime(item.createdAt)) +
          (edited ? row(ico('<path d="M17 2.5L20.5 6 17 9.5"/><path d="M3.5 11.5V10a4 4 0 0 1 4-4H20.5"/><path d="M7 21.5L3.5 18 7 14.5"/><path d="M20.5 12.5V14a4 4 0 0 1-4 4H3.5"/>'), '更新于', fmtDateTime(item.updatedAt)) : '') +
        '</div>',
      actions: [
        {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('备忘', item.title, function () { DB.deleteMemo(item.id); });
          }
        },
        { text: '取消', className: 'btn-default' },
        { text: '编辑', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); openMemoForm(DB.getMemo(item.id), { back: function () { var nd = DB.getMemo(item.id); if (nd) openMemoDetail(nd); } }); } }
      ]
    });
    mobDetailify();
    /* Markdown 组件是懒加载：首开可能只渲染出原文，组件到位后静默补一次重绘 */
    if (typeof window.marked === 'undefined') {
      var mid = item.id, src = item.content;
      ensureMarked(function (ok) {
        if (!ok) return;
        var box = $('#dt-mdbody', Modal.card);
        if (!box || box.getAttribute('data-mid') !== mid) return; /* 已切到别的备忘/弹窗：不写 */
        box.innerHTML = mdToHtml(src) || '<span class="md-empty-hint">（无内容）</span>';
      });
    }
    $('#dt-pin', Modal.card).addEventListener('click', function () {
      DB.toggleMemoPin(item.id);
      item = DB.getMemo(item.id);
      this.classList.toggle('on', item.pinned);
      this.setAttribute('aria-pressed', item.pinned ? 'true' : 'false');
      this.title = item.pinned ? '取消置顶' : '置顶';
      renderView(state.view);
    });
  }

  /* ---- 事件详情（参考 iOS 分组卡片式：灰底画布 + 白色圆角卡 + 巨型倒计时） ---- */
  function openDateDetail(ev) {
    var item = DB.listSpecial().filter(function (x) { return x.id === ev.id; })[0] || ev;
    var dd = item.days;            /* null=无效；>0 还有；0 今天；<0 已过去（一次性） */
    var since = item.since;        /* 起始日距今（showSince 用） */
    var lun = window.Lunar ? Lunar.solarToLunar(item.date) : null;
    function ico(p) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
    }
    function row(i, k, v) {
      return '<div class="dd-row"><span class="dd-ico">' + i + '</span><span class="dd-k">' + k + '</span><span class="dd-v">' + v + '</span></div>';
    }
    /* 年龄（周岁）：生日按周年计；纪念日显示「第 N 年」 */
    var years = (function () {
      var p = String(item.date).split('-').map(Number), now = new Date();
      if (p.length !== 3 || isNaN(p[0])) return null;
      var y = now.getFullYear() - p[0];
      if (now.getMonth() + 1 < p[1] || (now.getMonth() + 1 === p[1] && now.getDate() < p[2])) y--;
      return y;
    })();
    var sign = (function () {
      var md = String(item.date).slice(5).split('-').map(Number);
      var cut = [20,19,21,20,21,22,23,23,23,24,23,22];
      var nm = ['摩羯座','水瓶座','双鱼座','白羊座','金牛座','双子座','巨蟹座','狮子座','处女座','天秤座','天蝎座','射手座','摩羯座'];
      return md.length === 2 && md[0] >= 1 && md[0] <= 12 ? nm[md[1] < cut[md[0] - 1] ? md[0] - 1 : md[0]] : '—';
    })();
    var zodiac = lun ? '鼠牛虎兔龙蛇马羊猴鸡狗猪'.charAt(((lun.y - 4) % 12 + 12) % 12) : '—';
    var cap = dd === 0 ? '就是今天' : dd > 0 ? '还有' : dd < 0 ? '已过去' : '日期无效';
    var big = dd === 0
      ? '<span class="dd-num dd-num-today">今天</span>'
      : '<span class="dd-num">' + (dd === null ? '—' : Math.abs(dd)) + '</span><span class="dd-unit">天</span>';
    var dateCN = item.date.slice(0, 4) + '年' + mdCN(item.date);
    var tm = typeMeta(item.type);
    var body =
      '<div class="dd-hero">' +
        '<div class="dd-hero-head">' +
          '<span class="badge badge-sm" style="--bdot:' + esc(tm.color) + '">' + esc(tm.label) + '</span>' +
          yearsTagHtml(item.type, item.date) +
        '</div>' +
        '<div class="dd-hero-name">' + esc(item.name) + '</div>' +
        '<div class="dd-hero-count"><span class="dd-cap">' + cap + '</span><div class="dd-big">' + big + '</div></div>' +
        '<div class="dd-hero-date">' + dateCN + ' · ' + weekdayCN(item.date) + (item.repeat ? ' · 每年' : ' · 一次性') + '</div>' +
        (item.showSince && since !== null && since !== undefined
          ? '<div class="dd-hero-since">至今 <b>' + since + '</b> 天</div>' : '') +
      '</div>' +
      '<div class="dd-group">' +
        row(ico('<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M8 3v4M16 3v4M3 10h18"/>'), '公历日期', dateCN) +
        row(ico('<path d="M20.2 13.8A8.6 8.6 0 1 1 10.2 3.8a7 7 0 0 0 10 10z"/>'), '农历日期', lun ? (lun.y + '年' + Lunar.fullText(lun)) : '—') +
        (item.type === 'birthday'
          ? row(ico('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.4"/>'), '生肖', zodiac) +
            row(ico('<path d="M12 3.4l2.3 6.3 6.3 2.3-6.3 2.3-2.3 6.3-2.3-6.3-6.3-2.3 6.3-2.3z"/>'), '星座', sign)
          : '') +
        (years !== null && years >= 0
          ? row(ico('<path d="M12 21V12"/><path d="M12 12c0-4.4-3.2-7.6-7.6-7.6C4.4 8.8 7.6 12 12 12z"/><path d="M12 12c0-4.4 3.2-7.6 7.6-7.6C19.6 8.8 16.4 12 12 12z"/>'),
              item.type === 'birthday' ? '年龄' : '第几年',
              item.type === 'birthday' ? years + ' 岁' : '第 ' + (years + 1) + ' 年')
          : '') +
      '</div>' +
      '<div class="dd-group">' +
        row(ico('<path d="M17 3.5L20 6.5 17 9.5"/><path d="M4 12V10.5a4 4 0 0 1 4-4h12"/><path d="M7 20.5L4 17.5 7 14.5"/><path d="M20 12v1.5a4 4 0 0 1-4 4H4"/>'), '重复', item.repeat ? '每年重复' : '一次性') +
        (dd !== null && dd >= 0
          ? row(ico('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'), '下次发生', item.nextDate + ' · ' + weekdayCN(item.nextDate)) : '') +
        (item.note
          ? row(ico('<path d="M6.5 3.5h11A1.5 1.5 0 0 1 19 5v14a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19V5a1.5 1.5 0 0 1 1.5-1.5z"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4"/>'), '备注', esc(item.note)) : '') +
      '</div>';
    Modal.open({
      title: '事件详情',
      body: body,
      actions: [
        {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('纪念日', item.name, function () { DB.deleteSpecial(item.id); });
          }
        },
        { text: '取消', className: 'btn-default' },
        { text: '编辑', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); openDateForm(DB.getSpecial(item.id), { back: function () { var nd = DB.getSpecial(item.id); if (nd) openDateDetail(nd); } }); } }
      ],
      cls: 'dd-modal'
    });
    mobDetailify();
  }

  /* ---- 习惯详情 ---- */
  function openHabitDetail(h) {
    if (!h) return;
    /* 热力面板状态：当前视图 + 当期锚点日（翻页只推锚点，Tab 切换不跳期） */
    var st = { view: 'week', at: new Date() };
    /* 与待办/备忘详情同一套 dd-row 图标行语言 */
    function ico(p) {
      return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
    }
    function row(i, k, v) {
      return '<div class="dd-row"><span class="dd-ico">' + i + '</span><span class="dd-k">' + k + '</span><span class="dd-v">' + v + '</span></div>';
    }
    var HB_ICO = {
      flame: '<path d="M12 3c1 3-1.5 4.2-1.5 6.5A2.5 2.5 0 0 0 13 12c.8 0 1.4-.5 1.6-1.2.9 1 1.4 2.2 1.4 3.4A5.5 5.5 0 0 1 6.5 14c0-3.6 3.3-5.1 5.5-11z"/>',
      target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
      check: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-4.9"/>',
      clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'
    };
    Modal.open({
      title: '习惯详情',
      cls: 'hm-modal dd-modal', /* hm-modal 供热力面板年视图所需宽度，dd-modal 供灰底画布 + 白色圆角卡语言 */
      body:
        '<div class="dd-hero hb-hero">' +
          '<div class="hb-hero-row">' +
            '<span class="cat-dot hb-hero-dot" style="background:' + esc(h.color) + '"></span>' +
            '<div class="hb-hero-name">' + esc(h.name) + '</div>' +
            '<span class="hb-ctl" id="dtCtl"></span>' +
          '</div>' +
        '</div>' +
        '<div class="dd-group hb-stats" id="dtMeta"></div>' +
        '<div class="hm-panel" id="hmPanel"></div>',
      actions: [
        {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
            /* 同编辑页：交给 confirmDelete 的 closeUnderlying 在删除成功后收卡 */
            confirmDelete('习惯', h.name, function () { DB.removeHabit(h.id); },
              '打卡记录一并移入回收站，30 天内可恢复。');
          }
        },
        { text: '取消', className: 'btn-default' },
        { text: '编辑', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); openHabitForm(DB.getHabit(h.id), { back: function () { var nd = DB.getHabit(h.id); if (nd) openHabitDetail(nd); } }); } }
      ]
    });
    mobDetailify();
    /* 监听只挂每次 open 新建的节点：Modal 卡片是复用元素，挂它会跨弹窗累积监听器 */
    var panel = $('#hmPanel', Modal.card), ctl = $('#dtCtl', Modal.card);
    function paint(mode) {
      var cur = DB.getHabit(h.id);
      if (!cur) return;
      ctl.innerHTML = habitCheckCtl(cur, todayStr());
      $('#dtMeta', Modal.card).innerHTML =
        row(ico(HB_ICO.flame), '连续打卡', '<span class="hb-num">' + DB.habitStreak(cur.id) + '</span> 天') +
        row(ico(HB_ICO.target), '本月完成', '<span class="hb-num">' + DB.habitMonthRate(cur.id) + '%</span>') +
        row(ico(HB_ICO.check), '今日', '<span class="hb-num" id="dtTodayNum">' + DB.habitCount(cur.id, todayStr()) + '</span> 次') +
        row(ico(HB_ICO.clock), '创建于', fmtDate(cur.createdAt));
      panel.setAttribute('style', hmVars(cur.color)); /* 四档随习惯色（图例/格子继承变量） */
      if (mode === 'check') {
        /* 打卡：格子与统计原位更新，面板不重建、不重播入场；只给钮与今日格一点反馈 */
        hmRefresh(panel, cur, st);
        var btn = ctl.querySelector('[data-habit-toggle]');
        if (btn) btn.classList.add('btn-pop');
        var cell = $('.hm-cell.is-today', panel);
        if (cell) cell.classList.add('hm-pulse');
        var num = document.getElementById('dtTodayNum');
        if (num) num.classList.add('btn-pop');
        return;
      }
      panel.innerHTML = hmPanelHtml(cur, st);
      var sc = $('.hm-year-scroll', panel), tc = $('.hm-dot-c.is-today', panel);
      if (sc) {
        /* 年视图把「今天」停在可视区右缘（留 24px 余量）：历史向左继续滑，未来空档不占画幅 */
        if (tc) sc.scrollLeft += tc.getBoundingClientRect().right - sc.getBoundingClientRect().right + 24;
        else sc.scrollLeft = 0;
      }
      if (mode === 'tab' || mode === 'prev' || mode === 'next') {
        /* 方向可感知：下一页新内容从右进，上一页从左进，切视图只做上移淡入。
           只动 transform / opacity（合成层），不给 .hm-body 加 overflow:hidden——
           那会把今日格外圈 1.5px 的黑环裁掉，看起来像「顶部先缺一下再补回来」 */
        var cls = mode === 'tab' ? 'hm-in-up' : (mode === 'next' ? 'hm-in-left' : 'hm-in-right');
        $all('.hm-swap', panel).forEach(function (n) { n.classList.add(cls); });
        var body = $('.hm-body', panel);
        if (body) body.classList.add(cls);
      }
    }
    paint();
    panel.addEventListener('click', function (e) {
      var tab = e.target.closest('[data-hm-view]');
      if (tab) { st.view = tab.getAttribute('data-hm-view'); paint('tab'); return; }
      var step = e.target.closest('[data-hm-step]');
      if (step) {
        var dir = parseInt(step.getAttribute('data-hm-step'), 10) || 0;
        hmStep(st, dir);
        paint(dir === 0 ? 'tab' : (dir > 0 ? 'next' : 'prev'));
      }
    });
    /* 与概览时间线 / 习惯页同一套绑定：短按加一次、− 减一次、长按主钮取消今天 */
    bindHabitCheck(ctl, function () {
      paint('check');
      renderView(state.view);
    });
  }

  /* ---- 日记详情 ---- */
  /* 回顾详情——杂志三问条目（独立结构，不复用共用的 detail-kv） */
  function ddEntry(no, label, text) {
    var body = text ? esc(text).replace(/\n/g, '<br>') : '<span class="dd-empty">这一栏当天没有填写</span>';
    return '<section class="dd-entry' + (text ? '' : ' is-empty') + '">' +
      '<span class="dd-no" aria-hidden="true">' + no + '</span>' +
      '<div class="dd-entry-main">' +
        '<h4 class="dd-label">' + label + '</h4>' +
        '<div class="dd-text">' + body + '</div>' +
      '</div>' +
    '</section>';
  }

  function openDiaryDetail(d) {
    var mood = MOODS[d.mood] || MOODS.ok;
    var dp = String(d.date || '').split('-');
    var dayNum = dp.length === 3 ? (+dp[2]) : '';
    var yearMonth = dp.length === 3 ? ((+dp[0]) + ' 年 ' + (+dp[1]) + ' 月') : '';
    var imgs = Array.isArray(d.images) ? d.images : [];
    Modal.open({
      cls: 'dd-modal',
      title: '回顾详情',
      body:
        '<div class="diary-detail" data-diary-id="' + esc(d.id) + '">' +
          '<div class="dd-cover">' +
            '<div class="dd-mood" style="--mood:' + mood.color + '">' +
              '<span class="dd-mood-dot" aria-hidden="true"></span>' +
              '<span class="dd-mood-txt">心情 · ' + mood.label + '</span>' +
            '</div>' +
            '<header class="dd-mast">' +
              '<div class="dd-eyebrow">Daily Review · 一日三问</div>' +
              '<div class="dd-dateline">' +
                '<span class="dd-day">' + dayNum + '</span>' +
                '<span class="dd-my">' + yearMonth + '<i class="dd-week">' + weekdayCN(d.date) + '</i></span>' +
              '</div>' +
            '</header>' +
          '</div>' +
          '<div class="dd-entries">' +
            ddEntry('01', '今天做了什么', d.what) +
            ddEntry('02', '有什么收获', d.gain) +
            ddEntry('03', '明天计划', d.plan) +
          '</div>' +
          (imgs.length
            ? '<section class="dd-film">' +
                '<div class="dd-film-head"><span class="dd-film-eyebrow">Plates · 今日剪贴簿</span>' +
                '<span class="dd-film-count">' + imgs.length + '</span></div>' +
                diFilmHtml(imgs) +
              '</section>'
            : '') +
          '<footer class="dd-colophon"><span class="dd-rule" aria-hidden="true"></span>记录于 ' + fmtDate(d.createdAt) + '</footer>' +
        '</div>',
      actions: [
        {
          text: '删除', className: 'btn-danger', align: 'left',
          onClick: function () {
                        confirmDelete('日记', d.date, function () { DB.deleteDiary(d.id); });
          }
        },
        { text: '取消', className: 'btn-default' },
        { text: '编辑', className: 'btn-primary', primary: true, onClick: function () { Modal.close(true); openDiaryForm(d, { back: function () { var nd = null, l = DB.listDiary(), i; for (i = 0; i < l.length; i++) if (l[i].id === d.id) { nd = l[i]; break; } if (nd) openDiaryDetail(nd); } }); } }
      ]
    });
    mobDetailify();

    /* 胶片条：滑动渐隐、点格进看图台、小圆点（仅存本机）点按即补传 */
    var film = $('#ddFilmScroll', Modal.card);
    if (film) {
      tagBarFade(film);
      film.addEventListener('scroll', function () { tagBarFade(film); }, { passive: true });
      film.addEventListener('click', function (e) {
        var dot = e.target.closest ? e.target.closest('.dg-local-dot') : null;
        if (dot) {
          dot.classList.add('is-busy');
          DB.IMAGES.flush(d.id);
          return;
        }
        var cell = e.target.closest ? e.target.closest('.dg-cell') : null;
        if (cell) {
          openImageViewer(d.images, parseInt(cell.getAttribute('data-i'), 10) || 0,
            { title: mdCN(d.date) + ' ' + weekdayCN(d.date) });
        }
      });
    }
  }

  /* 一批配图上云完成：列表角标与打开着的胶片条就地刷新（不重开弹窗、不重播入场动画） */
  function refreshDiaryImages(itemId) {
    if (state.view === 'diary' || state.view === 'overview') renderView(state.view);
    var detail = Modal.card ? $('.diary-detail[data-diary-id]', Modal.card) : null;
    if (!detail || (itemId && detail.getAttribute('data-diary-id') !== itemId)) return;
    var rec = null, l = DB.listDiary(), k;
    for (k = 0; k < l.length; k++) { if (l[k].id === itemId) { rec = l[k]; break; } }
    if (!rec) return;
    var roll = $('#ddFilmScroll', detail);
    if (!roll) return;
    roll.outerHTML = diFilmHtml(rec.images);
    var nf = $('#ddFilmScroll', detail);
    if (nf) {
      tagBarFade(nf);
      nf.addEventListener('scroll', function () { tagBarFade(nf); }, { passive: true });
    }
  }

  /* ============================================================
     个人中心内嵌管理区块：数据概览 + 回收站 / 备份提醒 / 导出 / 导入 / 重置
     ============================================================ */
  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(2) + ' MB';
  }

  function dcStats() {
    var todos = DB.listTodos('all');
    var open = todos.filter(function (t) { return !t.done; });
    var today = todayStr();
    var habits = DB.listHabits();
    var json = '';
    try { json = JSON.stringify(DB.exportData()); } catch (e) { json = ''; }
    var bytes = json.length;
    try { bytes = new Blob([json]).size; } catch (e) { /* 退回字符数估算 */ }
    return {
      total: todos.length,
      open: open.length,
      done: todos.length - open.length,
      overdue: open.filter(function (t) { return t.due && t.due < today; }).length,
      todayDue: open.filter(function (t) { return t.due === today; }).length,
      memoCount: DB._data.memo.length,
      tagCount: (DB.memoTags() || []).length,
      dateCount: (DB._data.special_date || []).length,
      upcoming: DB.upcoming(7),
      habitCount: habits.length,
      habitToday: habits.filter(function (h) { return DB.isHabitDone(h.id, today); }).length,
      diaryCount: (DB._data.diary || []).length,
      receiptCount: (DB._data.receipts || []).length,
      trashCount: DB.listTrash().length,
      bytes: bytes
    };
  }

  /* ============================================================
   个人中心内嵌管理区块：我的概览 / 数据统计 / 数据管理 / 偏好设置
   返回 { html, danger, after }，登录态与本地模式共用
   ============================================================ */
  /* 全站统一图标语言：内联 SVG、viewBox 24、stroke currentColor */
  var PF_ICONS = {
    grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>',
    chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16"/><path d="M7 20v-7M12 20V6M17 20V10"/></svg>',
    db: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5.5" rx="7.5" ry="2.6"/><path d="M4.5 5.5v13c0 1.4 3.4 2.6 7.5 2.6s7.5-1.2 7.5-2.6v-13"/><path d="M4.5 12c0 1.4 3.4 2.6 7.5 2.6s7.5-1.2 7.5-2.6"/></svg>',
    sliders: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h7.5M16.5 8H20M4 16h2.5M11 16h9"/><circle cx="14" cy="8" r="2.2"/><circle cx="8.5" cy="16" r="2.2"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/><path d="M12 14.5v2"/></svg>',
    warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.8 2.8 19.6h18.4L12 3.8Z"/><path d="M12 9.5v4.5M12 17h.01"/></svg>',
    todo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="3"/><path d="m8.5 12.2 2.4 2.4 4.9-5"/></svg>',
    done: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.8 4.4 4.4L19 7.2"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.2"/><path d="M12 7.6V12l2.8 1.8"/></svg>',
    alarm: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="6.8"/><path d="M12 10v3.2l2.2 1.4M5.2 3.6 2.8 5.8M18.8 3.6l2.4 2.2"/></svg>',
    memo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3.5" width="14" height="17" rx="2.4"/><path d="M9 8.5h6M9 12.2h6M9 15.9h3.4"/></svg>',
    habit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 12a7.5 7.5 0 0 1 13.2-4.9M19.5 12a7.5 7.5 0 0 1-13.2 4.9"/><path d="M17.8 3.4v3.8h-3.8M6.2 20.6v-3.8H10"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20.2S4.6 15.7 3 11.6A5 5 0 0 1 12 6.9a5 5 0 0 1 9 4.7c-1.6 4.1-9 8.6-9 8.6Z"/></svg>',
    book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 5.8a2.3 2.3 0 0 1 2.3-2.3h12.7v14.2H6.8a2.3 2.3 0 0 0-2.3 2.3V5.8Z"/><path d="M4.5 20a2.3 2.3 0 0 1 2.3-2.3h12.7"/></svg>',
    receipt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5h12v17.2l-2.4-1.6-2.4 1.6-2.4-1.6-2.4 1.6L6 20.7V3.5Z"/><path d="M9.4 8.2h5.2M9.4 12h5.2"/></svg>',
    size: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="12.2" width="17" height="7" rx="2"/><path d="M6.8 12.2 9 5h6l2.2 7.2"/><path d="M7 15.7h.01M10.2 15.7h.01"/></svg>',
    cloud: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6.8 18.8a4.6 4.6 0 0 1-.3-9.2 5.6 5.6 0 0 1 11-1 4.3 4.3 0 0 1-.9 8.5l-9.8 1.7Z"/></svg>',
    cloudUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6.8 18.8a4.6 4.6 0 0 1-.3-9.2 5.6 5.6 0 0 1 11-1 4.3 4.3 0 0 1-.9 8.5"/><path d="M12 20v-7M9.2 15.4 12 12.6l2.8 2.8"/></svg>',
    bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6.2 9.8a5.8 5.8 0 0 1 11.6 0c0 4.6 1.9 5.8 1.9 5.8H4.3s1.9-1.2 1.9-5.8Z"/><path d="M10.2 19a2 2 0 0 0 3.6 0"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 6.5h15M9.5 6.5V5a1.4 1.4 0 0 1 1.4-1.4h2.2A1.4 1.4 0 0 1 14.5 5v1.5M6.5 6.5l.8 13a1.6 1.6 0 0 0 1.6 1.5h6.2a1.6 1.6 0 0 0 1.6-1.5l.8-13"/><path d="M10.1 10.5v6.5M13.9 10.5v6.5"/></svg>',
    download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v10.5M7.8 10.7l4.2 4.2 4.2-4.2M5 19.5h14"/></svg>',
    upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 14.7V4.2M7.8 8.4 12 4.2l4.2 4.2M5 19.5h14"/></svg>',
    calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.8" y="5.2" width="16.4" height="15" rx="2.4"/><path d="M3.8 9.8h16.4M8.2 3v4M15.8 3v4"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 6 6 6-6 6"/></svg>',
    archive: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4" width="17" height="5" rx="1.2"/><path d="M5.5 9v9.5a1.5 1.5 0 0 0 1.5 1.5h10a1.5 1.5 0 0 0 1.5-1.5V9"/><path d="M10 13h4"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.4"/><path d="M12 11v5.2M12 7.9h.01"/></svg>'
  };

  /* 分区标题（icon + 文案），供 dcManageBlocks 与 openProfile（账户安全）共用 */
  function pfSec(icon, title, inner, cls) {
    return '<div class="dc-block pf-sec' + (cls ? ' ' + cls : '') + '">' +
      '<div class="dc-title">' + PF_ICONS[icon] + '<span>' + esc(title) + '</span></div>' +
      inner + '</div>';
  }

  function pfKpiCard(goto, icon, label, value, warn, sub) {
    return '<div class="summary-card pf-kpi-card" data-goto="' + goto + '" role="button" tabindex="0" aria-label="' + esc(label) + '，点击查看">' +
      '<span class="pf-ico" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<div class="pf-kpi-main">' +
        '<div class="summary-label">' + esc(label) + '</div>' +
        '<div class="summary-value' + (warn ? ' is-warn' : '') + '" data-count="' + value + '">' + value + '</div>' +
        (sub ? '<div class="summary-sub">' + sub + '</div>' : '') +
      '</div>' +
    '</div>';
  }

  function pfStatRow(icon, label, value, cls) {
    return '<div class="pf-row' + (cls ? ' ' + cls : '') + '">' +
      '<span class="pf-ico pf-ico-sm" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<span class="pf-k">' + esc(label) + '</span>' +
      '<span class="pf-v">' + esc(value) + '</span></div>';
  }

  function pfAct(id, icon, title, desc, tail) {
    return '<button type="button" class="pf-act" id="' + id + '">' +
      '<span class="pf-ico" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<span class="pf-act-main"><span class="pf-act-title">' + esc(title) + '</span>' +
      '<span class="pf-act-desc">' + esc(desc) + '</span></span>' +
      (tail || '') +
      '<span class="pf-act-chev" aria-hidden="true">' + PF_ICONS.chev + '</span></button>';
  }

  function pfSet(id, icon, title, desc, checked) {
    return '<div class="pf-set">' +
      '<span class="pf-ico" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<span class="pf-act-main"><span class="pf-act-title">' + esc(title) + '</span>' +
      '<span class="pf-act-desc">' + esc(desc) + '</span></span>' +
      '<span class="pf-switch"><input type="checkbox" id="' + id + '"' + (checked ? ' checked' : '') + ' aria-label="' + esc(title) + '"><span class="pf-track" aria-hidden="true"></span></span>' +
    '</div>';
  }

  /* ---- 参考图新样式：灰标题（卡片外）+ 白卡分组 + 单行条目（无描述）---- */
  function pfGroup(title, inner, cls) {
    return '<section class="pfg' + (cls ? ' ' + cls : '') + '"><h3 class="pfg-label">' + esc(title) + '</h3><div class="pfg-card">' + inner + '</div></section>';
  }
  function pfItem(id, icon, title, tail) {
    return '<button type="button" class="pfg-row" id="' + id + '">' +
      '<span class="pfg-ico" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<span class="pfg-t">' + esc(title) + '</span>' +
      (tail || '') +
      '<span class="pfg-chev" aria-hidden="true">' + PF_ICONS.chev + '</span></button>';
  }
  /* 控制行（开关 / 分段）：非跳转，右侧放控件，无箭头 */
  function pfCtlRow(icon, title, ctlInner, cls) {
    return '<div class="pfg-row pfg-ctl' + (cls ? ' ' + cls : '') + '">' +
      '<span class="pfg-ico" aria-hidden="true">' + PF_ICONS[icon] + '</span>' +
      '<span class="pfg-t">' + esc(title) + '</span>' + ctlInner + '</div>';
  }
  function pfSwitchRow(id, icon, title, checked) {
    return pfCtlRow(icon, title,
      '<span class="pf-switch"><input type="checkbox" id="' + id + '"' + (checked ? ' checked' : '') + ' aria-label="' + esc(title) + '"><span class="pf-track" aria-hidden="true"></span></span>');
  }
  function pfSegRow(icon, title, segInner) {
    return pfCtlRow(icon, title, segInner);
  }
  /* 交给 klog-native.js 的行构造器：App 的「提醒与手感」分区复用同一套组件与图标，
     避免站内出现第二套弹窗/控件样式 */
  window.KlogPf = {
    pfGroup: pfGroup, pfItem: pfItem, pfCtlRow: pfCtlRow,
    pfSwitchRow: pfSwitchRow, pfSegRow: pfSegRow,
    icons: PF_ICONS, esc: esc
  };
  /* 原生桥的导出/自检提示复用站内 toast，不另起浮层 */
  window.KlogToast = toast;

  function dcManageBlocks() {
    var html =
      pfGroup('数据',
        pfItem('pf-data-overview', 'chart', '数据概览') +
        pfItem('pf-trash', 'trash', '回收站',
          DB.listTrash().length ? '<span class="pf-chip">' + DB.listTrash().length + '</span>' : '') +
        pfItem('pf-archive', 'archive', '已归档',
          DB.listArchived().length ? '<span class="pf-chip">' + DB.listArchived().length + '</span>' : '') +
        pfItem('pf-export', 'download', '导出备份') +
        pfItem('pf-import', 'upload', '导入备份')) +
      pfGroup('设置',
        pfSegRow('heart', '外观',
          '<span class="pf-seg" id="pf-theme" role="group" aria-label="外观主题">' +
            '<button type="button" data-th="light">浅色</button>' +
            '<button type="button" data-th="dark">深色</button>' +
            '<button type="button" data-th="auto">系统</button>' +
          '</span>') +
        pfItem('pf-receipt', 'receipt', '每日小票机') +
        (DB.CLOUD_ENABLED
          ? pfSwitchRow('pf-auto', 'cloudUp', '每日自动备份', autoBackupEnabled()) +
            pfSwitchRow('pf-remind', 'bell', '桌面提醒', remindEnabled()) +
            '<div class="pfg-note" id="pf-remind-hint"></div>'
          : '') +
        pfItem('pf-about', 'info', '关于',
          '<span class="pf-chip pf-chip-ver">' + esc(wbVersion()) + '</span>')) +
      /* App 内追加「提醒与手感」：系统通知排程 + 震动手感，复用同一套行组件 */
      (window.KlogNative && window.KlogNative.isApp ? window.KlogNative.settingsHtml() : '');

    var danger = pfGroup('危险操作',
      pfCtlRow('warn', '重置全部数据',
        '<button type="button" class="btn btn-danger dc-reset-btn" id="pf-reset" title="重置全部数据" aria-label="重置全部数据">' +
          '<svg class="dc-reset-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"/><path d="M3 3v5h5"/></svg>' +
          '<span class="dc-reset-txt">重置</span>' +
        '</button>', 'is-danger'),
      'is-danger');

    function after(card) {
      /* App 的「提醒与手感」分区：开关折叠、时间选择、自检与权限文案由原生桥接管 */
      if (window.KlogNative) window.KlogNative.bindSettings(card);
      /* 数据概览入口：进入二级弹窗（关闭原位返回并恢复浏览位置） */
      var ovBtn = $('#pf-data-overview', card);
      if (ovBtn) ovBtn.addEventListener('click', function () { pfLeaveOpen(openDataOverview); });
      /* pfLeaveOpen 已提升为模块级（编辑资料入口共用） */
      var trashBtn = $('#pf-trash', card);
      if (trashBtn) trashBtn.addEventListener('click', function () { pfLeaveOpen(openTrashBin); });
      var archBtn = $('#pf-archive', card);
      if (archBtn) archBtn.addEventListener('click', function () { pfLeaveOpen(openArchiveBin); });
      var secBtn = $('#pf-security', card);
      if (secBtn) secBtn.addEventListener('click', function () { pfLeaveOpen(openSecurityModal); });
      /* 外观三分段：点击即生效并回显 */
      var thSeg = $('#pf-theme', card);
      if (thSeg) {
        var syncTh = function () {
          var pref = currentThemePref();
          $all('button', thSeg).forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-th') === pref); });
        };
        syncTh();
        thSeg.addEventListener('click', function (e) {
          var b = e.target.closest('button[data-th]');
          if (!b) return;
          applyTheme(b.getAttribute('data-th'));
          syncTh();
        });
      }
      var rcvBtn = $('#pf-receipt', card);
      if (rcvBtn) rcvBtn.addEventListener('click', function () {
        pfLeaveOpen(openReceiptMachine); /* 关闭小票机（X/遮罩/Esc）返回个人中心并回到原浏览位置 */
      });
      var aboutBtn = $('#pf-about', card);
      if (aboutBtn) aboutBtn.addEventListener('click', function () { pfLeaveOpen(openAbout); });
      var autoCb = $('#pf-auto', card);
      if (autoCb) autoCb.addEventListener('change', function () {
        try { localStorage.setItem('wb_autobackup', this.checked ? '1' : '0'); } catch (e) { /* 忽略 */ }
        toast(this.checked ? '已开启自动备份' : '已关闭自动备份');
        if (this.checked) autoBackup(true);
      });
      var remCb = $('#pf-remind', card);
      if (remCb) remCb.addEventListener('change', function () {
        try { localStorage.setItem('wb_reminder', this.checked ? '1' : '0'); } catch (e) { /* 忽略 */ }
        if (this.checked) requestRemindPermission();
        updateRemindHint();
      });
      updateRemindHint();
      var exportBtn = $('#pf-export', card);
      if (exportBtn) exportBtn.addEventListener('click', doExport);
      var importBtn = $('#pf-import', card);
      if (importBtn) importBtn.addEventListener('click', function () { $('#importFile').click(); });
      var resetBtn = $('#pf-reset', card);
      if (resetBtn) resetBtn.addEventListener('click', function () {
        confirmModal({
          title: '重置全部数据',
          message: '将清空本机<b>全部数据</b>并恢复为初始状态。<br><br>不可撤销，建议先<b>导出备份</b>。',
          okText: '确认重置',
          danger: true,
          closeUnderlying: true, /* 抽屉叠在个人中心之上，重置成功后才收起 */
          onOk: function () {
            try { DB.reset(); }
            catch (e) { handleMutationError(e); return false; }
            switchView('overview');
            toast('已重置为初始数据');
          }
        });
      });
    }

    return { html: html, danger: danger, after: after };
  }

  /* ============================================================
     关于：品牌信息 + 精简数据说明 + 更新日志入口 + 版权
     ——视觉沿用站内「详情页」的 .dd-modal（灰底画布 + 白色圆角卡 + 图标行）语言。
     更新日志是一只接入 WbBack 返回栈的整屏层（手机端底部抽屉 / 桌面居中对话框），
     叠在「关于」之上，侧滑/返回先收它、再回到关于。
     ============================================================ */
  /* 构建号由 index.php 用 css / js / db 三个文件的 mtime 组合注入 meta：
     「构建日期」反映最近一次改动，与手工维护的 APP_VERSION 一并展示 */
  function wbBuildInfo() {
    var raw = (document.querySelector('meta[name="wb-build"]') || {}).content || '';
    var ts = String(raw).split('-')
      .map(function (x) { return parseInt(x, 10); })
      .filter(function (x) { return x > 946684800; }); /* 2000-01-01 之后才算有效时间戳 */
    return { raw: raw, at: ts.length ? Math.max.apply(null, ts) : 0 };
  }
  function wbVersion() {
    var b = wbBuildInfo();
    return b.at ? fmtDate(new Date(b.at * 1000).toISOString()) : '—';
  }

  /* 版本号（手工维护）+ 品牌标（与侧栏 / 顶栏同一枚黑底白字 K 方块） */
  var APP_VERSION = '1.0';
  var APP_LOGO = '<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Klog">' +
    '<rect width="200" height="200" rx="25" fill="#111111"/>' +
    '<path d="M118.903 93.9527L161.337 53.4467C162.643 52.2009 161.761 50 159.957 50L124.736 50C124.176 50 123.641 50.2353 123.262 50.6486L90.2808 86.6279C88.843 88.1964 86.2754 86.7327 86.8924 84.6964L96.6247 52.58C97.0139 51.2956 96.0527 50 94.7106 50L57.3579 50C56.4875 50 55.717 50.563 55.4525 51.3922L24.8318 147.392C24.4203 148.682 25.383 150 26.7372 150L65.4107 150C66.2919 150 67.0692 149.423 67.3248 148.58L78.085 113.071C78.549 111.54 80.5338 111.147 81.5469 112.385L111.723 149.266C112.103 149.731 112.671 150 113.271 150L159.9 150C161.606 150 162.529 148 161.421 146.702L118.762 96.6975C118.073 95.8901 118.135 94.6855 118.903 93.9527Z" fill="#FCFCFC" fill-rule="evenodd"/>' +
    '<path d="M169.966 50L173.285 50C174.547 50 175.493 51.1546 175.246 52.3922L173.46 61.3233C173.273 62.2581 172.452 62.931 171.498 62.931L169.966 62.931C168.861 62.931 167.966 62.0356 167.966 60.931L167.966 52C167.966 50.8954 168.861 50 169.966 50Z" fill="#FCFCFC" fill-rule="evenodd"/>' +
    '</svg>';

  /* 更新流水日志（新 → 旧） */
  var CHANGELOG = [
    { v: '1.0', d: '2026-09-17', items: [
      '待办、备忘、纪念日、习惯、一日三问、每日小票六大模块齐备。',
      '云端同步与本地档案双模式：离线可继续，同一账号跨设备自动同步。',
      '手机端交互全面打磨——详情统一灰底白卡、左滑归档 / 删除、侧滑返回逐层消隐。'
    ] },
    { v: '0.9', d: '2026-09-15', items: [
      '统一弹窗与确认体系，归档 / 回收站收口为同一视觉语言。'
    ] },
    { v: '0.8', d: '2026-09-14', items: [
      '建立手机端 4pt 间距与触控规范，习惯热力图与打卡体验优化。'
    ] },
    { v: '0.6', d: '2026-09-13', items: [
      '新增每日回顾（一日三问）与纪念日到期提醒。'
    ] },
    { v: '0.3', d: '2026-09-12', items: [
      '首个内测版本：待办与备忘的基础记录能力。'
    ] }
  ];
  function changelogHtml() {
    return '<div class="cl-list">' + CHANGELOG.map(function (e) {
      return '<section class="cl-item">' +
        '<header class="cl-head">' +
          '<span class="cl-ver">v' + esc(e.v) + '</span>' +
          '<span class="cl-date">' + esc(e.d) + '</span>' +
          (e.v === APP_VERSION ? '<span class="cl-cur">当前</span>' : '') +
        '</header>' +
        '<ul class="cl-ul">' + e.items.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>' +
      '</section>';
    }).join('') + '</div>';
  }
  function changelogFootHtml() {
    var b = wbBuildInfo();
    return '<div class="cl-foot">当前构建 ' + (b.at ? esc(fmtDateTime(new Date(b.at * 1000).toISOString())) : '—') + '</div>';
  }

  function openAbout(opts) {
    opts = opts || {};
    var dataTip = DB.CLOUD_ENABLED
      ? '数据保存在你的<b>云端账号</b>下，并保留本机缓存供离线查看；同一账号跨设备自动同步。换设备或长期离线前，建议先<b>导出备份</b>。'
      : '当前为<b>本地模式</b>，数据只存在这台设备的本机档案里，断网也能完整使用；登录账号后即可同步至云端。';

    Modal.open({
      title: '关于',
      cls: 'dd-modal', /* 灰底画布 + 白色圆角卡，与站内详情/数据概览同一语言 */
      afterClose: opts.back,
      actions: [],
      body:
        '<div class="dd-hero ab-brand">' +
          '<span class="ab-logo" aria-hidden="true">' + APP_LOGO + '</span>' +
          '<div class="ab-id">' +
            '<div class="ab-name">' + esc(APP_NAME) + '</div>' +
            '<div class="ab-badge">' +
              '<span class="ab-ver">版本 ' + esc(APP_VERSION) + '</span>' +
              '<span class="ab-dot" aria-hidden="true">·</span>' +
              '<span class="ab-date">' + esc(wbVersion()) + '</span>' +
            '</div>' +
            '<div class="ab-slogan">待办 · 备忘 · 纪念日 · 习惯 · 一日三问</div>' +
          '</div>' +
        '</div>' +
        pfGroup('数据说明', '<div class="ab-text">' + dataTip + '</div>') +
        pfGroup('更新',
          pfItem('ab-changelog', 'clock', '更新日志',
            '<span class="pf-chip pf-chip-ver">v' + esc(APP_VERSION) + '</span>')) +
        '<div class="ab-copy">© 2026 Kezn</div>'
    });

    var cl = $('#ab-changelog', Modal.card);
    if (cl) cl.addEventListener('click', openChangelog);
  }

  /* 更新日志整屏层：单一 .wp-mask/.wp-sheet 路径，
     靠 CSS 在桌面居中成对话框、手机端为底部抽屉；接入 WbBack 返回栈，
     一次返回只收这一层（关于弹窗留在原位，不关卡重开）。 */
  var clSheetOpen = false;
  function openChangelog() {
    if (clSheetOpen) return;
    clSheetOpen = true;
    var mask = document.createElement('div');
    mask.className = 'wp-mask ab-mask';
    mask.innerHTML =
      '<div class="wp-sheet ab-sheet" role="dialog" aria-modal="true" aria-label="更新日志">' +
        '<div class="wp-grab" aria-hidden="true"></div>' +
        '<div class="wp-title">更新日志</div>' +
        '<div class="cl-scroll">' + changelogHtml() + changelogFootHtml() + '</div>' +
        '<div class="wp-foot"><button type="button" class="wp-btn wp-btn-ok" id="clDone">完成</button></div>' +
      '</div>';
    document.body.appendChild(mask);
    var sheet = $('.wp-sheet', mask);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });
    wpPinViewport(mask);
    wireSheetGrab(sheet, function () { close(); }, { expand: false, tap: false });
    var clFr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先收更新日志 */

    function close() {
      if (!clSheetOpen) return;                                  /* 幂等守卫：程序关 / Esc / 遮罩 / 甩关只生效一次 */
      clSheetOpen = false;
      if (clFr) { WbBack.finish(clFr); clFr = null; }          /* ← 先消费返回帧，再删 DOM */
      document.removeEventListener('keydown', onKey, true);
      mask.classList.remove('is-open');
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 320);
    }
    function onKey(e) { if (e.key === 'Escape') { if (!wpIsTopMask(mask)) return; e.preventDefault(); e.stopPropagation(); close(); } }
    document.addEventListener('keydown', onKey, true);
    mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
    $('#clDone', mask).addEventListener('click', close);
  }

  /* 数据概览二级弹窗：从个人中心「数据概览」进入，承载 KPI + 明细统计 + 存储说明 */
  function openDataOverview(opts) {
    opts = opts || {};
    var s = dcStats();
    var nextEv = s.upcoming[0];
    var nextTxt = nextEv
      ? esc(nextEv.name) + '（' + (nextEv.days === 0 ? '就是今天' : '还有 ' + nextEv.days + ' 天') + '）'
      : '暂无临近事件';
    var storageTxt = (window.WorkbenchDB && WorkbenchDB.storageLabel) ? WorkbenchDB.storageLabel() : '浏览器标准存储';
    var tip = DB.CLOUD_ENABLED
      ? '数据保存在云端，并保留本机缓存副本，断网时可继续使用、恢复网络后自动同步。如需换新设备或长期离线归档，请先<b>导出备份</b>。'
      : '当前为<b>本地模式</b>，数据保存在本机专属档案，不依赖网络与账号；登录账号后数据将同步至云端。如需换设备或归档，请先<b>导出备份</b>。';

    Modal.open({
      title: '数据概览',
      cls: 'dc-card dd-modal',
      afterClose: opts.back,
      actions: [],
      body:
        '<section class="pfg"><h3 class="pfg-label">概览</h3>' +
          '<div class="kpi-grid">' +
            pfKpiCard('todo', 'todo', '待办进行中', s.open, false, '共 ' + s.total + ' 条') +
            pfKpiCard('todo', 'clock', '今日到期', s.todayDue, !!s.todayDue, '今天需完成') +
            pfKpiCard('memo', 'memo', '备忘', s.memoCount, false, s.tagCount + ' 个标签') +
            pfKpiCard('date', 'alarm', '7 天内临近', s.upcoming.length, !!s.upcoming.length, nextTxt) +
          '</div></section>' +
        '<section class="pfg"><h3 class="pfg-label">数据统计</h3>' +
          '<div class="pf-list">' +
            pfStatRow('todo', '待办总数', s.total) +
            pfStatRow('done', '已完成待办', s.done) +
            pfStatRow('clock', '已过期待办', s.overdue, s.overdue ? 'is-danger' : '') +
            pfStatRow('memo', '备忘', s.memoCount + ' 条') +
            pfStatRow('habit', '习惯打卡', s.habitCount + ' 个 · 今日完成 ' + s.habitToday) +
            pfStatRow('calendar', '纪念日 / 生日', s.dateCount) +
            pfStatRow('book', '回顾日记', s.diaryCount + ' 篇') +
            pfStatRow('receipt', '小票存档', s.receiptCount + ' 张') +
            pfStatRow('size', '本地数据占用', fmtSize(s.bytes)) +
            pfStatRow('cloud', '存储方式', storageTxt) +
          '</div></section>' +
        '<div class="dc-tip">' + tip + '</div>'
    });

    /* KPI 卡：点击关闭弹窗，视图跳转交给文档级 data-goto 委托 */
    $all('.summary-card[data-goto]', Modal.card).forEach(function (el) {
      el.addEventListener('click', function () { Modal.close(); });
      el.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); Modal.close(); }
      });
    });
    animateCounters(Modal.card);
  }

  /* ============================================================
     小票机：选一天，把当天的待办 / 习惯 / 回顾打印成一张小票
     小票以定格快照存档（小票盒），可保存为图片 / 删除
     ============================================================ */
  var RM_STATE = { date: todayStr(), tab: 'machine', current: null };

  function rmCollectDay(dateStr) {
    var todos = DB.listTodos('all').filter(function (t) {
      return t.done && typeof t.doneAt === 'string' && isoToLocalDay(t.doneAt) === dateStr;
    }).map(function (t) {
      var d = new Date(t.doneAt);
      return { time: isNaN(d.getTime()) ? '' : pad(d.getHours()) + ':' + pad(d.getMinutes()), title: t.title };
    });
    var habits = DB.listHabits().filter(function (h) { return DB.isHabitDone(h.id, dateStr); })
      .map(function (h) {
        var n = DB.habitCount(h.id, dateStr);
        return { title: h.name + (n > 1 ? ' ×' + n : '') }; /* 单日可多次打卡 */
      });
    var d = DB.getDiaryByDate(dateStr);
    var diary = null;
    if (d) {
      var mood = (MOODS[d.mood] || MOODS.ok).label;
      var brief = (d.what || d.gain || '').replace(/\s+/g, ' ').slice(0, 40) || '记录了一段回顾';
      diary = { title: '回顾 · ' + mood, detail: brief };
    }
    return { date: dateStr, todos: todos, habits: habits, diary: diary,
      count: todos.length + habits.length + (diary ? 1 : 0) };
  }

  function rmSeedRand(seed) {
    var x = 7;
    for (var i = 0; i < seed.length; i++) x = (x * 31 + seed.charCodeAt(i)) >>> 0;
    return function () { x = (x * 1103515245 + 12345) >>> 0; return (x >>> 8) / 16777216; };
  }

  /* 「打印 ID 昵称」设备级偏好（localStorage，与个人中心自动备份同款） */
  function rmNickOn() { try { return localStorage.getItem('wb_rm_nick') === '1'; } catch (e) { return false; } }

  /* 小票 canvas 绘制（2x 高清；两遍布局：先按字号断行量高，再落笔）
     排版原则：分区虚线（页眉 / 正文 / 合计 / 存根）深一档，记录之间用更细更浅的细虚线；
     虚线上下与文本保持对称呼吸间距（≈40 canvas px）；
     时刻 / 类别 / 标题定列对齐，长标题与摘要换行（最多两行，末行折省略号）。 */
  function rmDraw(canvas, day, printedAt, baseOnly) {
    try {
    var W = 640, PAD = 48;
    var F_BODY = '"PingFang SC", "Microsoft YaHei", sans-serif';
    var FONT_META = '22px ' + F_BODY;
    var FONT_TIME = '22px ui-monospace, "SF Mono", Consolas, monospace';
    var FONT_TITLE = '500 25px ' + F_BODY;
    var FONT_DET = '21px ' + F_BODY;
    var TIME_COL = PAD + 78;   /* 类别列 */
    var COL = PAD + 132;       /* 标题列 */
    var LINE = 36, DET = 30;   /* 标题行高 / 摘要行高 */
    var ITEM_GAP = 26;         /* 记录间留白 */
    var FOOTER_H = 486;        /* 合计 + 小计 + 打印时间 + 条码 + 撕边 */
    var ctx = canvas.getContext('2d');
    /* 打印 ID 昵称（开关存 localStorage，与个人中心自动备份/提醒同款设备级偏好）：
       开启时页眉副标题下加一行昵称，下方版式整体下移 HO */
    var nick = rmNickOn() ? String(displayUser() || '') : '';
    var HO = nick ? 36 : 0;
    var ITEMS_TOP = 296 + HO;  /* 首条记录块顶（日期虚线下方留白） */
    var items = [];
    if (!baseOnly) {
      day.todos.forEach(function (t) { items.push({ tag: '待办', time: t.time, title: t.title }); });
      day.habits.forEach(function (h) { items.push({ tag: '习惯', time: '', title: h.title }); });
      if (day.diary) items.push({ tag: '回顾', time: '', title: day.diary.title, detail: day.diary.detail });
    }
    if (!items.length) items.push({ empty: true });

    /* 第一遍：断行并量出每条记录的高度（含底部留白） */
    var maxW = W - PAD - COL;
    items.forEach(function (it) {
      if (it.empty) { it.lines = []; it.dlines = []; it.h = 64; return; }
      ctx.font = FONT_TITLE;
      it.lines = rmWrap(ctx, it.title, maxW, 2);
      ctx.font = FONT_DET;
      it.dlines = it.detail ? rmWrap(ctx, it.detail, maxW, 2) : [];
      var last = (it.lines.length - 1) * LINE;
      if (it.dlines.length) last += 36 + (it.dlines.length - 1) * DET;
      it.h = 26 + last + 12 + ITEM_GAP;
    });
    var H = ITEMS_TOP + items.reduce(function (s, it) { return s + it.h; }, 0) + FOOTER_H;
    canvas.width = W; canvas.height = H;
    canvas.style.width = '100%';

    var brand = (document.querySelector('.logo-cn') || {}).textContent || 'Klog';
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
    ctx.textBaseline = 'alphabetic';

    /* 页眉：品牌 + 日期，两条分区虚线（与文本上下间距对称） */
    ctx.fillStyle = '#111'; ctx.font = '600 40px ' + F_BODY;
    ctx.textAlign = 'center'; ctx.fillText(brand, W / 2, 96);
    ctx.fillStyle = '#9a9a9a'; ctx.font = '22px ' + F_BODY;
    ctx.fillText('记 录 小 票', W / 2, 138);
    if (nick) {
      ctx.fillStyle = '#8a8a8a'; ctx.font = '20px ' + F_BODY;
      ctx.fillText(nick, W / 2, 170);
    }
    rmDash(ctx, PAD, 176 + HO, W - PAD, 176 + HO);
    ctx.textAlign = 'left'; ctx.fillStyle = '#9a9a9a'; ctx.font = '24px ' + F_BODY;
    ctx.fillText('日期', PAD, 232 + HO);
    ctx.textAlign = 'right'; ctx.fillStyle = '#111'; ctx.font = '600 27px ' + F_BODY;
    ctx.fillText(mdCN(day.date) + ' ' + weekdayCN(day.date), W - PAD, 232 + HO);
    rmDash(ctx, PAD, 268 + HO, W - PAD, 268 + HO);

    /* 正文：记录之间用一道细虚线分隔（比分区线更浅更细），末条后不画（下方即合计分区线） */
    var y = ITEMS_TOP;
    items.forEach(function (it, idx) {
      if (it.empty) {
        ctx.textAlign = 'center'; ctx.fillStyle = '#b9b9b9'; ctx.font = '24px ' + F_BODY;
        ctx.fillText('本日无记录', W / 2, y + 26);
        y += it.h; return;
      }
      var base = y + 26;
      ctx.textAlign = 'left';
      if (it.time) { ctx.fillStyle = '#8a8a8a'; ctx.font = FONT_TIME; ctx.fillText(it.time, PAD, base); }
      ctx.fillStyle = '#9a9a9a'; ctx.font = FONT_META; ctx.fillText(it.tag, TIME_COL, base);
      ctx.fillStyle = '#111'; ctx.font = FONT_TITLE;
      it.lines.forEach(function (ln, i) { ctx.fillText(ln, COL, base + i * LINE); });
      if (it.dlines.length) {
        ctx.fillStyle = '#9a9a9a'; ctx.font = FONT_DET;
        var dBase = base + (it.lines.length - 1) * LINE + 36;
        it.dlines.forEach(function (ln, i) { ctx.fillText(ln, COL, dBase + i * DET); });
      }
      /* 相邻记录间的细虚线：落在本块底部留白 ITEM_GAP 的垂直中点 */
      if (idx < items.length - 1) {
        var dy = y + it.h - ITEM_GAP / 2;
        rmDashThin(ctx, PAD, dy, W - PAD, dy);
      }
      y += it.h;
    });

    /* 合计区：正文末尾虚线与上一条基线相距 40，与「合计」顶相距 32 */
    var fy = y + 2;
    rmDash(ctx, PAD, fy, W - PAD, fy);
    var ty = fy + 62;
    ctx.textAlign = 'left'; ctx.fillStyle = '#111'; ctx.font = '600 30px ' + F_BODY;
    ctx.fillText('合计', PAD, ty);
    ctx.textAlign = 'right'; ctx.font = '700 32px ' + F_BODY;
    ctx.fillText(day.count + ' 条记录', W - PAD, ty);
    var fy2 = ty + 42;
    rmDash(ctx, PAD, fy2, W - PAD, fy2);

    /* 存根：小计（标签灰、数值黑右对齐）+ 打印时间 */
    var sy = fy2 + 50;
    ctx.font = '22px ' + F_BODY;
    var lines = [['待办', day.todos.length], ['习惯', day.habits.length], ['回顾', day.diary ? 1 : 0]];
    lines.forEach(function (l, i) {
      var yy = sy + i * 38;
      ctx.textAlign = 'left'; ctx.fillStyle = '#8a8a8a'; ctx.fillText(l[0], PAD, yy);
      ctx.textAlign = 'right'; ctx.fillStyle = '#111'; ctx.fillText(String(l[1]), W - PAD, yy);
    });
    var py = sy + 2 * 38 + 44;
    ctx.textAlign = 'left'; ctx.fillStyle = '#9a9a9a'; ctx.font = '22px ' + F_BODY;
    ctx.fillText('打印时间', PAD, py);
    ctx.textAlign = 'right'; ctx.fillStyle = '#111';
    ctx.fillText(printedAt, W - PAD, py);

    /* 条形码 + 票号（居中 380px，不通栏，更像真实小票的存根条码） */
    var by = py + 30;
    var rnd = rmSeedRand(day.date.replace(/-/g, '') + printedAt);
    var bw = 380, bx = (W - bw) / 2, bEnd = bx + bw;
    ctx.fillStyle = '#111';
    while (bx < bEnd - 4) {
      var w = 2 + Math.floor(rnd() * 5);
      ctx.fillRect(bx, by, Math.min(w, bEnd - bx), 62);
      bx += w + 2 + Math.floor(rnd() * 5);
    }
    ctx.textAlign = 'center'; ctx.font = '20px monospace'; ctx.fillStyle = '#6d6d6d';
    ctx.fillText('NO. ' + day.date.replace(/-/g, ''), W / 2, by + 92);

    /* 锯齿撕边 */
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(0, H - 26);
    var step = 20;
    for (var x = 0; x < W; x += step) {
      ctx.lineTo(x + step / 2, H - 8);
      ctx.lineTo(Math.min(x + step, W), H - 26);
    }
    ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath(); ctx.fill();
    } catch (e) {
      canvas.width = 640; canvas.height = 320;
      var xc = canvas.getContext('2d');
      xc.fillStyle = '#fff'; xc.fillRect(0, 0, 640, 320);
      xc.fillStyle = '#c66'; xc.font = '24px sans-serif'; xc.textAlign = 'center';
      xc.fillText('小票绘制失败：' + e.message, 320, 150);
      if (window.console && console.error) console.error('rmDraw:', e);
    }
  }

  /* 逐字断行（中文场景），最多 maxLines 行，末行溢出折省略号 */
  function rmWrap(ctx, text, maxW, maxLines) {
    text = String(text || '');
    var lines = [], rest = text;
    while (rest && lines.length < maxLines) {
      var take = 0, isLast = lines.length === maxLines - 1;
      while (take < rest.length && ctx.measureText(rest.slice(0, take + 1)).width <= maxW) take++;
      if (take === 0) take = 1; /* 超宽单字符兜底，防死循环 */
      if (isLast && take < rest.length) {
        var s = rest.slice(0, take);
        while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1);
        lines.push(s + '…');
        break;
      }
      lines.push(rest.slice(0, take));
      rest = rest.slice(take);
    }
    if (!lines.length) lines.push('');
    return lines;
  }

  function rmDash(ctx, x1, y1, x2, y2, light) {
    ctx.save();
    /* 2x canvas 显示约 0.47 倍：线宽 3（显示≈1.4px）+ 加深灰，保证虚线清晰可见 */
    ctx.strokeStyle = light ? '#cfcfcf' : '#b9b9b9';
    ctx.setLineDash([5, 7]); ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.restore();
  }

  /* 记录间细虚线：比分区线浅一档、点更短疏，只作行分组不作页面分区 */
  function rmDashThin(ctx, x1, y1, x2, y2) {
    ctx.save();
    ctx.strokeStyle = '#dedede';
    ctx.setLineDash([3, 7]); ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.restore();
  }

  function rmSetState(txt, mode) {
    var el = $('#rmStateTxt');
    if (el) el.textContent = txt;
    var dot = $('#rmDot');
    if (dot) dot.className = 'rm-dot' + (mode ? ' rm-dot-' + mode : '');
  }

  function rmShowDay(dateStr) {
    var big = $('#rmDateBig'), yr = $('#rmYear');
    if (big) big.textContent = rmDateLabel(dateStr);
    if (yr) yr.textContent = dateStr.slice(0, 4) + '年';
  }

  /* 打印分段定时器：切日期 / 查看历史时中断旧动画，防止串扰 */
  var rmTimers = [];
  function rmClearTimers() {
    rmTimers.forEach(function (t) { clearTimeout(t); });
    rmTimers = [];
  }

  /* 重置：收起纸（切换日期 / 弹窗重开时回到无纸状态） */
  function rmResetPaper() {
    rmClearTimers();
    var root = Modal ? Modal.card : document;
    var paper = $('#rmPaper', root);
    if (paper) { paper.hidden = true; paper.dataset.busy = '0'; }
    var save = $('#rmSave', root);
    if (save) save.hidden = true;
    var canvas = $('#rmCanvas', root);
    if (canvas) { canvas.style.transition = 'none'; canvas.style.transform = 'none'; }
  }

  function rmRenderBox() {
    var box = $('#rmBoxList');
    if (!box) return;
    var list = DB.listReceipts();
    var cnt = $('#rmBoxCnt');
    if (cnt) cnt.textContent = String(list.length);
    if (!list.length) {
      box.innerHTML = '<div class="rm-box-empty">小票盒还是空的，去打印第一张吧</div>';
      return;
    }
    box.innerHTML = list.map(function (r) {
      var c = (r.data && r.data.count) || 0;
      return '<div class="rm-box-row" data-rc-id="' + esc(r.id) + '">' +
        '<div class="rm-box-info">' +
          '<div class="rm-box-date">' + esc(mdCN(r.date)) + ' ' + weekdayCN(r.date) + '</div>' +
          '<div class="rm-box-sub">' + esc((r.createdAt || '').slice(0, 16).replace('T', ' ')) + ' 打印 · ' + c + ' 条记录</div>' +
        '</div>' +
        '<div class="rm-box-ops">' +
          '<button type="button" class="btn btn-default btn-sm" data-rc-view>查看</button>' +
          '<button type="button" class="btn btn-danger btn-sm" data-rc-del>删除</button>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  function rmSwitchTab(tab) {
    $all('.rm-tabs [data-rmt]', Modal.card).forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-rmt') === tab); });
    var m = $('#rmMachineView', Modal.card), bx = $('#rmBoxView', Modal.card);
    if (m) m.hidden = tab !== 'machine';
    if (bx) bx.hidden = tab !== 'box';
    if (tab === 'box') rmRenderBox();
  }

  function openReceiptMachine(opts) {
    rmClearTimers(); /* 重开先断掉旧动画定时器，防止串扰新弹窗 DOM */
    RM_STATE.date = todayStr();
    RM_STATE.lastPrint = null;
    Modal.open({
      title: '小票机',
      afterClose: opts && opts.back, /* 从个人中心进入：X / 遮罩 / Esc 关闭均原位返回并恢复浏览位置 */
      body:
        '<div class="seg rm-tabs">' +
          '<button type="button" class="active" data-rmt="machine">小票机</button>' +
          '<button type="button" data-rmt="box">小票盒<span class="seg-cnt" id="rmBoxCnt">0</span></button>' +
        '</div>' +
        '<div id="rmMachineView">' +
          '<div class="rm-machine">' +
            '<div class="rm-brand">' +
              '<span class="rm-logo">' + esc((document.querySelector(".logo-cn") || {}).textContent || 'Klog') + '</span>' +
              '<label class="rm-cal" title="选择日期">' +
                '<input type="date" id="rmDate" value="' + RM_STATE.date + '">' +
              '</label>' +
            '</div>' +
            '<div class="rm-screen">' +
              '<div class="rm-date-line"><b id="rmDateBig">' + rmDateLabel(RM_STATE.date) + '</b><span id="rmYear">' + RM_STATE.date.slice(0, 4) + '年</span></div>' +
              '<div class="rm-state"><span class="rm-dot" id="rmDot"></span><span id="rmStateTxt">待机 · 选择日期后打印</span></div>' +
            '</div>' +
            '<div class="rm-actions"><button type="button" class="btn btn-primary" id="rmPrint">打印小票</button></div>' +
            '<label class="rm-nick-row"><span>打印 ID 昵称</span>' +
              '<span class="status-switch"><input type="checkbox" id="rmNick"><span class="switch-slider"></span></span>' +
            '</label>' +
            '<div class="rm-slot"></div>' +
          '</div>' +
          '<div class="rm-paper-win">' +
            '<div class="rm-paper" id="rmPaper" hidden>' +
              '<canvas id="rmCanvas"></canvas>' +
            '</div>' +
          '</div>' +
          '<div class="rm-paper-ops"><button type="button" class="rm-save-btn" id="rmSave" hidden title="保存图片" aria-label="保存图片">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11"/><path d="M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>' +
          '</button></div>' +
        '</div>' +
        '<div id="rmBoxView" hidden><div id="rmBoxList" class="rm-box-list"></div></div>',
      actions: [],
      /* 桌面定高 82vh + 个人中心宽度；移动端随全局弹窗全屏，不随有无纸变化 */
      cls: 'dc-card rm-modal'
    });

    var dateInput = $('#rmDate', Modal.card);
    if (dateInput) dateInput.addEventListener('change', function () {
      if (!dateInput.value) return;
      RM_STATE.date = dateInput.value;
      rmShowDay(RM_STATE.date);
      rmResetPaper();
      rmSetState('待机 · 选择日期后打印', '');
    });

    /* 「打印 ID 昵称」开关：初始化 + 切换即写偏好；若已有出纸，用最近一次数据原位重绘 */
    var nickOpt = $('#rmNick', Modal.card);
    if (nickOpt) {
      nickOpt.checked = rmNickOn();
      nickOpt.addEventListener('change', function () {
        try { localStorage.setItem('wb_rm_nick', this.checked ? '1' : '0'); } catch (e) {}
        var paper = $('#rmPaper', Modal.card);
        var canvas = $('#rmCanvas', Modal.card);
        if (paper && !paper.hidden && canvas && RM_STATE.lastPrint) {
          rmDraw(canvas, RM_STATE.lastPrint.day, RM_STATE.lastPrint.printedAt);
        }
      });
    }

    var printBtn = $('#rmPrint', Modal.card);
    if (printBtn) printBtn.addEventListener('click', function () {
      var paper = $('#rmPaper', Modal.card);
      var save = $('#rmSave', Modal.card);
      var canvas = $('#rmCanvas', Modal.card);
      if (!paper || !canvas) return;
      if (paper.dataset.busy === '1') return;
      paper.dataset.busy = '1';
      if (save) save.hidden = true;
      /* 阶段一：正在整理当日的日志 */
      rmSetState('正在整理当日的日志中…', 'busy');
      rmTimers.push(setTimeout(function () {
        var day = rmCollectDay(RM_STATE.date);
        var printedAt = (function () {
          var n = new Date();
          return n.getFullYear() + '/' + (n.getMonth() + 1) + '/' + n.getDate() + ' ' +
            String(n.getHours()).padStart(2, '0') + ':' + String(n.getMinutes()).padStart(2, '0');
        })();
        RM_STATE.lastPrint = { day: day, printedAt: printedAt };
        /* 阶段二：整张纸先藏进出纸口内（窗口只裁出纸口以下部分），分段下移滑出——纸在动、窗口不动 */
        rmSetState('打印中…', 'busy');
        paper.hidden = false;
        rmDraw(canvas, day, printedAt);
        canvas.style.transition = 'none';
        canvas.style.transform = 'translateY(-100%)';
        void canvas.offsetWidth;
        var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var STEPS = 5, SEG = 500;
        if (reduceMotion) { STEPS = 1; SEG = 0; }
        else { canvas.style.transition = 'transform .34s cubic-bezier(.3,.7,.4,1)'; }
        for (var i = 1; i <= STEPS; i++) {
          (function (i) {
            rmTimers.push(setTimeout(function () {
              canvas.style.transform = 'translateY(' + (i * 20 - 100) + '%)';
            }, (i - 1) * SEG));
          })(i);
        }
        /* 阶段三：入库 + 完成 */
        rmTimers.push(setTimeout(function () {
          DB.saveReceipt({ id: 'rc' + RM_STATE.date.replace(/-/g, '') + '-' + Date.now().toString(36), date: RM_STATE.date, createdAt: new Date().toISOString(), data: day });
          rmSetState('打印完成 ✓', 'done');
          if (save) save.hidden = false;
          var cnt = $('#rmBoxCnt', Modal.card);
          if (cnt) cnt.textContent = String(DB.listReceipts().length);
          paper.dataset.busy = '0';
        }, STEPS * SEG + 340));
      }, 620));
    });

    var saveBtn = $('#rmSave', Modal.card);
    if (saveBtn) saveBtn.addEventListener('click', function () {
      rmSaveCanvas($('#rmCanvas', Modal.card), 'receipt-' + RM_STATE.date + '.png');
    });

    $all('.rm-tabs [data-rmt]', Modal.card).forEach(function (b) {
      b.addEventListener('click', function () { rmSwitchTab(b.getAttribute('data-rmt')); });
    });

    var boxList = $('#rmBoxList', Modal.card);
    if (boxList) boxList.addEventListener('click', function (e) {
      var row = e.target.closest('[data-rc-id]');
      if (!row) return;
      var id = row.getAttribute('data-rc-id');
      var view = e.target.closest('[data-rc-view]');
      var del = e.target.closest('[data-rc-del]');
      if (view) {
        var rec = DB.getReceipt(id);
        if (!rec || !rec.data) { toast('小票数据缺失', 'error'); return; }
        rmOpenViewer(rec);
        return;
      }
      if (del) {
        var rec2 = DB.getReceipt(id);
        confirmDelete('小票', rec2 ? mdCN(rec2.date) : '该记录', function () { DB.deleteReceipt(id); rmRenderBox(); });
      }
    });

    rmRenderBox();
  }

  /* 画布导出 PNG 下载（小票机存图 / 查看器存图共用） */
  function rmSaveCanvas(canvas, filename) {
    if (!canvas || !canvas.toBlob) { toast('当前浏览器不支持导出', 'error'); return; }
    canvas.toBlob(function (blob) {
      if (!blob) { toast('导出失败', 'error'); return; }
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
      toast('小票图片已保存');
    }, 'image/png');
  }

  /* 小票盒「查看」：全屏纯小票查看器。独立浮层叠在小票机之上，
     关闭后回到小票盒列表，不顶掉底下的弹窗（沿用 cfSheet 的 body 级 .wp-mask 思路）。 */
  function rmOpenViewer(rec) {
    var printedAt = (rec.createdAt || '').slice(0, 16).replace('T', ' ').replace(/-/g, '/');
    var mask = document.createElement('div');
    mask.className = 'rm-view-mask';
    mask.innerHTML =
      '<div class="rm-view" role="dialog" aria-modal="true" aria-label="小票预览">' +
        '<div class="rm-view-bar">' +
          '<button type="button" class="rm-view-x" aria-label="关闭">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
          '</button>' +
          '<span class="rm-view-title">' + esc(mdCN(rec.date)) + ' ' + weekdayCN(rec.date) + '</span>' +
          '<button type="button" class="rm-view-save" title="保存图片" aria-label="保存图片">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11"/><path d="M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>' +
          '</button>' +
        '</div>' +
        '<div class="rm-view-scroll"><div class="rm-view-paper"><canvas></canvas></div></div>' +
      '</div>';
    document.body.appendChild(mask);
    var canvas = $('.rm-view-paper canvas', mask);
    if (canvas && rec.data) rmDraw(canvas, rec.data, printedAt || rec.date);
    requestAnimationFrame(function () { mask.classList.add('is-open'); });

    var closed = false;
    var bfr = WbBack.supported ? WbBack.enter(function () { close(); }) : null; /* 侧滑/返回先关全屏预览 */
    function close() {
      if (closed) return;
      closed = true;
      if (bfr) WbBack.finish(bfr);
      mask.classList.remove('is-open');
      document.removeEventListener('keydown', onKey, true);
      setTimeout(function () { if (mask.parentNode) mask.parentNode.removeChild(mask); }, 260);
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

    $('.rm-view-x', mask).addEventListener('click', close);
    $('.rm-view-save', mask).addEventListener('click', function () {
      rmSaveCanvas(canvas, 'receipt-' + rec.date + '.png');
    });
    /* 点空白（遮罩或滚动区背景，非纸面）关闭 */
    mask.addEventListener('click', function (e) {
      if (e.target === mask || e.target.classList.contains('rm-view-scroll')) close();
    });
    document.addEventListener('keydown', onKey, true);
  }

  function rmDateLabel(dateStr) {
    return mdCN(dateStr) + ' ' + weekdayCN(dateStr);
  }

  /* ============================================================
     个人中心：账号信息 + 退出登录
     ============================================================ */
  var EYE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/></svg>';

  function pwdField(id, label, placeholder) {
    return '<div class="field">' +
      '<label for="' + id + '">' + esc(label) + '</label>' +
      '<div class="pwd-field">' +
        '<input class="form-input" type="password" id="' + id + '" placeholder="' + esc(placeholder) + '" autocomplete="new-password">' +
        '<button type="button" class="pwd-toggle" data-toggle-for="' + id + '" aria-label="显示 / 隐藏密码">' + EYE_SVG + '</button>' +
      '</div></div>';
  }

  /* 子弹窗切换：离开时记下浏览位置，返回时原位恢复；close(true) 保证遮罩不闪。
     必须在模块级 —— dcManageBlocks 的 after 闭包（回收站 / 账号安全行）也引用它；
     此前误放在 openProfile 体内，after 回调解析不到 → 手机端点击 ReferenceError 无效果 */
  function pfLeaveOpen(opener) {
    var sc = $('.modal-body', Modal.card);
    var st = { scroll: sc ? sc.scrollTop : 0 };
    Modal.close(true);
    opener({ back: function () { openProfile(st); } });
  }

  function openProfile(state) {

  /* 编辑资料（登录态）：昵称可重复 + 头像上传（居中裁剪压缩 128×128 JPEG dataURL）。
     保存 / 取消 / 关闭后均回到个人中心并恢复浏览位置（afterClose = back） */
  /* 退出登录流程（个人中心 / 编辑资料页共用）：确认 → 快照本地档案 → 登出刷新 */
  function doLogoutFlow() {
    confirmModal({
      title: '退出登录',
      message: '退出后数据仍保存在本机，重新登录可继续同步。',
      okText: '退出',
      danger: true,
      onOk: function () {
        /* 登出前把登录态数据快照进昵称数据档案（IndexedDB），本地模式无缝接管 */
        var doLogout = function () {
          fetch('api/account.php?action=logout', { method: 'POST', credentials: 'same-origin' })
            .catch(function () { /* 网络异常也照常刷新，会话兜底由服务端刷新时校验 */ })
            .finally(function () { location.reload(); });
        };
        try {
          DB.snapshotForLogout(doLogout);
        } catch (e) { doLogout(); /* 快照失败不阻断登出 */ }
      }
    });
  }

  function openEditProfileModal(opts) {
    if (!LOGIN_AUTHED) return;
    var prof = myProfile || { nickname: '', avatar: '' };
    var draft = { nickname: prof.nickname || '', avatar: prof.avatar || '' };
    var mob = wbCoarse();

    function submitProfile() {
      var card = Modal.card;
      var nick = $('#ep-nick', card).value.trim();
      if (nick.length > 32) { showFormError('昵称不能超过 32 个字符'); return; }
      fetch('api/account.php?action=profile', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nickname: nick, avatar: draft.avatar }) })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res || !res.ok) { showFormError((res && res.error) || '保存失败'); return; }
          myProfile = { nickname: nick, avatar: draft.avatar };
          Modal.markClean();
          Modal.close();
          toast('资料已更新');
          refreshIdentityUi();
          renderUsers();
        })
        .catch(function () { showFormError('网络异常，请重试'); });
    }

    Modal.open({
      title: '编辑资料',
      dirtyGuard: true,
      afterClose: opts && opts.back,
      headAction: mob ? { icon: true, text: '保存', onClick: submitProfile } : null,
      body:
        '<div class="pf-edit-avatar">' +
          '<button type="button" class="ep-avatar-btn" id="ep-avatar" aria-label="更换头像">' +
            '<span class="user-avatar user-avatar-xl" id="ep-preview" aria-hidden="true">' + (safeAvatar(draft.avatar) ? '<img class="avatar-img" src="' + esc(safeAvatar(draft.avatar)) + '" alt="">' : esc((loginUser() || 'U').slice(0, 1).toUpperCase())) + '</span>' +
            '<span class="ep-avatar-cam" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8.5h3l1.5-2.2h7L17 8.5h3a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13" r="3.2"/></svg></span>' +
          '</button>' +
          '<input type="file" id="ep-file" accept="image/*" hidden>' +
        '</div>' +
        '<div class="fg-card">' +
          '<div class="field fg-row">' +
            '<label for="ep-nick">昵称</label>' +
            '<input class="form-input" id="ep-nick" type="text" maxlength="32" value="' + esc(draft.nickname) + '" placeholder="留空则显示账号名">' +
          '</div>' +
        '</div>' +
        '<div class="dd-foot-inline">' +
          '<button type="button" class="pf-logout-pill" id="ep-logout">退出登录</button>' +
        '</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: mob ? [] : [
        { text: '取消', className: 'btn-default' },
        { text: '保存', className: 'btn-primary', primary: true, onClick: submitProfile }
      ]
    });
    if (mob) Modal.card.classList.add('wbf-modal');
    var logoutBtn = $('#ep-logout', Modal.card);
    if (logoutBtn) logoutBtn.addEventListener('click', function () { Modal.close(true); doLogoutFlow(); });

    /* 点头像 → 选文件 → 居中裁剪压缩为 128×128 JPEG，即时预览 */
    var fileInput = $('#ep-file', Modal.card);
    var avatarBtn = $('#ep-avatar', Modal.card);
    if (avatarBtn && fileInput) {
      avatarBtn.addEventListener('click', function () { fileInput.click(); });
      fileInput.addEventListener('change', function () {
        var f = fileInput.files && fileInput.files[0];
        fileInput.value = '';
        if (!f) return;
        if (!/^image\/(jpeg|png|webp)$/.test(f.type)) { showFormError('仅支持 JPG / PNG / WebP 图片'); return; }
        var reader = new FileReader();
        reader.onload = function () {
          var img = new Image();
          img.onload = function () {
            try {
              var S = 128, cv = document.createElement('canvas');
              cv.width = S; cv.height = S;
              var ctx = cv.getContext('2d');
              var side = Math.min(img.width, img.height);
              ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
              draft.avatar = cv.toDataURL('image/jpeg', 0.85);
              $('#ep-preview', Modal.card).innerHTML = '<img class="avatar-img" src="' + esc(safeAvatar(draft.avatar)) + '" alt="">';
              var fe = $('#formError', Modal.card);
              if (fe) { fe.textContent = ''; fe.classList.remove('show'); }
            } catch (e) { showFormError('图片处理失败，请换一张试试'); }
          };
          img.onerror = function () { showFormError('图片读取失败，请换一张试试'); };
          img.src = String(reader.result);
        };
        reader.readAsDataURL(f);
      });
    }
  }

    var m = dcManageBlocks();

    /* 本地模式：无账号体系，展示本地数据档案 + 管理区块 + 登录入口 */
    if (!LOGIN_AUTHED) {
      var prof = (window.WorkbenchDB && WorkbenchDB.getProfile) ? WorkbenchDB.getProfile() : null;
      var bodyLocal =
        '<div class="pf-account">' +
          '<span class="user-avatar user-avatar-lg" aria-hidden="true">' + esc((displayUser() || '客').slice(0, 1).toUpperCase()) + '</span>' +
          '<div class="pf-account-main">' +
            '<div class="pf-name">' + esc(displayUser() || '访客') + '</div>' +
            '<div class="pf-sub"><span class="role-badge role-local">本地模式</span></div>' +
          '</div>' +
          '<button type="button" class="pf-login-act" id="pf-login-open" aria-label="登录账号">登录账号' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9.5 6 6 6-6 6"/></svg>' +
          '</button>' +
        '</div>' +
        m.html + m.danger;

      Modal.open({
        title: '个人中心',
        body: bodyLocal,
        actions: [],
        cls: 'dc-card dd-modal'
      });
      var loginAct = $('#pf-login-open', Modal.card);
      if (loginAct) loginAct.addEventListener('click', function () { Modal.close(); openLoginModal(); });
      m.after(Modal.card);
      animateCounters(Modal.card);
      return;
    }

    var body =
      '<div class="pf-idcard">' +
      '<div class="pf-account pf-account-click">' +
        '<span class="user-avatar user-avatar-lg" aria-hidden="true">' + (safeAvatar(myProfile && myProfile.avatar) ? '<img class="avatar-img" src="' + esc(safeAvatar(myProfile && myProfile.avatar)) + '" alt="">' : esc((loginUser() || 'U').slice(0, 1).toUpperCase())) + '</span>' +
        '<div class="pf-account-main">' +
          '<div class="pf-name">' + esc(displayUser() || '未登录') + roleBadgeHtml(window.LOGIN_ROLE || 'free') + '</div>' +
          '<div class="pf-sub">@' + esc(loginUser() || '—') + '</div>' +
        '</div>' +
        '<button type="button" class="cat-act pf-edit-btn" id="pf-edit-profile" title="编辑资料" aria-label="编辑资料"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9.5 6 6 6-6 6"/></svg></button>' +
      '</div>' +
      /* 云端同步状态行：与账户卡连体（参考用户提供的截图样式） */
      '<div class="pf-sync-row">' +
        '<span class="pf-sync-text">账号数据已保存至云端</span>' +
        '<span class="pf-sync-ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>已同步</span>' +
      '</div>' +
      '</div>' +
      m.html +
      pfGroup('账户安全',
        pfItem('pf-security', 'lock', '修改登录密码')) +
      m.danger;

    Modal.open({
      title: '个人中心',
      body: body,
      actions: [],  /* 退出登录已移至「编辑资料」页底部；底栏自动收起 */
      cls: 'dc-card dd-modal'
    });
    m.after(Modal.card);
    /* KPI 数字滚动（380ms 三次缓出，reduced-motion 自动跳过）：
       与概览页共用同一动效语言 */
    animateCounters(Modal.card);

    /* 恢复上次浏览位置（从回收站 / 账号安全 / 编辑资料子弹窗返回时） */
    if (state && state.scroll) {
      var sc = $('.modal-body', Modal.card);
      if (sc) sc.scrollTop = state.scroll;
    }
    /* 用户栏整体可点击进入编辑资料：右箭头按钮仅为视觉引导，点击事件冒泡到卡片统一处理 */
    var pfCard = $('.pf-account-click', Modal.card);
    if (pfCard) pfCard.addEventListener('click', function () { pfLeaveOpen(openEditProfileModal); });
  }

  /* 账号安全独立弹窗：修改登录密码（个人中心「账户安全」行进入）。
     取消 / 关闭 / 保存成功后均回到个人中心并恢复浏览位置（afterClose = back） */
  function openSecurityModal(opts) {
    opts = opts || {};
    Modal.open({
      dirtyGuard: true,
      title: '账号安全',
      headAction: wbCoarse() ? { icon: true, text: '保存', onClick: clickFormPrimary } : null,
      body:
        pwdField('pf-old', '当前密码', '请输入当前密码') +
        '<div class="field-row">' +
          '<div>' + pwdField('pf-new', '新密码', '至少 4 位') + '</div>' +
          '<div>' + pwdField('pf-confirm', '确认新密码', '再次输入新密码') + '</div>' +
        '</div>' +
        '<div class="form-error" id="formError" role="alert"></div>',
      actions: [
        { text: '取消', className: 'btn-default' },
        { text: '保存修改', className: 'btn-primary', primary: true, onClick: savePassword }
      ],
      afterClose: opts.back
    });
    mobFormify(); /* 移动端：密码行转行式、收起旧底部栏（保存走头部 ✓ → clickFormPrimary） */
    /* 密码显隐切换 */
    $all('.pwd-toggle[data-toggle-for]', Modal.card).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var input = $('#' + btn.getAttribute('data-toggle-for'), Modal.card);
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.classList.toggle('on', show);
      });
    });
  }

  function savePassword() {
    var card = Modal.card;
    var oldP = $('#pf-old', card).value;
    var newP = $('#pf-new', card).value;
    var conP = $('#pf-confirm', card).value;

    if (!oldP) { showFormError('请输入当前密码', 'pf-old'); return; }
    if (newP.length < 4) { showFormError('新密码至少 4 位', 'pf-new'); return; }
    if (newP.length > 64) { showFormError('新密码不能超过 64 位', 'pf-new'); return; }
    if (newP !== conP) { showFormError('两次输入的新密码不一致', 'pf-new'); return; }
    if (newP === oldP) { showFormError('新密码不能与当前密码相同', 'pf-new'); return; }

    fetch('api/account.php?action=password', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ old: oldP, new: newP })
    })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res || res.ok !== true) {
          showFormError(res && res.error ? res.error : '修改失败，请重试');
          return;
        }
        Modal.markClean();
        Modal.close();
        toast('密码已更新，请用新密码登录');
      })
      .catch(function () { showFormError('网络异常，请重试'); });
  }

  /* ============================================================
     事件绑定
     ============================================================ */
  function bindSearch(inputId, clearId, onChange) {
    var input = $('#' + inputId);
    var clear = $('#' + clearId);
    var deb = debounce(function (v) { onChange(v); }, 180);
    input.addEventListener('input', function () {
      clear.hidden = !input.value;
      deb(input.value);
    });
    clear.addEventListener('click', function () {
      input.value = '';
      clear.hidden = true;
      onChange('');
      input.focus();
    });
  }

  function bindSeg(segId, onChange) {
    var seg = $('#' + segId);
    seg.addEventListener('click', function (e) {
      var btn = e.target.closest('button');
      if (!btn || btn.classList.contains('active')) return;
      $all('button', seg).forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      onChange(btn.getAttribute('data-f'));
    });
  }

  function bindEvents() {
    /* 主题入口已并入「设置 · 外观」；auto 偏好下跟随系统切换 */
    if (window.matchMedia) {
      var mqDark = window.matchMedia('(prefers-color-scheme: dark)');
      var onSysTheme = function () { if (currentThemePref() === 'auto') applyTheme('auto'); };
      if (mqDark.addEventListener) mqDark.addEventListener('change', onSysTheme);
      else if (mqDark.addListener) mqDark.addListener(onSysTheme);
    }
    /* 个人中心：侧边栏用户栏（桌面）/ 顶栏头像（平板、移动端） */
    $('#userBar').addEventListener('click', openProfile);
    $('#avatarBtn').addEventListener('click', openProfile);
    $('#importFile').addEventListener('change', function () {
      var f = this.files && this.files[0];
      doImport(f);
      this.value = '';
    });

    /* 侧边栏/底部导航：移动端「同一个 tab 连点两下」→ 进入概览（概览已退出 dock 的回归手势）。
       历史上只记一个全局时间戳，快速点两个不同 tab 就会被误判成双击、莫名跳回概览，
       因此必须比对 view；单点已选中的 tab 不重复渲染，只给指示块果冻反馈。 */
    var lastTap = { view: '', at: 0 };
    $all('.menu-item[data-view]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var v = btn.getAttribute('data-view');
        var now = Date.now();
        var sameTabTwice = lastTap.view === v && now - lastTap.at < 400;
        lastTap.view = v;
        lastTap.at = now;
        if (wbCoarse() && v !== 'overview' && sameTabTwice) {
          lastTap.at = 0;
          switchView('overview');
          return;
        }
        if (v === state.view) {
          if (wbCoarse()) wobbleTabIndicator();
          return;
        }
        switchView(v);
      });
    });
    /* 顶栏 logo：回概览；已在概览时点一下回到页顶（和常见 App 点标题回顶一致） */
    var logoBtn = $('#btnLogo');
    if (logoBtn) logoBtn.addEventListener('click', function () {
      if (state.view !== 'overview') { switchView('overview'); return; }
      var sc = document.getElementById('mainContent');
      var box = (sc && sc.scrollHeight > sc.clientHeight + 4) ? sc : document.scrollingElement;
      if (!box) return;
      var smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (box.scrollTo) box.scrollTo({ top: 0, behavior: smooth ? 'smooth' : 'auto' });
      else box.scrollTop = 0;
    });

    /* 概览「查看全部」 */
    $all('[data-goto]').forEach(function (btn) {
      btn.addEventListener('click', function () { switchView(btn.getAttribute('data-goto')); });
    });

    /* 移动端悬浮新增按钮（FAB） */
    $('#fabAdd').addEventListener('click', function () {
      var fn = FAB_ACTIONS[state.view];
      if (fn) fn();
    });

    /* ---------- 待办 ---------- */
    bindSearch('todoSearch', 'todoSearchClear', function (v) { state.todoSearch = v; renderTodos(); });
    bindSeg('todoSeg', function (f) { state.todoFilter = f; renderTodos(); });
    $('#btnAddTodo').addEventListener('click', function () { openTodoForm(null); });

    $('#view-todo').addEventListener('click', function (e) {
      /* 左滑展开态：点行内非动作按钮 → 先收起，不打开详情 */
      var openRow = e.target.closest('tr.is-swipe');
      if (openRow && !e.target.closest('.swipe-act')) {
        openRow.classList.remove('is-swipe');
        $all('td', openRow).forEach(function (td) { td.style.transition = ''; td.style.transform = ''; td.style.opacity = ''; });
        var odb = openRow.querySelector('.swipe-del');
        if (odb) { odb.style.transition = ''; odb.style.width = ''; }
        return;
      }
      /* 点击行任意位置打开编辑（复选框等交互元素除外） */
      if (e.target.closest('button, input, select, textarea, a[href], label')) return;
      var row = e.target.closest('[data-id]');
      if (!row) return;
      var t = DB.getTodo(row.getAttribute('data-id'));
      if (t) openTodoDetail(t);
    });

    /* ---------- 左滑快捷操作（移动端 · 两段式手势）：归档 / 删除 ----------
       第一段左滑：滑出归档、删除两个圆钮；
       展开态再次左滑（第二段）：删除钮随进度拉长成大胶囊，
       滑过中点松手 → 完全展开并自动执行删除；未过半 → 回退第一段。
       右滑 / 点行外 / 滚动 → 收起。 */
    (function bindTodoSwipe() {
      var body = $('#todoBody');
      if (!body) return;
      var W1 = 112, W2 = 188;               /* 一段（双圆钮）/ 二段（胶囊）位移 */
      var DEL0 = 44, DEL1 = 120;            /* 删除钮：圆 / 胶囊宽 */
      var sx = 0, sy = 0, act = null, horiz = false, second = false;
      var off = 0, lastX = 0, lastT = 0, vx = 0, deleting = false;
      function contentTds(tr) {
        return $all('td', tr).filter(function (td) { return !td.classList.contains('swipe-acts'); });
      }
      /* setOffset：内容平移+渐隐、动作层同步滑入、删除钮宽度随进度生长。
         anim=false 跟手即时；true 交给 CSS 弹性吸附 */
      function setOffset(tr, dx, anim, delW) {
        var tds = contentTds(tr);
        var fade = Math.max(0, 1 - Math.abs(dx) / W2 * 0.92);
        for (var i = 0; i < tds.length; i++) {
          tds[i].style.transition = anim ? '' : 'none';
          tds[i].style.transform = dx ? 'translateX(' + dx + 'px)' : '';
          tds[i].style.opacity = dx ? fade : '';
        }
        var acts = tr.querySelector('.swipe-acts');
        if (acts) {
          acts.style.transition = anim ? '' : 'none';
          acts.style.transform = dx ? 'translateX(' + dx + 'px)' : '';
        }
        var db = tr.querySelector('.swipe-del');
        if (db) {
          db.style.transition = anim ? '' : 'none';
          db.style.width = delW ? delW + 'px' : '';
        }
      }
      function closeRow(tr) { tr.classList.remove('is-swipe'); setOffset(tr, 0, true); }
      function openRow(tr) { tr.classList.add('is-swipe'); setOffset(tr, -W1, true); }
      function closeOthers(except) {
        $all('tr.is-swipe', body).forEach(function (r) { if (r !== except) closeRow(r); });
      }
      body.addEventListener('touchstart', function (e) {
        var tr = e.target.closest('tr[data-id]');
        if (!tr || deleting) return;
        var t0 = e.touches[0];
        sx = t0.clientX; sy = t0.clientY; act = tr; horiz = false;
        second = tr.classList.contains('is-swipe'); /* 已展开 → 本次为第二段 */
        off = second ? -W1 : 0;
        lastX = t0.clientX; lastT = e.timeStamp; vx = 0;
      }, { passive: true });
      body.addEventListener('touchmove', function (e) {
        if (!act) return;
        var t0 = e.touches[0];
        var dx = t0.clientX - sx, dy = t0.clientY - sy;
        if (!horiz && Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy) * 1.4) { horiz = true; closeOthers(act); }
        if (!horiz) return;
        var dt = e.timeStamp - lastT;
        if (dt > 0) { vx = (t0.clientX - lastX) / dt; lastX = t0.clientX; lastT = e.timeStamp; }
        var target;
        if (!second) {
          /* 第一段：0 ~ -W1；想继续拉只有强阻尼（暗示需二次滑动） */
          target = dx >= 0 ? 0 : (dx > -W1 ? dx : -W1 + (dx + W1) * 0.12);
        } else {
          if (dx > 12) { closeRow(act); act = null; return; } /* 右滑收起 */
          var extra = Math.max(-(W2 - W1), dx);                /* 第二段行程 76px */
          target = -W1 + extra;
          if (dx < -(W2 - W1)) target = -W2 + (dx + (W2 - W1)) * 0.2;
        }
        off = target;
        var delW = off < -W1 ? DEL0 + (-off - W1) / (W2 - W1) * (DEL1 - DEL0) : 0;
        setOffset(act, off, false, delW);
        e.preventDefault();
      }, { passive: false });
      function endSwipe() {
        if (!act) return;
        var tr = act; act = null;
        if (!horiz || deleting) return;
        if (!second) {
          if (off <= -W1 + 1 || (vx < -0.35 && off < -24)) openRow(tr);
          else closeRow(tr);
          return;
        }
        /* 第二段：过半或快甩 → 完全展开并自动删除；否则回退双圆钮 */
        if (off < -(W1 + W2) / 2 || (vx < -0.5 && off < -W1 - 20)) {
          deleting = true;
          /* 越过即锁定的那一刻先给一次触感，320ms 后真正删除再给完成音 */
          if (window.KlogNative) window.KlogNative.haptic('medium');
          setOffset(tr, -W2, true, DEL1);
          var id = tr.getAttribute('data-id');
          setTimeout(function () {
            deleting = false;
            try { DB.deleteTodo(id); }
            catch (err) { handleMutationError(err); return; }
            toast('已移入回收站');
            renderView('todo');
          }, 320);
        } else {
          openRow(tr);
        }
      }
      body.addEventListener('touchend', endSwipe);
      body.addEventListener('touchcancel', endSwipe);
      /* 动作按钮：归档 / 删除（直接执行 + toast 提示，回收站兜底） */
      body.addEventListener('click', function (e) {
        var btn = e.target.closest('.swipe-act');
        if (!btn) return;
        var row = btn.closest('tr[data-id]');
        if (!row) return;
        var id = row.getAttribute('data-id');
        closeRow(row);
        try {
          if (btn.getAttribute('data-swipe') === 'arch') {
            DB.archiveTodo(id);
            toast('已归档，可在「已归档」中恢复');
          } else {
            DB.deleteTodo(id);
            toast('已移入回收站');
          }
        } catch (err) { handleMutationError(err); return; }
        renderView('todo');
      });
      /* 纵向滚动时收起展开行，避免误触 */
      $('.main').addEventListener('scroll', function () {
        $all('tr.is-swipe', body).forEach(closeRow);
      }, { passive: true });
    })();

    $('#view-todo').addEventListener('change', function (e) {
      var cb = e.target.closest('.todo-check input');
      if (!cb) return;
      var row = e.target.closest('tr[data-id]');
      if (!row) return;
      var tid = row.getAttribute('data-id');
      try { DB.updateTodo(tid, { done: cb.checked }); }
      catch (err) { handleMutationError(err); return; }
      if (cb.checked) {
        var t = DB.getTodo(tid);
        toast('已完成' + (t && t.repeat ? '，已生成下一次' : ''));
      }
      renderView('todo');
    });

    /* ---------- 备忘 ---------- */
    bindSearch('memoSearch', 'memoSearchClear', function (v) { state.memoSearch = v; renderMemos(); });
    $('#btnAddMemo').addEventListener('click', function () { openMemoForm(null); });

    $('#memoTagBar').addEventListener('click', function (e) {
      if (e.target.closest('[data-tag-all]')) { openTagPicker(); return; }
      var chip = e.target.closest('.chip[data-tag]');
      if (!chip) return;
      var t = chip.getAttribute('data-tag') || '';
      if (!t) state.memoTags = [];
      else {
        var i = state.memoTags.indexOf(t);
        if (i === -1) state.memoTags.push(t);
        else state.memoTags.splice(i, 1);
      }
      renderMemos();
    });

    $('#view-memo').addEventListener('click', function (e) {
      /* 点击卡片任意位置打开编辑（交互元素除外） */
      if (e.target.closest('button, input, select, textarea, a[href], label')) return;
      var card = e.target.closest('[data-id]');
      if (!card) return;
      var m = DB.getMemo(card.getAttribute('data-id'));
      if (m) openMemoDetail(m);
    });

    /* 备忘置顶切换 */
    $('#view-memo').addEventListener('click', function (e) {
      var pin = e.target.closest('[data-memo-pin]');
      if (!pin) return;
      try { DB.toggleMemoPin(pin.getAttribute('data-memo-pin')); }
      catch (err) { toast('操作失败，请重试', 'error'); return; }
      renderMemos();
      if (state.view === 'overview') renderOverview();
    });

    /* ---------- 习惯打卡 ---------- */
    $('#btnAddHabit').addEventListener('click', function () { openHabitForm(null); });
    bindHabitCheck($('#habitTodayList'), renderHabits);
    $('#habitGrid').addEventListener('click', function (e) {
      var editBtn = e.target.closest('[data-habit-edit]');
      if (editBtn) {
        var h1 = DB.getHabit(editBtn.getAttribute('data-habit-edit'));
        if (h1) openHabitForm(h1);
        return;
      }
      var delBtn = e.target.closest('[data-habit-del]');
      if (delBtn) {
        var h2 = DB.getHabit(delBtn.getAttribute('data-habit-del'));
        if (!h2) return;
        confirmDelete('习惯', h2.name, function () { DB.removeHabit(h2.id); },
          '打卡记录一并移入回收站，30 天内可恢复。');
        return;
      }
      if (e.target.closest('button, input, select, textarea, a[href], label')) return;
      var card = e.target.closest('[data-id]');
      if (card) {
        var h3 = DB.getHabit(card.getAttribute('data-id'));
        if (h3) openHabitDetail(h3);
      }
    });

    /* ---------- 概览 · 今日时间线（内容每次重渲染，一律事件委托） ---------- */
    /* 习惯快捷打卡：主钮 +1 次、「减一次」−1 次，落库后只重画概览不重放入场动画 */
    bindHabitCheck($('#ovTimeline'), function () { renderOverview(); });

    /* 点行 → 对应模块详情（待办 / 习惯 / 纪念日 / 回顾） */
    function ovActivateRow(row) {
      var kind = row.getAttribute('data-tl-type'), id = row.getAttribute('data-tl-id');
      if (!kind || !id) return;
      if (kind === 'todo') { var t = DB.getTodo(id); if (t) openTodoDetail(t); }
      else if (kind === 'habit') { var h = DB.getHabit(id); if (h) openHabitDetail(h); }
      else if (kind === 'date') { var ev = DB.getSpecial(id); if (ev) openDateDetail(ev); }
      else if (kind === 'diary') {
        var list = DB.listDiary();
        for (var i = 0; i < list.length; i++) { if (list[i].id === id) { openDiaryDetail(list[i]); return; } }
      }
    }
    $('#ovTimeline').addEventListener('click', function (e) {
      var fin = e.target.closest('[data-tl-done]');
      if (fin) {
        var tid = fin.getAttribute('data-tl-done');
        var item = DB.getTodo(tid);
        if (!item) { renderOverview(); return; }
        try { DB.updateTodo(tid, { done: true }); }
        catch (err) { handleMutationError(err); return; }
        toast('已完成' + (item.repeat ? '，已生成下一次' : '')); /* 克制：只在完成时提示一次 */
        renderOverview();
        renderCounts();
        return;
      }
      var go = e.target.closest('[data-goto]');
      if (go) { switchView(go.getAttribute('data-goto')); return; }
      if (e.target.closest('button, a[href], input, label')) return;
      var row = e.target.closest('.tl-item[data-tl-id]');
      if (row) ovActivateRow(row);
    });
    $('#ovTimeline').addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      var row = e.target.closest('.tl-item[data-tl-id]');
      if (!row) return;
      e.preventDefault();
      ovActivateRow(row);
    });
    /* 本周卡：模块计数与「去看看」一类跳转 */
    $('#insightGrid').addEventListener('click', function (e) {
      var go = e.target.closest('[data-goto]');
      if (go) switchView(go.getAttribute('data-goto'));
    });

    /* ---------- 重要日子 ---------- */
    bindSearch('dateSearch', 'dateSearchClear', function (v) { state.dateSearch = v; renderDates(); });
    $('#dateTypeBar').addEventListener('click', function (e) {
      if (e.target.closest('[data-type-all]')) { openTypePicker(); return; }
      var chip = e.target.closest('.chip[data-type]');
      if (!chip) return;
      var t = chip.getAttribute('data-type') || '';
      if (state.dateFilter === t) return;
      state.dateFilter = t;
      renderDates();
    });
    $('#btnAddDate').addEventListener('click', function () { openDateForm(null); });

    $('#view-date').addEventListener('click', function (e) {
      /* 点击卡片任意位置打开编辑（交互元素除外） */
      if (e.target.closest('button, input, select, textarea, a[href], label')) return;
      var card = e.target.closest('[data-id]');
      if (!card) return;
      var ev = DB.getSpecial(card.getAttribute('data-id'));
      if (ev) openDateDetail(ev);
    });

    /* ---------- 各视图空态「清空筛选」 ---------- */
    ['todo', 'memo', 'date', 'diary'].forEach(function (name) {
      $('#view-' + name).addEventListener('click', function (e) {
        var btn = e.target.closest('[data-action="clear-filter"]');
        if (!btn) return;
        if (name === 'todo') {
          state.todoFilter = 'all';
          state.todoSearch = '';
          state.todoCat = '';
          $('#todoSearch').value = '';
          $('#todoSearchClear').hidden = true;
          $all('#todoSeg button').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-f') === 'all'); });
          renderTodos();
        } else if (name === 'memo') {
          state.memoTags = [];
          state.memoSearch = '';
          $('#memoSearch').value = '';
          $('#memoSearchClear').hidden = true;
          renderMemos();
        } else if (name === 'diary') {
          state.diarySearch = '';
          $('#diarySearch').value = '';
          $('#diarySearchClear').hidden = true;
          renderDiary();
        } else {
          state.dateFilter = '';
          state.dateSearch = '';
          $('#dateSearch').value = '';
          $('#dateSearchClear').hidden = true;
          renderDates();
        }
      });
    });

    /* ---------- 每日回顾 ---------- */
    bindSearch('diarySearch', 'diarySearchClear', function (v) { state.diarySearch = v; renderDiary(); });
    $('#btnAddDiary').addEventListener('click', function () { openDiaryForm(null); });
    document.addEventListener('click', function (e) {
      if (e.target.closest('.dd')) return;
      $all('.dd.open .dd-menu').forEach(function (m) { m.hidden = true; });
      $all('.dd.open').forEach(function (d) { d.classList.remove('open'); });
    });

    /* 用户管理：添加 / 角色切换 / 删除 */
    var addUserBtn = $('#btnAddUser');
    if (addUserBtn) addUserBtn.addEventListener('click', function () { openAddUserForm(); });
    var usersRows = $('#usersRows');
    if (usersRows) {
      usersRows.addEventListener('click', function (e) {
        /* 开合 */
        var toggle = e.target.closest('.dd-toggle');
        if (toggle) {
          var dd = toggle.closest('.dd');
          var menu = dd.querySelector('.dd-menu');
          var opening = menu.hidden;
          $all('.dd.open .dd-menu').forEach(function (m) { m.hidden = true; });
          $all('.dd.open').forEach(function (d) { d.classList.remove('open'); });
          if (opening) { menu.hidden = false; dd.classList.add('open'); }
          return;
        }
        /* 选中 */
        var item = e.target.closest('.dd-item');
        if (item) {
          var dd2 = item.closest('.dd');
          var uname = dd2.getAttribute('data-dd-user');
          var role = item.getAttribute('data-dd-val');
          dd2.querySelector('.dd-menu').hidden = true;
          dd2.classList.remove('open');
          fetch('api/account.php?action=role', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: uname, role: role }) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
              if (!res || !res.ok) { toast((res && res.error) || '修改失败', 'error'); renderUsers(); return; }
              toast('「' + uname + '」角色已设为 ' + (ROLE_LABEL[role] || role));
              if (uname === loginUser()) { window.LOGIN_ROLE = role; }
              renderUsers();
            })
            .catch(function () { toast('网络异常', 'error'); renderUsers(); });
        }
      });
      usersRows.addEventListener('click', function (e) {
        var del = e.target.closest('[data-u-del]');
        if (!del) return;
        var uname = del.getAttribute('data-u-del');
        confirmModal({
          title: '删除账号',
          headline: '「<b>' + esc(uname) + '</b>」',
          message: '该账号将无法登录，名下全部数据一并删除。',
          okText: '删除',
          danger: true,
          onOk: function () {
            fetch('api/account.php?action=del', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: uname }) })
              .then(function (r) { return r.json(); })
              .then(function (res) {
                toast(res && res.ok ? '账号已删除' : ((res && res.error) || '删除失败'), res && res.ok ? '' : 'error');
                renderUsers();
              })
              .catch(function () { toast('网络异常', 'error'); });
          }
        });
      });
    }

    $('#view-diary').addEventListener('click', function (e) {
      if (e.target.closest('button, input, select, textarea, a[href], label')) return;
      var card = e.target.closest('[data-id]');
      if (!card) return;
      var id = card.getAttribute('data-id');
      var list = DB.listDiary();
      for (var i = 0; i < list.length; i++) {
        if (list[i].id === id) { openDiaryDetail(list[i]); return; }
      }
    });

    /* ---------- 待办分类栏：筛选 / 全部分类浮层 ---------- */
    $('#todoCatBar').addEventListener('click', function (e) {
      if (e.target.closest('[data-cat-all]')) { openCatPicker(); return; }
      var chip = e.target.closest('.chip[data-cat]');
      if (chip) {
        state.todoCat = chip.getAttribute('data-cat');
        renderTodos();
      }
      /* 管理分类入口统一由 document 级委托处理，避免双开 */
    });

    /* ---------- 热力图：月/年视图格子小，触屏无 hover，点一下回读日期与次数 ---------- */
    document.addEventListener('click', function (e) {
      var c = e.target.closest ? e.target.closest('[data-hm-tip]') : null;
      if (c) toast(c.getAttribute('data-hm-tip'));
    });

    /* ---------- 空态 / 概览的「+新增」快捷入口与「管理分类」 ---------- */
    document.addEventListener('click', function (e) {
      var quick = e.target.closest('[data-quick]');
      if (quick) {
        var q = quick.getAttribute('data-quick');
        if (q === 'todo') openTodoForm(null);
        else if (q === 'memo') openMemoForm(null);
        else if (q === 'date') openDateForm(null);
        else if (q === 'habit') openHabitForm(null);
        else if (q === 'diary') openDiaryForm(null);
        return;
      }
      if (e.target.closest('[data-cat-manage]')) openCatManager();
    });
  }

  /* ============================================================
     启动
     ============================================================ */

  /* ---------- 首次访问 / 老用户升级：欢迎页 + 昵称设置 ---------- */
  function obEl(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstChild; }

  /* 引导页线性图标：与 dd-row / PF_ICONS 同一参数（24 视图 · 1.8 描边 · 圆端点） */
  function obIco(p) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  }
  var OB_ICO = {
    db: '<ellipse cx="12" cy="5.6" rx="7.4" ry="2.7"/><path d="M4.6 5.6v12.7c0 1.5 3.3 2.7 7.4 2.7s7.4-1.2 7.4-2.7V5.6"/><path d="M4.6 12c0 1.5 3.3 2.7 7.4 2.7s7.4-1.2 7.4-2.7"/>',
    offline: '<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2Z"/>',
    cloud: '<path d="M6.9 18.9a4.6 4.6 0 0 1-.3-9.2 5.6 5.6 0 0 1 11-1 4.3 4.3 0 0 1-.9 8.5l-9.8 1.7Z"/><path d="M12 16.6v-5.4M9.6 13.4 12 11l2.4 2.4"/>',
    file: '<path d="M13.5 3.7H7.2a2 2 0 0 0-2 2v12.6a2 2 0 0 0 2 2h9.6a2 2 0 0 0 2-2V9.2l-5.3-5.5Z"/><path d="M13.3 3.9v5.4h5.4"/>',
    back: '<path d="m14.6 5.4-6.9 6.6 6.9 6.6"/>',
    go: '<path d="M4.6 12h14.2M13.4 7l4.4 5-4.4 5"/>'
  };

  function runOnboarding(ident, onDone) {
    var appEl = document.querySelector('.app');
    if (appEl && 'inert' in appEl) appEl.inert = true;

    var isLegacy = ident.mode === 'legacy';
    /* 品牌标记直接复用侧栏那颗真 logo（黑底白 K 的圆角方块），不再手打一个「K」字 */
    var srcLogo = document.querySelector('.logo-icon');
    var markHtml = srcLogo
      ? '<span class="logo-icon ob-mark" aria-hidden="true">' + srcLogo.innerHTML + '</span>'
      : '<span class="ob-mark ob-mark-fb" aria-hidden="true">K</span>';
    function obFeat(ico, t, d) {
      return '<li class="dd-row ob-feat"><span class="dd-ico">' + obIco(ico) + '</span>' +
             '<span class="dd-k ob-feat-k">' + t + '<i>' + d + '</i></span></li>';
    }
    var mask = obEl(
      '<div class="ob-mask' + (isLegacy ? ' is-legacy' : '') + '" role="dialog" aria-modal="true" aria-label="欢迎使用">' +
        '<div class="ob-card">' +
          /* 页眉＝品牌 + 等宽步数计数（与站内「黑白 + tabular-nums」同一语言） */
          '<div class="ob-head">' +
            (isLegacy ? '' : '<button type="button" class="ob-back" id="obBack" aria-label="返回上一步" hidden>' + obIco(OB_ICO.back) + '</button>') +
            markHtml +
            '<span class="ob-head-txt">' +
              '<span class="logo-cn">' + esc(APP_NAME) + '</span>' +
              '<span class="ob-tag">' + (isLegacy ? '本机已有数据 · 建立档案' : '本地优先 · 无需注册') + '</span>' +
            '</span>' +
            '<span class="ob-count" aria-hidden="true"><b class="' + (isLegacy ? '' : 'on') + '">01</b><i>/</i><b class="' + (isLegacy ? 'on' : '') + '">02</b></span>' +
          '</div>' +
          '<div class="ob-step ob-step-welcome"' + (isLegacy ? ' hidden' : '') + '>' +
            '<div class="dd-hero">' +
              '<h2 class="ob-title">欢迎使用 ' + esc(APP_NAME) + '</h2>' +
              '<p class="ob-desc">这是一个<b>本地优先</b>的工作台：打开即用、无需注册登录，' +
                '所有数据都写在你自己的设备上。</p>' +
            '</div>' +
            '<ul class="dd-group ob-feats">' +
              obFeat(OB_ICO.db, '数据存本机', '以你的昵称命名，随时可导出备份文件') +
              obFeat(OB_ICO.offline, '离线可用', '断网也能完整使用全部功能') +
              obFeat(OB_ICO.cloud, '可选登录', '登录后同步到云端，多设备共用') +
            '</ul>' +
            '<div class="ob-foot">' +
              '<div class="ob-tear" aria-hidden="true"></div>' +
              '<button type="button" class="btn btn-primary btn-block ob-go" id="obStart">开始使用' + obIco(OB_ICO.go) + '</button>' +
            '</div>' +
          '</div>' +
          '<div class="ob-step ob-step-nick"' + (isLegacy ? '' : ' hidden') + '>' +
            '<div class="dd-hero">' +
              '<h2 class="ob-title">' + (isLegacy ? '设置昵称' : '给自己起个昵称') + '</h2>' +
              '<p class="ob-desc">' + (isLegacy
                ? '检测到本机已有工作数据。设置昵称后，数据将迁移到以昵称命名的数据文件中继续使用。'
                : '你的数据将以昵称命名保存在本机，之后也可以随时登录账号进行云端同步。') + '</p>' +
            '</div>' +
            '<div class="dd-group ob-form">' +
              '<div class="ob-nfield">' +
                '<label class="ob-nlab" for="obNick">昵称</label>' +
                '<input class="form-input ob-ninput" type="text" id="obNick" maxlength="20" placeholder="例如：小明、阿真" autocomplete="off" autocapitalize="off" spellcheck="false">' +
                '<div class="form-error" id="obErr" role="alert"></div>' +
              '</div>' +
              '<div class="ob-nfile">' +
                '<span class="dd-ico">' + obIco(OB_ICO.file) + '</span>' +
                '<span class="ob-nfile-k">本机数据文件</span>' +
                '<code class="ob-nfile-v" id="obFile">wb_data_—</code>' +
              '</div>' +
            '</div>' +
            '<div class="ob-foot">' +
              '<div class="ob-tear" aria-hidden="true"></div>' +
              '<button type="button" class="btn btn-primary btn-block ob-go" id="obCreate">' + (isLegacy ? '迁移并继续' : '创建我的数据文件') + '</button>' +
              '<p class="ob-note">昵称只用于本机命名，之后可随时在个人中心修改</p>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
    document.body.appendChild(mask);

    var stepW = $('.ob-step-welcome', mask);
    var stepN = $('.ob-step-nick', mask);
    var input = $('#obNick', mask);
    var err = $('#obErr', mask);
    var fileEl = $('#obFile', mask);
    var form = $('.ob-form', mask);

    /* 文件名预览：与 WorkbenchDB.slugify 同一清洗规则（两端 IIFE 独立，此处不复用其内部函数） */
    function fileOf(v) {
      var s = String(v == null ? '' : v).replace(/[\\/:*?"<>|\x00-\x1f]/g, '').trim();
      return 'wb_data_' + (s || '—');
    }
    function showNick() {
      stepW.hidden = true;
      stepN.hidden = false;
      $all('.ob-count b', mask).forEach(function (el, i) { el.classList.toggle('on', i === 1); });
      var bk = $('#obBack', mask);
      if (bk) { bk.hidden = false; bk.disabled = false; }
      input.focus();
    }
    function showWelcome() {
      stepN.hidden = true;
      stepW.hidden = false;
      $all('.ob-count b', mask).forEach(function (el, i) { el.classList.toggle('on', i === 0); });
      var bk = $('#obBack', mask);
      if (bk) { bk.hidden = true; bk.disabled = true; }
    }
    function fail(msg) {
      err.textContent = msg;
      err.classList.add('show');
      form.classList.remove('bad');
      void form.offsetWidth; /* 重触抖动：同一错误连点两次也要有反馈 */
      form.classList.add('bad');
      input.focus();
      input.select();
    }
    function submit() {
      var v = input.value;
      if (!v.trim()) { fail('昵称不能为空，起一个你喜欢的名字吧'); return; }
      if (v.trim().length > 20) { fail('昵称不能超过 20 个字符'); return; }
      if (window.WorkbenchDB.nickConflict(v)) { fail('这个昵称在本机已有同名数据文件，请换一个'); return; }
      var res;
      try {
        res = WorkbenchDB.setupProfile(v, ident.legacyFrom || '');
      } catch (e) {
        fail(e && e.message ? e.message : '创建失败，请重试');
        return;
      }
      /* 退场：整卡下滑淡出（与手机端上滑成对），遮罩同时放行点击，不挡后续渲染 */
      mask.classList.add('is-out');
      if (appEl && 'inert' in appEl) appEl.inert = false;
      setTimeout(function () { if (mask.parentNode) mask.remove(); }, 260);
      toast(res.migrated ? '数据已迁移到专属档案「' + res.profile.nickname + '」，欢迎回来' : '专属数据档案「' + res.profile.nickname + '」已创建，开始使用吧', 'ok');
      onDone();
    }

    $('#obStart', mask).addEventListener('click', showNick);
    $('#obCreate', mask).addEventListener('click', submit);
    if ($('#obBack', mask)) $('#obBack', mask).addEventListener('click', showWelcome);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
    input.addEventListener('input', function () {
      err.classList.remove('show');
      form.classList.remove('bad');
      fileEl.textContent = fileOf(input.value);
    });
    if (isLegacy) setTimeout(function () { input.focus(); }, 60);
  }

  /* ---------- 身份相关的静态 UI（侧栏昵称 / 头像） ---------- */
  function refreshIdentityUi() {
    var name = displayUser();
    var isFirst = !name ? '' : name.charAt(0).toUpperCase();
    var av = safeAvatar((LOGIN_AUTHED && myProfile) ? myProfile.avatar : '');
    $all('.user-avatar').forEach(function (el) {
      if (av) { el.innerHTML = '<img class="avatar-img" src="' + esc(av) + '" alt="">'; }
      else { el.textContent = isFirst || '客'; }
    });
    $all('.user-name').forEach(function (el) {
      if (el.querySelector('.role-badge')) return; /* 登录态徽章由 PHP 渲染，保留 */
      el.textContent = name;
    });
    $all('.user-sub').forEach(function (el) { if (el.textContent === '本地模式' && LOGIN_AUTHED) el.textContent = '个人中心'; });
    var avatarBtn = $('#avatarBtn');
    if (avatarBtn) {
      if (av) { avatarBtn.innerHTML = '<img class="avatar-img" src="' + esc(av) + '" alt="">'; }
      else { avatarBtn.textContent = isFirst || '客'; }
    }
  }

  /* ---------- 登录弹卡（本地模式顶栏「登录」按钮） ---------- */
  function openLoginModal() {
    var mask = $('#loginMask');
    if (!mask) return;
    mask.hidden = false;
    var u = $('#username', mask);
    if (u && window.matchMedia('(hover: hover) and (pointer: fine)').matches) u.focus();
  }

  /* 登录卡由 index.php 内联脚本开合（closeLogin 落 hidden=true）。为把它纳入统一返回栈，
     又不在两处脚本各挂 popstate 抢栈——这里只用 MutationObserver 观察 #loginMask 的 hidden
     属性：变可见就压一层（返回时点 #loginX 让内联脚本正常收尾），变隐藏就消费该层。 */
  function wireLoginBack() {
    if (!WbBack.supported) return;
    var lm = $('#loginMask');
    if (!lm || typeof MutationObserver === 'undefined') return;
    var fr = null;
    function shown() { return !lm.hidden; }
    function enterF() {
      if (fr) return;
      fr = WbBack.enter(function () { var x = $('#loginX'); if (x) x.click(); });
    }
    function leaveF() {
      if (!fr) return;
      var f = fr; fr = null;
      WbBack.finish(f);
    }
    new MutationObserver(function () { shown() ? enterF() : leaveF(); })
      .observe(lm, { attributes: true, attributeFilter: ['hidden'] });
    if (shown()) enterF(); /* 登录失败时 data-open 在启动即展开：补登记 */
  }

  function startApp() {
    refreshIdentityUi();
    wireLoginBack();

    /* 登录态：拉取当前账号资料（昵称 + 头像），成功后刷新顶栏身份区；失败静默回落首字母 */
    if (LOGIN_AUTHED && loginUser()) {
      fetch('api/account.php?action=profile&_ts=' + Date.now(), { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (res) {
          if (!res || !res.ok) return;
          myProfile = { nickname: String(res.nickname || ''), avatar: String(res.avatar || '') };
          refreshIdentityUi();
        })
        .catch(function () { /* 静默降级 */ });
    }

    /* 异步数据层就绪失败兜底：IndexedDB 运行期写失败且旧存储也满时弹窗 */
    DB.onQuota = function () { quotaModal(); };

    DB.load(function (err) {
      if (err) {
        if (err instanceof Errors.CorruptError) {
          corruptModal(err.message);
          return;
        }
        toast(err && err.message ? err.message : '数据初始化失败', 'error');
        return;
      }

      /* 恢复上次所在视图（UI 状态持久化）并渲染 */
      loadUiState();
      renderAll();

      var ident = DB.detectIdentity();
      if (ident.mode === 'local' && ident.expiredFallback) {
        toast('登录已过期，暂用本地数据；重新登录后自动同步', 'warn');
      }

      if (DB.CLOUD_ENABLED) {
        /* 登录前把本地模式（昵称档案）积累的数据并入工作副本（IndexedDB），
           使下面的云端合并包含本地模式的全部变更——切换不丢数据 */
        DB.adoptLocalProfileData(function (adopted) {
          /* 登录态：MySQL 主存 + 本地镜像。初始化合并（并集、新者优先）——
             离线期间产生的本地变更在此回同步，云端新数据也会并入本地 */
          DB.onSync = function (kind) {
            if (kind === 'offline') toast('连不上云端，已暂存本机并自动重试', 'warn');
            if (kind === 'server-error') toast('云端保存失败，已暂存本机稍后重试', 'warn');
            if (kind === 'restored') toast('云端保存已恢复，离线变更已同步', 'ok');
          };
          DB.pullRemote(
            function (state) {
              try {
                DB.mergeRemote(state);
                renderAll();
                toast(adopted ? 'Hi，' + displayUser() + '！本地数据已与云端合并同步' : 'Hi，' + displayUser() + '！云端数据已同步', 'ok');
              } catch (e) {
                handleMutationError(e);
              }
            },
            function () {
              /* 云端为空：本地已有数据（如本地模式积累）迁移上云 */
              var local = DB.exportData();
              if (local.todo.length || local.memo.length || local.special_date.length || local.habits.length || local.habit_log.length || local.diary.length || local.receipts.length) {
                DB.pushRemote(local, function () {
                  toast('本机数据已同步至云端', 'ok');
                });
              }
            },
            function (msg) {
              toast(msg || '暂时连不上云端，当前仅使用本机数据', 'warn');
            }
          );
        });
      } else {
        /* 本地模式：不连接云端，全部数据仅存本机 */
        DB.onSync = function () { /* 本地模式无云同步 */ };
      }

      /* 数据就绪后再做每日首开备份（此前在 init 阶段调用时数据未加载，从未生效） */
      initAutoBackup();

      /* 日记配图：一批转成服务器引用后回调 UI 就地刷新；
         启动稳定后与恢复联网时补传本机暂存（本地模式内部自判，不碰接口） */
      DB.onImages = refreshDiaryImages;
      setTimeout(function () { DB.IMAGES.flush(); }, 2600);
      window.addEventListener('online', function () { DB.IMAGES.flush(); });
    });
  }

  function init() {
    /* 主题已由 <head> 内联脚本预置，这里同步 meta 与切换事件 */
    var meta = $('#metaThemeColor');
    if (meta) meta.setAttribute('content', currentTheme() === 'dark' ? '#101114' : '#F7F8FA');

    bindEvents();

    /* 登录弹卡入口（未登录渲染）：顶栏按钮 + 登录失败自动弹出 */
    var btnLogin = $('#btnLogin');
    if (btnLogin) btnLogin.addEventListener('click', openLoginModal);
    var loginMask = $('#loginMask');
    if (loginMask && loginMask.getAttribute('data-open') === '1') {
      loginMask.hidden = false;
      var lu = $('#username', loginMask);
      if (lu && window.matchMedia('(hover: hover) and (pointer: fine)').matches) lu.focus();
    }

    /* 桌面提醒 / 快捷键（每日自动备份移至 startApp 数据就绪后触发） */
    initReminder();
    initShortcuts();

    /* 首次访问（欢迎 → 昵称）与老用户升级（补昵称 + 数据迁移）走 onboarding，
       完成后再进入正常启动 */
    var ident = DB.detectIdentity();
    if (ident.mode === 'fresh' || ident.mode === 'legacy') {
      runOnboarding(ident, startApp);
      return;
    }
    startApp();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
