/* ============================================================
   WorkbenchDB — 轻量工作台独立数据层
   ------------------------------------------------------------
   · 工作副本：内存（读写零延迟，对外同步接口不变）
   · 本地持久层：IndexedDB（大容量，键与旧键值存储一一对应）；
     打开失败（隐私模式等）自动降级回浏览器键值存储（5MB 配额）
   · 云端持久层：MySQL（api/db.php）——每次变更后 400ms 防抖全量推送；
     页面初始化时以服务器状态为事实源拉取，服务器为空时自动迁移本地数据
   · 职责：读写 / 校验 / 版本迁移 / 全部业务 CRUD / 云端同步 / 异常抛出
   · 约定：解析失败等异常一律向外抛出（CorruptError），
     禁止在数据层内部静默重置清空数据；
     存储空间占满抛出 QuotaError 或触发 onQuota 回调，交由 UI 层提示。
   · 迁移：通过 _v 版本号逐级升级，兼容旧浏览器缓存；
     首次启动自动把旧键值存储数据迁入 IndexedDB（校验一致后清理旧键）。
   ============================================================ */
(function (global) {
  'use strict';

  /* ---------------- 身份与存储拓扑（本地优先、可选云端） ----------------
     · 登录态（window.LOGIN_AUTHED=true）：MySQL 为主存，localStorage 键
       「workbench_db_v1_<账号>」作离线镜像，断网期间本地可写、恢复后回同步。
     · 本地模式（未登录）：数据只存 localStorage 键「wb_data_<昵称slug>」
       —— 以欢迎流程中设置的昵称命名的本地 JSON 数据文件，不调用任何 API。
     · 本地身份存于「wb_profile_v1」；旧版无昵称数据（workbench_db_v1_*）
       在首次升级时迁移进昵称文件，历史数据不丢失。 */
  var PROFILE_KEY = 'wb_profile_v1';
  var PENDING_KEY = 'wb_data__pending'; /* 首次访问尚未设置昵称时的暂存键（正常流程不会写入） */
  var SCHEMA_VERSION = 8;
  var AUTHED = (typeof window.LOGIN_AUTHED !== 'undefined') ? !!window.LOGIN_AUTHED : true;
  /* 登录态 = 当前账号；未登录（会话过期/主动登出）= 上次登录账号（app.js 落盘），
     用于定位登录镜像键做数据衔接 */
  var LAST_USER = String((typeof window.LOGIN_USER !== 'undefined' && window.LOGIN_USER) ? window.LOGIN_USER : '');
  if (!LAST_USER) {
    try { LAST_USER = String(global.localStorage.getItem('wb_login_user') || ''); } catch (e) { LAST_USER = ''; }
  }
  var profile = null;      /* 本地身份 {nickname, slug, createdAt} */
  var STORAGE_KEY;         /* 当前生效的本地存储键 */
  var LEGACY_MIGRATE_FROM = ''; /* 升级场景：待迁移的旧版数据键（setupProfile 时消费） */

  function readProfile() {
    try {
      var raw = global.localStorage.getItem(PROFILE_KEY);
      if (!raw) return null;
      var p = JSON.parse(raw);
      if (p && typeof p.nickname === 'string' && p.nickname && typeof p.slug === 'string' && p.slug) {
        return { nickname: String(p.nickname), slug: String(p.slug), createdAt: String(p.createdAt || '') };
      }
    } catch (e) { /* 损坏则视为无身份，走重建流程 */ }
    return null;
  }

  /* 昵称 → 存储键 slug：去除文件名非法字符与首尾空白（不强制 ASCII，中文名可用） */
  function slugify(name) {
    return String(name == null ? '' : name).replace(/[\\/:*?"<>|\x00-\x1f]/g, '').trim();
  }

  function dataKeyOf(slug) { return 'wb_data_' + slug; }
  function legacyKeyOf(user) { return 'workbench_db_v1_' + String(user || 'default'); }

  function hasKeyData(key) {
    try {
      var raw = global.localStorage.getItem(key);
      return typeof raw === 'string' && raw.length > 2;
    } catch (e) { return false; }
  }

  /* ---------------- 删除墓碑（liveness log） ----------------
     合并规则是「按 id 取并集 + 新值优先」，而删除在并集里是隐形的：
     只要云端或另一台设备还留着旧副本，下一轮 pull→merge 就会把刚删的条目并回来，
     表现为「数据删不掉、回收站清不空」。因此删除动作必须显式留痕：
       deleted: [{ id, type, at, gone }]   gone=true 已删 / gone=false 已恢复
     同一 (type,id) 取 at 最大的一条为准，并用它过滤各集合。
     墓碑保留 45 天（> 回收站 30 天窗口），足够离线设备上线后收敛。 */
  var DEAD_KEEP_DAYS = 45;
  var DEAD_MAX = 3000;
  var DEAD_TYPES = ['todo', 'memo', 'special_date', 'diary', 'habits', 'categories', 'receipts', 'trash', 'event_types'];

  /* 归一化：同键去重留最新 + 过期清理 + 按时间倒序截断 */
  function normDeleted(list) {
    var out = [], seen = {}, i, e, k, at, cur;
    if (!Array.isArray(list)) return out;
    for (i = 0; i < list.length; i++) {
      e = list[i];
      if (!isObj(e) || e.id == null || DEAD_TYPES.indexOf(e.type) === -1) continue;
      k = e.type + '|' + e.id;
      at = typeof e.at === 'string' ? e.at.slice(0, 40) : '';
      cur = seen[k];
      if (cur) {
        if (at >= cur.at) { cur.at = at; cur.gone = e.gone !== false; }
        continue;
      }
      cur = { id: String(e.id).slice(0, 40), type: e.type, at: at, gone: e.gone !== false };
      seen[k] = cur; out.push(cur);
    }
    var limit = Date.now() - DEAD_KEEP_DAYS * 86400000;
    out = out.filter(function (r) {
      var t = Date.parse(r.at);
      return !(isNaN(t) || t < limit);
    });
    out.sort(function (x, y) { return String(y.at).localeCompare(String(x.at)); });
    return out.slice(0, DEAD_MAX);
  }

  function deadIndex(deleted) {
    var m = {}, i, r;
    for (i = 0; i < (deleted || []).length; i++) {
      r = deleted[i];
      if (r && r.gone) m[r.type + '|' + r.id] = String(r.at || '');
    }
    return m;
  }

  /* 删除时刻不早于条目自身时间才算数：条目在删除之后又被恢复/编辑过则条目胜出 */
  function filterDead(list, type, dead, timeOf) {
    if (!Array.isArray(list) || !list.length) return list || [];
    return list.filter(function (it) {
      if (!it || it.id == null) return true;
      var at = dead[type + '|' + it.id];
      if (at === undefined) return true;
      return !(at >= timeOf(it));
    });
  }

  /* ---------------- 状态合并（本地 ↔ 镜像 ↔ 云端 共用） ----------------
     集合并集；同 id 条目按更新时间新者优先（updatedAt > doneAt > createdAt）。
     prim 序保留（用于无显式排序的集合：habits/categories/回收站），sec 独有条目追加。 */
  function mergeStates(a, b, bOrderForSets) {
    function timeOf(it) { return String((it && (it.updatedAt || it.doneAt || it.createdAt || it.deletedAt)) || ''); }
    function newer(x, y) { return timeOf(x) > timeOf(y) ? x : y; } /* 平局判给 prim（本地），避免本地无 updatedAt 的编辑被云端旧值覆盖 */
    function merge(prim, sec) {
      var p = prim || [], s = sec || [], out = [], seen = {}, i, it;
      var sMap = {};
      for (i = 0; i < s.length; i++) { it = s[i]; if (it && it.id != null) sMap[it.id] = it; }
      for (i = 0; i < p.length; i++) {
        it = p[i];
        if (!it || it.id == null || seen[it.id]) continue;
        seen[it.id] = 1;
        out.push(sMap[it.id] ? newer(sMap[it.id], it) : it);
      }
      for (i = 0; i < s.length; i++) {
        it = s[i];
        if (!it || it.id == null || seen[it.id]) continue;
        seen[it.id] = 1;
        out.push(it);
      }
      return out;
    }
    function unionLog(l1, l2) {
      var pos = {}, out = [], i, x, k, p;
      var all = (l1 || []).concat(l2 || []);
      for (i = 0; i < all.length; i++) {
        x = all[i];
        if (!x || !x.h || !x.d) continue;
        k = x.h + '|' + x.d;
        if (!(k in pos)) { pos[k] = out.length; out.push(x); continue; }
        /* 单日可多次打卡 ⇒ 同 (习惯, 日期) 只留一行（行内 n 记次数）：
           谁的 updatedAt 新听谁的，平局判给先入列的一侧（本地），
           避免本地刚「+1 / -1」的次数被云端旧值吞回去 */
        p = out[pos[k]];
        if (String(x.updatedAt || '') > String(p.updatedAt || '')) out[pos[k]] = x;
      }
      return out;
    }
    /* bOrderForSets=true：habits/categories 以 b（云端）顺序为准（服务器 sort 序） */
    function setPair(name) {
      return bOrderForSets ? merge(b[name], a[name]) : merge(a[name], b[name]);
    }
    /* 墓碑先合并（两侧取并、同键新者为准），再据此过滤各集合 */
    var deleted = normDeleted((a.deleted || []).concat(b.deleted || []));
    var dead = deadIndex(deleted);
    function fd(list, type) { return filterDead(list, type, dead, timeOf); }
    return {
      _v: SCHEMA_VERSION,
      habits: fd(setPair('habits'), 'habits'),
      categories: fd(setPair('categories'), 'categories'),
      event_types: fd(merge(a.event_types, b.event_types), 'event_types'),
      todo: fd(merge(a.todo, b.todo), 'todo'),
      memo: fd(merge(a.memo, b.memo), 'memo'),
      special_date: fd(merge(a.special_date, b.special_date), 'special_date'),
      diary: fd(merge(a.diary, b.diary), 'diary'),
      receipts: fd(merge(a.receipts, b.receipts), 'receipts'),
      trash: fd(merge(a.trash, b.trash), 'trash'),
      habit_log: unionLog(a.habit_log, b.habit_log),
      deleted: deleted
    };
  }

  var expiredFallback = false; /* 会话过期后由登录镜像续用本地数据的标记（UI 提示用） */

  (function resolveIdentity() {
    profile = readProfile();
    if (AUTHED) {
      STORAGE_KEY = legacyKeyOf(LAST_USER);
      return;
    }
    if (profile) {
      STORAGE_KEY = dataKeyOf(profile.slug);
      /* 会话过期（曾登录后回到本地模式）的镜像数据衔接改在 load() 内异步完成：
         上次登录账号的镜像（IndexedDB / 旧存储）与昵称档案全量合并，数据无缝续用 */
      return;
    }
    /* 无本地身份：探测旧版数据键（老用户升级补昵称）；都没有 = 真·首次访问 */
    var cands = LAST_USER ? [legacyKeyOf(LAST_USER), legacyKeyOf('default')] : [legacyKeyOf('default')];
    for (var i = 0; i < cands.length; i++) {
      if (hasKeyData(cands[i])) { LEGACY_MIGRATE_FROM = cands[i]; break; }
    }
    STORAGE_KEY = LEGACY_MIGRATE_FROM || PENDING_KEY;
  })();

  var TRASH_KEEP_DAYS = 30;
  var TRASH_MAX = 500;

  /* ---------------- 异常类型 ---------------- */
  function DBError(message) {
    this.name = 'DBError';
    this.message = message || '数据层错误';
    this.stack = new Error().stack;
  }
  DBError.prototype = Object.create(Error.prototype);
  DBError.prototype.constructor = DBError;

  /* 本地缓存解析 / 结构失败 —— 交由 UI 弹窗，绝不静默重置 */
  function CorruptError(message) {
    DBError.call(this, message || '本地缓存数据已损坏');
    this.name = 'CorruptError';
  }
  CorruptError.prototype = Object.create(DBError.prototype);
  CorruptError.prototype.constructor = CorruptError;

  /* LocalStorage 写入失败（配额已满等） */
  function QuotaError(message) {
    DBError.call(this, message || '本地存储空间已满');
    this.name = 'QuotaError';
  }
  QuotaError.prototype = Object.create(DBError.prototype);
  QuotaError.prototype.constructor = QuotaError;

  /* 入参数据不合法 */
  function ValidationError(message) {
    DBError.call(this, message || '数据校验失败');
    this.name = 'ValidationError';
  }
  ValidationError.prototype = Object.create(DBError.prototype);
  ValidationError.prototype.constructor = ValidationError;

  /* ---------------- IndexedDB 持久层（大容量本地存储） ----------------
     键与旧键值存储一一对应（wb_data_<slug> / workbench_db_v1_<账号>），
     值统一为 JSON 字符串（与旧存储内容格式一致，迁移/对比零歧义）。
     打开失败（隐私模式、被策略禁用等）自动降级回旧键值存储，业务层无感。 */
  var IDB_NAME = 'wb_workbench';
  var IDB_STORE = 'kv';
  var idbDb = null;        /* 打开成功的 IDBDatabase；null = 尚未打开或不可用 */
  var idbBroken = false;   /* 打开失败 / 运行期不可用 → 降级标记 */
  var storageMode = 'legacy'; /* 'idb' = IndexedDB 主存；'legacy' = 旧键值存储 */
  var idbKeyCache = null;  /* IDB 全部键名缓存（getAllKeys），同步占位检测用 */

  function idbOpen(done) {
    if (idbDb) { done(idbDb); return; }
    if (idbBroken || typeof global.indexedDB === 'undefined' || !global.indexedDB) {
      idbBroken = true; done(null); return;
    }
    try {
      var req = global.indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = function (e) {
        var d = e.target.result;
        if (!d.objectStoreNames.contains(IDB_STORE)) d.createObjectStore(IDB_STORE);
      };
      req.onsuccess = function (e) { idbDb = e.target.result; done(idbDb); };
      req.onerror = function () { idbBroken = true; done(null); };
      req.onblocked = function () { idbBroken = true; done(null); };
    } catch (e) { idbBroken = true; done(null); }
  }

  /* done(value, unavailable)：unavailable=true 表示 IDB 不可用（调用方走降级） */
  function idbGet(key, done) {
    idbOpen(function (db) {
      if (!db) { done(null, true); return; }
      try {
        var tx = db.transaction(IDB_STORE, 'readonly');
        var rq = tx.objectStore(IDB_STORE).get(key);
        rq.onsuccess = function () { done(rq.result != null ? rq.result : null); };
        rq.onerror = function () { done(null); };
      } catch (e) { done(null); }
    });
  }

  function idbSet(key, value, done) {
    idbOpen(function (db) {
      if (!db) { if (done) done(false); return; }
      try {
        var tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(value, key);
        tx.oncomplete = function () { if (done) done(true); };
        tx.onerror = function () { if (done) done(false); };
        tx.onabort = function () { if (done) done(false); };
      } catch (e) { if (done) done(false); }
    });
  }

  function idbDel(key, done) {
    idbOpen(function (db) {
      if (!db) { if (done) done(false); return; }
      try {
        var tx = db.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).delete(key);
        tx.oncomplete = function () { if (done) done(true); };
        tx.onerror = function () { if (done) done(false); };
      } catch (e) { if (done) done(false); }
    });
  }

  function idbRefreshKeys(done) {
    idbOpen(function (db) {
      if (!db) { if (done) done(); return; }
      try {
        var tx = db.transaction(IDB_STORE, 'readonly');
        var rq = tx.objectStore(IDB_STORE).getAllKeys();
        rq.onsuccess = function () { idbKeyCache = rq.result || []; if (done) done(); };
        rq.onerror = function () { if (done) done(); };
      } catch (e) { if (done) done(); }
    });
  }

  function idbHasKey(key) {
    return !!(idbKeyCache && idbKeyCache.indexOf(key) !== -1);
  }

  /* ---------------- 内部工具 ---------------- */
  function str(v) { return v == null ? '' : String(v); }

  function nextId(prefix) {
    return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function normDate(v) {
    var s = str(v).trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : '';
  }

  function normPriority(v) {
    return v === 'high' || v === 'low' ? v : 'normal';
  }

  function normType(v) {
    var s = str(v).trim();
    if (s === 'birthday' || s === 'anniversary') return s;
    /* 自定义事件类型 id：安全字符集 + 限长，空/非法回落「生日」 */
    return /^[A-Za-z0-9_-]{1,40}$/.test(s) ? s : 'birthday';
  }

  function normCategoryId(v) {
    return str(v).trim().slice(0, 40);
  }

  /* ---------------- 日记配图：引用形态与归一化 ----------------
     一枚配图 = { u: 引用, t?: 缩略图引用 }，u/t 只接受两种形态（与后端 wb_img_ref 同规则）：
       · /api/img.php?t=<16hex 用户段>/<32hex 文件段>.<jpg|png|webp> —— 已上云的文件
       · data:image/(jpeg|png|webp);base64,...                     —— 仅存本机（本地模式或尚未上传完）
     单篇最多 9 张，超出的尾部丢弃。 */
  var IMG_REF_RE  = /^\/api\/img\.php\?t=[0-9a-f]{16}\/[0-9a-f]{32}\.(?:jpg|png|webp)$/;
  var IMG_DATA_HEADS = ['data:image/jpeg;base64', 'data:image/png;base64', 'data:image/webp;base64'];
  var IMG_DATA_MAX = 1600000;   /* 单张 data: 暂存上限（与后端 wb_img_ref 一致） */
  var DIARY_IMG_MAX = 9;

  /* data: 暂存形态：前缀白名单 + 长度封顶 + 负向字符类扫描。
     不用 `[A-Za-z0-9+/=]{24,}$` 这类「贪婪类 + 结尾锚点」——对 1MB+ 的 base64
     遇到非法字符会退化成整串反复回吐，归一化每篇最多 9 张时足以看出卡顿。 */
  function isDataImg(s) {
    if (s.indexOf('data:image/') !== 0) return false;
    var comma = s.indexOf(',');
    if (comma < 0 || IMG_DATA_HEADS.indexOf(s.slice(0, comma)) < 0) return false;
    var body = s.slice(comma + 1);
    if (body.length < 24 || body.length > IMG_DATA_MAX) return false;
    return !/[^A-Za-z0-9+\/=]/.test(body);
  }

  function imgRef(v) {
    var s = str(v).trim();
    return (IMG_REF_RE.test(s) || isDataImg(s)) ? s : '';
  }

  function isCloudImg(s) { return IMG_REF_RE.test(str(s)); }

  function normDiaryImages(list) {
    if (!Array.isArray(list)) return [];
    var out = [], i, it, u, t;
    for (i = 0; i < list.length && out.length < DIARY_IMG_MAX; i++) {
      it = list[i];
      if (it && typeof it === 'object') { u = imgRef(it.u); t = imgRef(it.t); }
      else { u = imgRef(it); t = ''; }
      if (!u) continue;
      out.push(t ? { u: u, t: t } : { u: u });
    }
    return out;
  }

  /* data: URI → Blob（上传接口的入参）；非法/超限返回 null */
  function dataUriToBlob(uri) {
    var s = String(uri);
    var comma = s.indexOf(',');
    if (comma < 0) return null;
    var m = /^data:([^;,]+)/.exec(s.slice(0, comma));
    var mime = (m && m[1]) ? m[1] : 'image/jpeg';
    var bin;
    try { bin = global.atob(s.slice(comma + 1)); } catch (e) { return null; }
    var len = bin.length, bytes = new Uint8Array(len), j;
    for (j = 0; j < len; j++) bytes[j] = bin.charCodeAt(j);
    try { return new global.Blob([bytes], { type: mime }); } catch (e) { return null; }
  }

  function normColor(v) {
    var s = str(v).trim();
    return /^#[0-9a-fA-F]{3,8}$/.test(s) ? s.toLowerCase() : '#888780';
  }

  /* 打卡次数：字段缺失（旧数据一行即一次）按 1 次；
     显式 0 是「已取消」的墓碑行，必须原样保留，否则这次取消会在合并时丢掉 */
  function normTimes(v) {
    if (v === undefined || v === null || v === '') return 1;
    var n = parseInt(v, 10);
    if (isNaN(n)) return 1;
    if (n < 0) return 0;
    return n > 99 ? 99 : n;
  }

  function normCatName(v) {
    return str(v).trim().slice(0, 12);
  }

  /* 重复规则白名单：{type:daily|weekly|monthly|yearly, days?:[0-6], dom?:1-31} */
  function normRepeat(v) {
    if (!isObj(v)) return null;
    var type = str(v.type);
    if (['daily', 'weekly', 'monthly', 'yearly'].indexOf(type) === -1) return null;
    var out = { type: type };
    if (type === 'weekly') {
      var days = [];
      for (var i = 0; i < 7; i++) {
        if (Array.isArray(v.days) && v.days.indexOf(i) !== -1) days.push(i);
      }
      if (!days.length) return null;
      out.days = days;
    } else if (type === 'monthly') {
      var dom = parseInt(v.dom, 10);
      if (!(dom >= 1 && dom <= 31)) return null;
      out.dom = dom;
    }
    return out;
  }

  /* 子任务白名单：[{id,title,done}] ≤20 项 */
  function normSubtasks(list) {
    if (!Array.isArray(list)) return [];
    var out = [];
    for (var i = 0; i < list.length && out.length < 20; i++) {
      var s = list[i];
      if (!isObj(s)) continue;
      var title = str(s.title).trim().slice(0, 100);
      if (!title) continue;
      out.push({ id: str(s.id) || nextId('s'), title: title, done: !!s.done });
    }
    return out;
  }

  /* 重复任务「下一次」截止日：以 base（无 due 时取今天）为起点严格向后找 */
  function nextRepeatDate(base, rep) {
    if (!rep) return '';
    var p = /^\d{4}-\d{2}-\d{2}$/.test(str(base)) ? base.split('-').map(Number) : null;
    var now = new Date();
    var y = p ? p[0] : now.getFullYear();
    var m = p ? p[1] - 1 : now.getMonth();
    var d = p ? p[2] : now.getDate();
    var cur = new Date(y, m, d);

    function fmt(dt) { return toDateStr(dt); }
    function dim(yy, mm) { return new Date(yy, mm + 1, 0).getDate(); }

    if (rep.type === 'daily') {
      cur.setDate(cur.getDate() + 1);
      return fmt(cur);
    }
    if (rep.type === 'weekly') {
      for (var i = 1; i <= 7; i++) {
        var dt = new Date(y, m, d + i);
        if (rep.days.indexOf(dt.getDay()) !== -1) return fmt(dt);
      }
      return '';
    }
    if (rep.type === 'monthly') {
      var yy = y, mm = m;
      for (var j = 0; j < 48; j++) {
        mm += 1;
        if (mm > 11) { mm = 0; yy += 1; }
        var day = Math.min(rep.dom, dim(yy, mm));
        var cand = new Date(yy, mm, day);
        if (cand > cur) return fmt(cand);
      }
      return '';
    }
    /* yearly：顺延一年（Date 自动处理月末溢出） */
    var ny = new Date(y + 1, m, d);
    return fmt(ny);
  }

  function normTags(list) {
    if (!Array.isArray(list)) return [];
    var seen = {};
    var out = [];
    for (var i = 0; i < list.length && out.length < 12; i++) {
      var t = str(list[i]).trim().slice(0, 16);
      if (t && !seen[t]) { seen[t] = 1; out.push(t); }
    }
    return out;
  }

  function isObj(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }

  /* 本地日期字符串 YYYY-MM-DD（与设备时区一致） */
  function toDateStr(d) {
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  /* 距今天数：今天为 0，未来为正，过去为负 */
  function daysFromToday(dateStr) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(str(dateStr))) return null;
    var p = dateStr.split('-');
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var target = new Date(+p[0], +p[1] - 1, +p[2]);
    return Math.round((target - today) / 86400000);
  }

  /* 纪念日下一次发生日期：每年重复取未来最近周年，一次性取原日期 */
  function nextOccur(ev) {
    var base = str(ev.date);
    if (!ev.repeat) return base;
    if (ev.lunar && window.Lunar) return nextLunarOccur(base);
    var days = daysFromToday(base);
    if (days !== null && days >= 0) return base;
    var p = base.split('-');
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var n = new Date(now.getFullYear(), +p[1] - 1, +p[2]);
    if (n < today) n = new Date(now.getFullYear() + 1, +p[1] - 1, +p[2]);
    return toDateStr(n);
  }

  /* 某农历年中指定月日的公历日期：
     目标月无闰月时回退平月，日数超出该月天数时取月末 */
  function lunarDayInYear(y, m, d, leap) {
    var L = window.Lunar;
    var useLeap = leap && L.leapMonth(y) === m;
    var months = L.yearMonths(y), i, target = null;
    for (i = 0; i < months.length; i++) {
      if (months[i].m === m && months[i].leap === useLeap) { target = months[i]; break; }
    }
    if (!target) return null;
    if (d > target.days) d = target.days;
    return L.lunarToSolar(y, m, d, useLeap);
  }

  /* 农历重复事件：未来最近的农历周年（以公历表示）
     原日期仍在未来时优先原日期；否则从当前农历年起向后找 */
  function nextLunarOccur(base) {
    var L = window.Lunar;
    var l = L.solarToLunar(base);
    if (!l) return base;
    var now = new Date();
    var today = toDateStr(now);
    if (daysFromToday(base) >= 0) return base;
    var tl = L.solarToLunar(today);
    var startYear = tl ? tl.y : now.getFullYear();
    for (var i = 0; i < 2; i++) {
      var s = lunarDayInYear(startYear + i, l.m, l.d, l.leap);
      if (s && daysFromToday(s) >= 0) return s;
    }
    return base;
  }

  /* ---------------- 日记配图：本机暂存 → 服务器文件 ----------------
     登录态下把仍是 data: 暂存的图片逐张上传（并发 2 张：够快，又不挤占常规同步请求），
     成功后就地换成 /api/img.php 引用；整批结束才一次 save()，此后全量推送里只剩小字符串。
     本地模式（未登录）完全不碰接口：图片以 data: 暂存形态只留在本机 IndexedDB。
     上传失败者保持暂存 = UI 上「未上云」的小圆点，点一下即时重试，不额外打扰。 */
  var IMAGES = {
    MAX: DIARY_IMG_MAX,
    running: false,
    again: false,
    uploadUrl: 'api/upload.php?action=upload',
    recycleUrl: 'api/upload.php?action=delete',

    /* 引用是否已落到服务器文件 */
    isCloud: function (u) { return isCloudImg(str(u)); },

    /* 一组图片里是否还有「仅存本机」的暂存项 */
    hasLocal: function (list) {
      var imgs = list || [], i;
      for (i = 0; i < imgs.length; i++) {
        if (imgs[i] && !isCloudImg(imgs[i].u)) return true;
      }
      return false;
    },

    /* 一篇回顾里仍需上云的图片张数 */
    localCount: function (item) {
      var imgs = (item && item.images) || [], n = 0, i;
      for (i = 0; i < imgs.length; i++) { if (imgs[i] && !isCloudImg(imgs[i].u)) n++; }
      return n;
    },

    _itemById: function (id) {
      var list = (WorkbenchDB._data && WorkbenchDB._data.diary) || [], i;
      for (i = 0; i < list.length; i++) { if (list[i] && list[i].id === id) return list[i]; }
      return null;
    },

    /* 待上传清单（itemId 省略 = 全库扫描：断网恢复 / 启动补传） */
    _jobs: function (itemId) {
      var out = [], list = (WorkbenchDB._data && WorkbenchDB._data.diary) || [], i, j, imgs, im;
      for (i = 0; i < list.length; i++) {
        if (!list[i] || (itemId && list[i].id !== itemId)) continue;
        imgs = list[i].images || [];
        for (j = 0; j < imgs.length; j++) {
          im = imgs[j];
          if (im && im.u && !isCloudImg(im.u)) {
            out.push({ id: list[i].id, u: im.u, t: str(im.t) });
          }
        }
      }
      return out;
    },

    _send: function (job, onOk, onErr) {
      var blob = dataUriToBlob(job.u);
      if (!blob) { onErr('图片数据不可读'); return; }
      var fd = new global.FormData();
      fd.append('file', blob, 'diary');
      if (job.t) {
        var tb = dataUriToBlob(job.t);
        if (tb) fd.append('thumb', tb, 'thumb');
      }
      try {
        global.fetch(this.uploadUrl, { method: 'POST', credentials: 'same-origin', body: fd })
          .then(function (r) { return r.json(); })
          .then(function (res) { if (res && res.ok && res.u) { onOk(res); } else { onErr((res && res.error) || '上传失败'); } })
          .catch(function () { onErr('网络异常，图片未上传'); });
      } catch (e) { onErr('上传未发起'); }
    },

    /* 写回：按「原暂存值」定位（期间可能被拖动重排或删除，定位不到就安静放弃） */
    _apply: function (job, res) {
      var item = this._itemById(job.id);
      if (!item) return false;
      var imgs = item.images || [], i;
      for (i = 0; i < imgs.length; i++) {
        if (imgs[i] && imgs[i].u === job.u) {
          var t = isCloudImg(res.t) ? res.t : '';
          imgs[i] = t ? { u: res.u, t: t } : { u: res.u };
          return true;
        }
      }
      return false;
    },

    /* 上云一批（默认只处理刚保存的那一篇；无参调用用于补传全库） */
    flush: function (itemId) {
      var self = this;
      if (!WorkbenchDB.CLOUD_ENABLED) return;      /* 本地模式：图片只留本机 */
      var jobs = self._jobs(itemId);
      if (!jobs.length) return;
      if (self.running) { self.again = true; return; }
      self.running = true;
      var cursor = 0;
      function finish() {
        self.running = false;
        /* 收尾必推一次：saveDiary 见有暂存图时暂缓了推送，
           即使这批全部失败，正文变更也不能一直压在本地 */
        WorkbenchDB.save();
        if (typeof WorkbenchDB.onImages === 'function') WorkbenchDB.onImages(itemId);
        if (self.again) { self.again = false; self.flush(itemId); }
      }
      function worker() {
        if (cursor >= jobs.length) { if (--alive <= 0) finish(); return; }
        var job = jobs[cursor++];
        self._send(job, function (res) {
          self._apply(job, res);
          worker();
        }, function () {
          worker();                                /* 失败保持暂存，UI 以小圆点承接重试 */
        });
      }
      var alive = Math.min(2, jobs.length), k;
      for (k = 0; k < alive; k++) worker();
    },

    /* 编辑里摘掉的云端图片 → 请服务器删文件（fire-and-forget，失败下次开页面自然成为孤儿） */
    recycleRemoved: function (oldImgs, newImgs) {
      var kept = {}, i, refs = [];
      for (i = 0; i < (newImgs || []).length; i++) { if (newImgs[i]) kept[newImgs[i].u] = 1; if (newImgs[i] && newImgs[i].t) kept[newImgs[i].t] = 1; }
      for (i = 0; i < (oldImgs || []).length; i++) {
        var im = oldImgs[i];
        if (!im) continue;
        if (isCloudImg(im.u) && !kept[im.u]) refs.push(im.u);
        if (isCloudImg(im.t) && !kept[im.t]) refs.push(im.t);
      }
      this.recycle(refs);
    },

    recycle: function (refs) {
      refs = (refs || []).filter(function (r) { return isCloudImg(r); });
      if (!refs.length || !WorkbenchDB.CLOUD_ENABLED) return;
      try {
        global.fetch(this.recycleUrl, {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refs: refs })
        }).catch(function () { /* 回收失败不影响业务 */ });
      } catch (e) { /* 忽略 */ }
    }
  };

  /* ---------------- 数据层 ---------------- */
  var WorkbenchDB = {
    _data: null,

    /* 云端同步总开关：仅登录态启用；本地模式（未登录）数据只存本机 */
    CLOUD_ENABLED: AUTHED,

    /* 日记配图：上传/回收入口见 IMAGES；一批图片上云完成后回调 UI 层（刷新胶片条与角标） */
    IMAGES: IMAGES,
    onImages: null,

    /* 空种子数据 */
    seed: function () {
      return { _v: SCHEMA_VERSION, habits: [], habit_log: [], diary: [], trash: [], categories: [], event_types: [], todo: [], memo: [], special_date: [], receipts: [], deleted: [] };
    },

    /* 页面初始化：读取 + 解析 + 迁移；异步完成回调 onReady(err)。
       数据源优先级：IndexedDB 主键 → 旧键值存储（自动迁入 IDB）→ 种子数据。
       曾登录后回到本地模式的镜像衔接也在此异步完成（并集、新者优先）。
       首次访问（无昵称无历史数据）时由 UI 层先完成欢迎/昵称流程再 load，
       此处只回内存种子、不落盘，避免把数据写进「_pending」暂存键 */
    load: function (onReady) {
      var self = this;
      function done(err) { if (onReady) onReady(err || null); }
      function parseState(str) {
        var parsed = JSON.parse(str);
        if (!isObj(parsed)) throw new CorruptError('本地缓存数据结构异常，数据可能已损坏');
        return parsed;
      }
      function ready() {
        self.trashGC();
        idbRefreshKeys(function () { done(null); });
      }

      if (!AUTHED && !profile && STORAGE_KEY === PENDING_KEY) {
        this._data = this.seed();
        done(null);
        return;
      }

      idbGet(STORAGE_KEY, function (val, unavailable) {
        /* 迁移/衔接完成：内存态已就绪，落盘 IDB（成功则清旧键；失败回退旧存储）。
           settle/settleMirror 定义在回调内以直接访问 oldState */
        function settle() {
          if (oldState) {
            self._data = oldState;
            self.trashGC();
            idbSet(STORAGE_KEY, JSON.stringify(self._data), function (ok) {
              if (ok) {
                try { global.localStorage.removeItem(STORAGE_KEY); } catch (e) { /* 忽略 */ }
                storageMode = 'idb';
              } else {
                /* IDB 写入失败：数据保留在旧键值存储，本次会话走降级 */
                storageMode = 'legacy';
                try { global.localStorage.setItem(STORAGE_KEY, JSON.stringify(self._data)); } catch (e2) { /* 忽略 */ }
              }
              idbRefreshKeys(function () { done(null); });
            });
          } else {
            /* 两处都没有数据：种子（save 走 IDB） */
            self._data = self.seed();
            self.save(true);
            idbRefreshKeys(function () { done(null); });
          }
        }

        /* ---------- 降级路径：IndexedDB 不可用，沿用旧键值存储 ---------- */
        if (unavailable) {
          storageMode = 'legacy';
          var raw0 = null;
          try { raw0 = global.localStorage.getItem(STORAGE_KEY); } catch (e) { done(new CorruptError('无法访问浏览器本地存储（可能被浏览器隐私模式禁用）')); return; }
          if (raw0 === null || raw0 === '') { self._data = self.seed(); self.save(true); done(null); return; }
          var p0 = null;
          try { p0 = parseState(raw0); } catch (e) { done(e); return; }
          self._data = self.migrate(p0);
          self.trashGC();
          done(null);
          return;
        }

        /* ---------- 主路径：IndexedDB 有主数据 ---------- */
        storageMode = 'idb';
        if (val != null) {
          var p1 = null;
          try { p1 = parseState(val); } catch (e) { done(e); return; }
          self._data = self.migrate(p1);
          ready();
          return;
        }

        /* IDB 无主数据：尝试从旧键值存储迁入（老用户 / 旧版本升级） */
        var oldState = null;
        try {
          var rawOld = global.localStorage.getItem(STORAGE_KEY);
          if (typeof rawOld === 'string' && rawOld.length > 2) oldState = self.migrate(parseState(rawOld));
        } catch (e) { done(e); return; }

        /* 曾登录后过期：镜像衔接（旧存储镜像 / IDB 镜像 → 昵称档案，并集、新者优先） */
        function settleMirror() {
          if (!AUTHED && profile && LAST_USER) {
            var lk = legacyKeyOf(LAST_USER);
            try {
              var mraw = global.localStorage.getItem(lk);
              if (typeof mraw === 'string' && mraw.length > 2) {
                var mm = self.migrate(parseState(mraw));
                oldState = oldState ? mergeStates(oldState, mm, false) : mm;
                expiredFallback = true;
                try { global.localStorage.removeItem(lk); } catch (e2) { /* 忽略 */ }
              }
            } catch (e) { /* 镜像损坏不阻断，昵称档案数据仍可用 */ }
            idbGet(lk, function (mv) {
              if (mv != null) {
                try {
                  var m2 = self.migrate(parseState(mv));
                  oldState = oldState ? mergeStates(oldState, m2, false) : m2;
                  expiredFallback = true;
                  idbDel(lk);
                } catch (e) { /* 忽略 */ }
              }
              settle();
            });
            return;
          }
          settle();
        }

        settleMirror();
      });
    },

    /* 版本迁移：旧 _v 逐级升级；新版本缓存降级打开时保留原数据不动 */
    migrate: function (data) {
      if (typeof data._v !== 'number' || !isFinite(data._v)) data._v = 1;
      while (data._v < SCHEMA_VERSION) {
        switch (data._v) {
          case 1:
            /* v2：新增分类集合与待办分类 / 完成时刻字段 */
            data.categories = Array.isArray(data.categories) ? data.categories : [];
            data.todo.forEach(function (t) {
              if (t && typeof t.category !== 'string') t.category = '';
              if (t && typeof t.doneAt !== 'string') t.doneAt = '';
            });
            data._v = 2;
            break;
          case 2:
            /* v3：习惯集合 + 待办子任务 / 重复 + 备忘置顶 */
            data.habits = Array.isArray(data.habits) ? data.habits : [];
            data.habit_log = Array.isArray(data.habit_log) ? data.habit_log : [];
            data.todo.forEach(function (t) {
              if (!t) return;
              if (!Array.isArray(t.subtasks)) t.subtasks = [];
              if (typeof t.repeat === 'undefined') t.repeat = null;
            });
            data.memo.forEach(function (m) { if (m) m.pinned = !!m.pinned; });
            data._v = 3;
            break;
          case 3:
            /* v4：日记集合 + 回收站（软删） */
            data.diary = Array.isArray(data.diary) ? data.diary : [];
            data.trash = Array.isArray(data.trash) ? data.trash : [];
            data._v = 4;
            break;
          case 4:
            /* v5：小票集合（打印历史定格快照） */
            data.receipts = Array.isArray(data.receipts) ? data.receipts : [];
            data._v = 5;
            break;
          case 5:
            /* v6：删除墓碑（liveness log）——合并是并集，删除必须显式留痕 */
            data.deleted = Array.isArray(data.deleted) ? data.deleted : [];
            data._v = 6;
            break;
          case 6:
            /* v7：自定义事件类型集合（生日 / 纪念日之外的用户标签） */
            data.event_types = Array.isArray(data.event_types) ? data.event_types : [];
            data._v = 7;
            break;
          case 7:
            /* v8：一日三问配图（每篇最多 9 张，元素 {u,t}；未上云者为 data: 暂存） */
            (data.diary || []).forEach(function (d) { if (d) d.images = normDiaryImages(d.images); });
            data._v = 8;
            break;
        }
      }
      data.habits = Array.isArray(data.habits) ? data.habits : [];
      data.habit_log = Array.isArray(data.habit_log) ? data.habit_log : [];
      data.diary = Array.isArray(data.diary) ? data.diary : [];
      data.diary.forEach(function (d) { if (d) d.images = normDiaryImages(d.images); });
      data.trash = Array.isArray(data.trash) ? data.trash : [];
      data.receipts = Array.isArray(data.receipts) ? data.receipts : [];
      data.categories = Array.isArray(data.categories) ? data.categories : [];
      data.event_types = Array.isArray(data.event_types) ? data.event_types : [];
      data.todo = Array.isArray(data.todo) ? data.todo : [];
      data.memo = Array.isArray(data.memo) ? data.memo : [];
      data.special_date = Array.isArray(data.special_date) ? data.special_date : [];
      data.deleted = normDeleted(data.deleted);
      if (data._v < SCHEMA_VERSION) data._v = SCHEMA_VERSION;
      return data;
    },

    /* 序列化写入本地，并调度 MySQL 云端同步（skipRemote=true 时跳过）。
       IndexedDB 主存：异步落盘（内存态已同步更新，业务层无感）；
       运行期写入失败自动降级旧键值存储，仍失败则触发 onQuota 回调。
       旧键值存储降级模式：同步写入，失败抛 QuotaError（保持旧行为）。
       本地写入失败仍会上云（内存态有效），随后提示 UI */
    save: function (skipRemote) {
      var payload = JSON.stringify(this._data);
      if (storageMode === 'idb') {
        var self = this;
        idbSet(STORAGE_KEY, payload, function (ok) {
          if (ok) return;
          /* IDB 运行期写入失败：降级写旧键值存储 */
          idbBroken = true;
          storageMode = 'legacy';
          try {
            global.localStorage.setItem(STORAGE_KEY, payload);
          } catch (e) {
            if (typeof self.onQuota === 'function') self.onQuota();
          }
        });
      } else {
        try {
          global.localStorage.setItem(STORAGE_KEY, payload);
        } catch (e) {
          if (!skipRemote && this.CLOUD_ENABLED) this.REMOTE.schedule();
          throw new QuotaError('浏览器本地存储空间已满，本次操作未能保存');
        }
      }
      if (!skipRemote && this.CLOUD_ENABLED) this.REMOTE.schedule();
    },

    /* ---------------- MySQL 云端同步 ---------------- */
    REMOTE: {
      url: 'api/db.php',
      timer: null,
      failed: false,
      syncing: false,  /* pushMerged 拉取-合并-推送进行中 */
      pending: false,  /* 进行中又有新变更：结束后自动补一轮 */

      /* 400ms 防抖：合并连续变更（如批量导入、快速勾选）为一次推送 */
      schedule: function () {
        var self = this;
        if (!WorkbenchDB.CLOUD_ENABLED) return;
        if (self.timer) clearTimeout(self.timer);
        self.timer = setTimeout(function () {
          self.timer = null;
          self.pushMerged(null, function () {
            /* 推送失败：下次任意变更会自动携带全量重试 */
            if (!self.failed) {
              self.failed = true;
              if (typeof WorkbenchDB.onSync === 'function') WorkbenchDB.onSync('offline');
            }
          });
        }, 400);
      },

      /* 合并推送：先拉取云端 → mergeStates 收敛 → 写本地 → 再整体推送。
         杜绝多设备「后保存方整库覆盖先保存方」的数据丢失。
         离线或拉取失败时退回直接推送本地（不阻断），失败状态由 push 维护。 */
      pushMerged: function (onDone, onError) {
        var self = this;
        if (!WorkbenchDB.CLOUD_ENABLED) { if (onError) onError('local-mode'); return; }
        if (self.syncing) { self.pending = true; return; }
        self.syncing = true;
        var finish = function (ok, err) {
          self.syncing = false;
          if (self.pending) { self.pending = false; self.pushMerged(null, null); }
          if (ok) { if (onDone) onDone(); } else { if (onError) onError(err); }
        };
        self.pull(function (remote) {
          try {
            var local = WorkbenchDB._data || WorkbenchDB.seed();
            var merged = mergeStates(local, remote, false);
            WorkbenchDB._data = WorkbenchDB.migrate(merged);
            WorkbenchDB.save(true); /* 合并态先落本地（skipRemote），随后统一推送 */
          } catch (e) { /* 合并异常退回推送本地现状 */ }
          self.push(null, finish, finish);
        }, function () {
          /* 云端为空：直接推送本地 */
          self.push(null, finish, finish);
        }, function () {
          /* 拉取失败（离线/服务器错误）：退回直接推送本地，失败标记由 push 维护 */
          self.push(null, finish, finish);
        });
      },

      /* 立即推送（网络恢复 / 页面重新可见时调用）：失败静默，等待下次重试 */
      flush: function () {
        if (!WorkbenchDB.CLOUD_ENABLED || !WorkbenchDB._data) return;
        this.pushMerged(function () { /* 静默 */ }, function () { /* 静默：failed 标记已由 push 维护 */ });
      },

      push: function (state, onDone, onError) {
        var self = this;
        if (!WorkbenchDB.CLOUD_ENABLED) { if (onError) onError('local-mode'); return; }
        if (self.timer) { clearTimeout(self.timer); self.timer = null; }
        fetch(self.url + '?action=save', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(state == null ? WorkbenchDB._data : state)
        }).then(function (r) { return r.json(); }).then(function (res) {
          if (!res || res.ok !== true) throw new Error(res && res.error ? res.error : '保存失败');
          if (self.failed) {
            self.failed = false;
            if (typeof WorkbenchDB.onSync === 'function') WorkbenchDB.onSync('restored');
          }
          if (onDone) onDone(res);
        }).catch(function (err) {
          if (!self.failed) {
            self.failed = true;
            /* fetch 网络失败为 TypeError；其余（服务端返回错误/响应异常）不是网络问题 */
            var offline = err instanceof TypeError;
            if (typeof WorkbenchDB.onSync === 'function') WorkbenchDB.onSync(offline ? 'offline' : 'server-error');
          }
          if (onError) onError();
        });
      },

      pull: function (onData, onEmpty, onError) {
        if (!WorkbenchDB.CLOUD_ENABLED) { if (onError) onError('本地模式：数据仅保存在本机'); return; }
        fetch(this.url + '?action=state', { credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (!res || res.ok !== true) throw new Error(res && res.error ? res.error : '响应异常');
            if (res.empty) { if (onEmpty) onEmpty(res); return; }
            if (onData) onData(res.data);
          })
          .catch(function () { if (onError) onError(); });
      }
    },

    /* 清空本地存储并恢复种子数据（IndexedDB 与旧键值存储双清） */
    reset: function () {
      try {
        global.localStorage.removeItem(STORAGE_KEY);
      } catch (e) { /* 移除失败不阻断，随后覆盖写入 */ }
      idbDel(STORAGE_KEY);
      this._data = this.seed();
      this.save();
      return this._data;
    },

    /* 导出备份（深拷贝，避免外部篡改内存态） */
    exportData: function () {
      return JSON.parse(JSON.stringify(this._data));
    },

    /* 导入备份：结构校验 + 迁移 + 写入 */
    importData: function (raw) {
      var data = raw;
      if (typeof data === 'string') {
        try {
          data = JSON.parse(data);
        } catch (e) {
          throw new ValidationError('备份文件内容无法识别，请确认选择的是正确的备份文件');
        }
      }
      if (!isObj(data)) {
        throw new ValidationError('备份内容不是有效的数据对象');
      }
      if (!Array.isArray(data.todo) || !Array.isArray(data.memo) || !Array.isArray(data.special_date)) {
        throw new ValidationError('备份缺少 todo / memo / special_date 数据集合');
      }
      data = this.migrate(data);
      this._data = data;
      this.save();
      return this._data;
    },

    /* ---------------- MySQL 云端同步（对外接口） ---------------- */
    /* 采纳服务器下发的全量状态：校验/迁移 → 覆盖内存与本地缓存（不回推云端） */
    adoptRemote: function (state) {
      this._data = this.migrate(isObj(state) ? state : {});
      this.save(true);
      return this._data;
    },

    /* ================= 身份与本地数据文件（昵称命名） ================= */

    /* 当前身份快照：{ mode, nickname, slug, expiredFallback }
       mode：authed=登录态（MySQL 主存）/ local=本地模式 / legacy=老用户待补昵称 / fresh=首次访问 */
    detectIdentity: function () {
      if (AUTHED) return { mode: 'authed', nickname: LAST_USER, slug: '', expiredFallback: false };
      if (profile) return { mode: 'local', nickname: profile.nickname, slug: profile.slug, expiredFallback: expiredFallback };
      return {
        mode: LEGACY_MIGRATE_FROM ? 'legacy' : 'fresh',
        nickname: '',
        slug: '',
        legacyFrom: LEGACY_MIGRATE_FROM,
        expiredFallback: false
      };
    },

    /* 本地身份（可能为 null） */
    getProfile: function () { return profile ? { nickname: profile.nickname, slug: profile.slug, createdAt: profile.createdAt } : null; },

    /* 昵称占用检测：本机是否已存在同名数据键（设置页实时校验用）。
       查询范围 = IndexedDB 键缓存（load 时 getAllKeys 建立）∪ 旧键值存储 */
    nickConflict: function (nickname) {
      var slug = slugify(nickname);
      if (!slug) return true;
      if (STORAGE_KEY === dataKeyOf(slug)) return false; /* 迁移场景：来源键即自身 */
      return idbHasKey(dataKeyOf(slug)) || hasKeyData(dataKeyOf(slug));
    },

    /* 设置昵称并创建/迁移本地数据文件。
       legacyFrom：老用户升级时传入旧数据键，数据迁入昵称文件。
       返回 { profile, migrated }；昵称非法/占用抛 ValidationError */
    setupProfile: function (nickname, legacyFrom) {
      var slug = slugify(nickname);
      if (!slug) throw new ValidationError('昵称不能为空');
      if (slug.length > 20) throw new ValidationError('昵称不能超过 20 个字符');
      if (legacyFrom !== dataKeyOf(slug) && hasKeyData(dataKeyOf(slug))) {
        throw new ValidationError('这个昵称在本机已有同名档案，请换一个昵称');
      }
      profile = { nickname: slug, slug: slug, createdAt: new Date().toISOString() };
      try {
        global.localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
      } catch (e) {
        throw new QuotaError('浏览器本地存储空间已满，无法保存昵称');
      }
      var migrated = false;
      var from = legacyFrom || LEGACY_MIGRATE_FROM || '';
      function regKey(s) {
        var k = dataKeyOf(s);
        if (idbKeyCache && idbKeyCache.indexOf(k) === -1) idbKeyCache.push(k);
      }
      if (from && from !== dataKeyOf(slug)) {
        try {
          var raw = global.localStorage.getItem(from);
          if (raw) {
            var parsed = JSON.parse(raw);
            if (isObj(parsed)) {
              this._data = this.migrate(parsed);
              STORAGE_KEY = dataKeyOf(slug);
              this.save(true);
              regKey(slug);
              migrated = true;
            }
          }
        } catch (e) { /* 迁移失败按首次使用处理，不阻断 */ }
      }
      if (!migrated) {
        STORAGE_KEY = dataKeyOf(slug);
        this._data = this.seed();
        this.save(true);
        regKey(slug);
      }
      /* 收尾：清掉暂存键与迁移完成的旧键 */
      try {
        global.localStorage.removeItem(PENDING_KEY);
        if (migrated && from) global.localStorage.removeItem(from);
      } catch (e) { /* 忽略 */ }
      return { profile: this.getProfile(), migrated: migrated };
    },

    /* ================= 登录态 ↔ 本地态数据衔接 ================= */

    /* 登录初始化合并：本地镜像（含昵称文件数据）与云端状态按集合并集、
       条目按更新时间新者优先。合并结果写入本地并调度上云（云端收敛到合并态）。
       纯新设备场景（本地无数据）等价于采纳云端。 */
    mergeRemote: function (remote) {
      var local = this._data || this.seed();
      var r;
      try {
        r = isObj(remote) ? JSON.parse(JSON.stringify(remote)) : {};
      } catch (e) {
        return null;
      }
      this._data = this.migrate(mergeStates(local, r, true));
      this.save(); /* 合并态上云，两端收敛 */
      return this._data;
    },

    /* 登录初始化前调用：把本地模式（昵称档案）积累的数据并入当前登录键的工作副本，
       使随后与云端的合并包含本地模式的全部变更。数据源：IndexedDB（主），
       IDB 无值或不可用时回退旧键值存储。完成回调 onDone(merged)。 */
    adoptLocalProfileData: function (onDone) {
      var self = this;
      function noData() { if (onDone) onDone(false); }
      if (!AUTHED || !profile || !self._data) { noData(); return; }
      var key = dataKeyOf(profile.slug);
      idbGet(key, function (val, unavailable) {
        var raw = null;
        if (!unavailable && typeof val === 'string' && val.length > 2) {
          raw = val;
        } else {
          try { raw = global.localStorage.getItem(key); } catch (e) { /* 忽略 */ }
        }
        if (!raw) { noData(); return; }
        var pd = null;
        try { pd = JSON.parse(raw); } catch (e) { noData(); return; }
        if (!isObj(pd)) { noData(); return; }
        /* 工作副本为种子（登录键为空）且昵称档案有数据：整体采纳 */
        var cur = self._data;
        var curEmpty = !cur.todo.length && !cur.memo.length && !cur.special_date.length && !cur.habits.length && !cur.diary.length && !cur.receipts.length && !cur.trash.length && !cur.categories.length && !cur.event_types.length && !cur.habit_log.length;
        var pEmpty = !(pd.todo || []).length && !(pd.memo || []).length && !(pd.special_date || []).length && !(pd.habits || []).length && !(pd.diary || []).length && !(pd.receipts || []).length && !(pd.trash || []).length && !(pd.categories || []).length && !(pd.event_types || []).length && !(pd.habit_log || []).length;
        if (pEmpty) { noData(); return; }
        if (curEmpty) {
          self._data = self.migrate(pd);
        } else {
          self._data = self.migrate(mergeStates(cur, pd, false));
        }
        self.save(true); /* 暂不上云：随后 pullRemote 的合并会统一收敛上云 */
        if (onDone) onDone(true);
      });
    },

    /* 退出登录前：把当前登录态数据快照到昵称数据档案，本地模式无缝接管。
       写入 IndexedDB（主）与旧键值存储（降级回退），完成回调 onDone(ok)。 */
    snapshotForLogout: function (onDone) {
      var self = this;
      function finish(ok) { if (onDone) onDone(ok); }
      if (!this.CLOUD_ENABLED || !this._data) { finish(false); return; }
      var p = profile;
      if (!p) { finish(false); return; }
      var payload = JSON.stringify(this._data);
      var key = dataKeyOf(p.slug);
      if (storageMode === 'idb') {
        idbSet(key, payload, function (ok) {
          if (ok) { if (idbKeyCache && idbKeyCache.indexOf(key) === -1) idbKeyCache.push(key); finish(true); return; }
          /* IDB 写失败：回退旧键值存储 */
          try { global.localStorage.setItem(key, payload); finish(true); } catch (e) { finish(false); }
        });
        return;
      }
      try {
        global.localStorage.setItem(key, payload);
        finish(true);
      } catch (e) { finish(false); }
    },

    /* 拉取云端状态：onData(有数据) / onEmpty(服务器为空) / onError(失败) */
    pullRemote: function (onData, onEmpty, onError) {
      this.REMOTE.pull(onData, onEmpty, onError);
    },
    /* 推送状态上云（缺省推送当前内存态） */
    pushRemote: function (state, onDone, onError) {
      this.REMOTE.push(state, onDone, onError);
    },

    /* ---------------- 通用查找 ---------------- */
    _find: function (list, id) {
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].id === id) return list[i];
      }
      return null;
    },

    /* ---------------- 单项读取（编辑场景取原始引用） ---------------- */
    getTodo: function (id) { return this._find(this._data.todo, id); },
    getMemo: function (id) { return this._find(this._data.memo, id); },
    getSpecial: function (id) { return this._find(this._data.special_date, id); },

    /* ---------------- 回收站（软删除） ---------------- */
    /* 写一条存活记录：gone=true 已删 / gone=false 已恢复。
       type 用「集合名」（todo/memo/special_date/diary/habits/categories/receipts/trash），
       与 mergeStates 的过滤键一致；同键就地更新时间戳，日志不膨胀。 */
    _markDead: function (type, id, gone) {
      if (!this._data || id == null) return;
      var list = Array.isArray(this._data.deleted) ? this._data.deleted : (this._data.deleted = []);
      var at = new Date().toISOString(), i;
      for (i = 0; i < list.length; i++) {
        if (list[i] && list[i].type === type && String(list[i].id) === String(id)) {
          list[i].at = at;
          list[i].gone = gone !== false;
          return;
        }
      }
      list.push({ id: String(id), type: type, at: at, gone: gone !== false });
    },

    /* 统一入口：从集合移除并写入回收站；extra 供恢复时附带（如习惯的打卡记录） */
    _softDelete: function (type, id, extra) {
      var lists = {
        todo: 'todo', memo: 'memo', special_date: 'special_date',
        habit: 'habits', diary: 'diary'
      };
      var key = lists[type];
      if (!key) return false;
      var list = this._data[key];
      for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (it && it.id === id) {
          list.splice(i, 1);
          this._markDead(key, id, true); /* 墓碑：合并是并集，不留痕就会被云端并回来 */
          this._data.trash.unshift({
            id: nextId('tr'),
            type: type,
            item: it,
            extra: extra || null,
            deletedAt: new Date().toISOString()
          });
          if (this._data.trash.length > TRASH_MAX) this._data.trash.length = TRASH_MAX;
          return true;
        }
      }
      return false;
    },

    listTrash: function () {
      return this._data.trash.slice();
    },

    /* 从回收站恢复：按类型放回原集合（保留原 id / createdAt） */
    restoreTrash: function (id) {
      var trash = this._data.trash;
      for (var i = 0; i < trash.length; i++) {
        var e = trash[i];
        if (!e || e.id !== id) continue;
        var map = {
          todo: 'todo', memo: 'memo', special_date: 'special_date',
          habit: 'habits', diary: 'diary'
        };
        var key = map[e.type];
        if (!key || !e.item) return false;
        this._data[key].unshift(e.item);
        if (e.type === 'habit' && Array.isArray(e.extra) && e.extra.length) {
          var hid = e.item.id;
          e.extra.forEach(function (l) {
            if (!l || !l.d) return;
            var prev = null;
            this._data.habit_log.forEach(function (x) {
              if (x && x.h === hid && x.d === l.d) prev = x;
            });
            /* 同日已有记录（删除后又在别处打过卡）：次数取大者，并刷新写入时刻 */
            if (prev) {
              var back = normTimes(l.n);
              if (back > normTimes(prev.n)) { prev.n = back; prev.updatedAt = new Date().toISOString(); }
              return;
            }
            this._data.habit_log.push(l);
          }, this);
        }
        trash.splice(i, 1);
        /* 条目撤销墓碑（恢复），但这条回收站记录是「用掉了」——必须留删除痕，
           否则云端的同一行会被并回来，恢复后回收站里又冒出一条 */
        this._markDead(key, e.item.id, false);
        this._markDead('trash', id, true);
        this.save();
        return true;
      }
      return false;
    },

    /* 彻底删除单条 */
    purgeTrash: function (id) {
      var trash = this._data.trash;
      for (var i = 0; i < trash.length; i++) {
        if (trash[i] && trash[i].id === id) {
          trash.splice(i, 1);
          this._markDead('trash', id, true);
          this.save();
          return true;
        }
      }
      return false;
    },

    /* 清空回收站 */
    emptyTrash: function () {
      var n = this._data.trash.length;
      var self = this;
      this._data.trash.forEach(function (e) { if (e && e.id != null) self._markDead('trash', e.id, true); });
      this._data.trash = [];
      this.save();
      return n;
    },

    /* 30 天懒清理：打开页面时调用，过期条目自动清除 */
    trashGC: function () {
      var keep = TRASH_KEEP_DAYS;
      var limit = Date.now() - keep * 86400000;
      var before = this._data.trash.length;
      var self = this;
      this._data.trash = this._data.trash.filter(function (e) {
        var t = Date.parse(e && e.deletedAt ? e.deletedAt : '');
        var expired = isNaN(t) || t < limit;
        /* 过期即彻底删除：同样要留痕，否则云端旧副本会把它并回来，GC 永远清不净 */
        if (expired && e && e.id != null) self._markDead('trash', e.id, true);
        return !expired;
      });
      if (this._data.trash.length !== before) this.save();
      return before - this._data.trash.length;
    },

    /* ---------------- 日记 / 每日回顾 ---------------- */
    listDiary: function () {
      return this._data.diary.slice().sort(function (a, b) {
        return String(b.date).localeCompare(String(a.date));
      });
    },

    getDiaryByDate: function (date) {
      return this._data.diary.find(function (d) { return d.date === date; }) || null;
    },

    /* 连续记录天数：今天已写从今天回数，否则从昨天回数（与习惯 streak 同策略） */
    diaryStreak: function () {
      var done = function (d) { return !!this.getDiaryByDate(d); }.bind(this);
      var now = new Date();
      var day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      if (!done(toDateStr(day))) day.setDate(day.getDate() - 1);
      var n = 0;
      while (done(toDateStr(day))) {
        n++;
        day.setDate(day.getDate() - 1);
      }
      return n;
    },

    /* 保存（按日期 upsert：同日一篇） */
    saveDiary: function (input) {
      input = input || {};
      var date = normDate(input.date);
      if (!date) throw new ValidationError('请填写有效的日期（YYYY-MM-DD）');
      var moods = ['great', 'good', 'ok', 'low', 'bad'];
      var mood = moods.indexOf(input.mood) !== -1 ? input.mood : 'ok';
      var existing = this.getDiaryByDate(date);
      var now = new Date().toISOString();
      /* 配图只在调用方显式传入时改写（未传 = 本次编辑没碰图片）；
         摘掉的云端图片顺手回收服务器文件，data: 暂存的直接本机丢弃 */
      var imgs = null;
      if (typeof input.images !== 'undefined') {
        imgs = normDiaryImages(input.images);
      }
      /* 仍有未上云的暂存图时，本轮只落本地：等 IMAGES.flush 收尾再推送，
         否则全量推送会带上几百 KB×N 的 base64（撞上传上限、且必然重传） */
      var holdPush = function (list) {
        return AUTHED && !!IMAGES.hasLocal(list);
      };
      if (existing) {
        existing.mood = mood;
        existing.what = str(input.what).slice(0, 2000);
        existing.gain = str(input.gain).slice(0, 2000);
        existing.plan = str(input.plan).slice(0, 2000);
        if (imgs) {
          IMAGES.recycleRemoved(existing.images || [], imgs);
          existing.images = imgs;
        }
        existing.updatedAt = now;
        this.save(holdPush(existing.images));
        return existing;
      }
      var item = {
        id: nextId('dy'),
        date: date,
        mood: mood,
        what: str(input.what).slice(0, 2000),
        gain: str(input.gain).slice(0, 2000),
        plan: str(input.plan).slice(0, 2000),
        images: imgs || [],
        createdAt: now,
        updatedAt: now
      };
      this._data.diary.push(item);
      this.save(holdPush(item.images));
      return item;
    },

    deleteDiary: function (id) {
      var ok = this._softDelete('diary', id);
      if (ok) this.save();
      return ok;
    },

    /* ---------------- 待办 todo ---------------- */
    addTodo: function (input) {
      input = input || {};
      var title = str(input.title).trim();
      if (!title) throw new ValidationError('待办标题不能为空');
      var item = {
        id: nextId('t'),
        title: title.slice(0, 200),
        desc: str(input.desc).trim().slice(0, 2000),
        done: false,
        priority: normPriority(input.priority),
        category: normCategoryId(input.category),
        due: normDate(input.due),
        subtasks: normSubtasks(input.subtasks),
        repeat: normRepeat(input.repeat),
        createdAt: new Date().toISOString(),
        doneAt: ''
      };
      this._data.todo.unshift(item);
      this.save();
      return item;
    },

    updateTodo: function (id, patch) {
      var item = this._find(this._data.todo, id);
      if (!item) throw new ValidationError('待办不存在或已被删除');
      patch = patch || {};
      if ('title' in patch) {
        var title = str(patch.title).trim();
        if (!title) throw new ValidationError('待办标题不能为空');
        item.title = title.slice(0, 200);
      }
      if ('desc' in patch) item.desc = str(patch.desc).trim().slice(0, 2000);
      if ('priority' in patch) item.priority = normPriority(patch.priority);
      if ('category' in patch) item.category = normCategoryId(patch.category);
      if ('due' in patch) item.due = normDate(patch.due);
      if ('repeat' in patch) item.repeat = normRepeat(patch.repeat);
      /* 编辑即打时间戳：合并冲突以真实修改时间判定（云端持久化 updated_at） */
      if (['title', 'desc', 'priority', 'category', 'due', 'subtasks', 'repeat', 'done'].some(function (k) { return k in patch; })) {
        item.updatedAt = new Date().toISOString();
      }

      var self = this;
      /* 统一完成态落地：时间戳、完成级联子待办、重复任务生成下一次副本 */
      function setDone(nd) {
        if (nd === !!item.done) return;
        item.done = nd;
        /* 记录完成 / 重新打开的时刻，供趋势图与最近活动统计 */
        item.doneAt = nd ? new Date().toISOString() : '';
        if (nd) {
          /* 勾选父待办：一键完成所有子待办 */
          (item.subtasks || []).forEach(function (s) { s.done = true; });
          /* 重复任务：完成即生成下一次副本（取消完成不回滚副本） */
          if (item.repeat) {
            var nextDue = nextRepeatDate(item.due, item.repeat);
            if (nextDue) {
              self._data.todo.unshift({
                id: nextId('t'),
                title: item.title,
                desc: item.desc,
                done: false,
                priority: item.priority,
                category: item.category,
                due: nextDue,
                subtasks: (item.subtasks || []).map(function (s) {
                  return { id: nextId('s'), title: s.title, done: false };
                }),
                repeat: item.repeat,
                createdAt: new Date().toISOString(),
                doneAt: ''
              });
            }
          }
        }
      }

      var subsPatch = 'subtasks' in patch;
      var doneOnlyToggle = false;
      if (subsPatch) {
        var oldSubs = item.subtasks || [];
        var newSubs = normSubtasks(patch.subtasks);
        /* 仅勾选状态变化（id/标题集合不变）才允许反向重开父待办，
           表单里增删改子任务等结构性变化不触发误重开 */
        doneOnlyToggle = oldSubs.length > 0 && oldSubs.length === newSubs.length &&
          oldSubs.every(function (s, i) { var n = newSubs[i]; return !!n && s.id === n.id && s.title === n.title; }) &&
          newSubs.some(function (n, i) { return !!n.done !== !!oldSubs[i].done; });
        item.subtasks = newSubs;
      }

      if ('done' in patch) {
        var want = !!patch.done;
        if (want !== !!item.done) {
          if (want) {
            /* 记录勾选父待办前子任务的完成态，取消完成时精确回滚 */
            item._subSnap = (item.subtasks || []).map(function (s) { return !!s.done; });
            setDone(true);
          } else if (Array.isArray(item._subSnap)) {
            setDone(false);
            var snap = item._subSnap;
            delete item._subSnap;
            (item.subtasks || []).forEach(function (s, i) { if (i < snap.length) s.done = !!snap[i]; });
          } else {
            /* 子任务是用户手动逐一勾选的真实状态，取消父完成仅改父，不动子、不伪造快照 */
            setDone(false);
          }
        }
      } else if (subsPatch && item.subtasks.length) {
        var allDone = item.subtasks.every(function (s) { return s.done; });
        if (allDone && !item.done) {
          /* 撤销完成产生的全勾快照失效：此刻起子任务勾选由用户手动管理 */
          delete item._subSnap;
          setDone(true);        /* 子待办全部完成 → 自动完成父 */
        } else if (doneOnlyToggle && !allDone && item.done) {
          delete item._subSnap; /* 手动改动子任务使快照失效 */
          setDone(false);       /* 取消某个子待办 → 父自动回到未完成 */
        }
      }
      this.save();
      return item;
    },

    deleteTodo: function (id) {
      var ok = this._softDelete('todo', id);
      if (ok) this.save();
      return ok;
    },

    /* ---------------- 归档（左滑快捷操作） ----------------
       归档 ≠ 删除：archived 标记使其脱离列表与统计，数据保留、可随时恢复 */
    archiveTodo: function (id) {
      var item = this._find(this._data.todo, id);
      if (!item) throw new ValidationError('待办不存在或已被删除');
      item.archived = true;
      item.archivedAt = new Date().toISOString();
      this.save();
      return item;
    },

    unarchiveTodo: function (id) {
      var item = this._find(this._data.todo, id);
      if (!item) throw new ValidationError('待办不存在或已被删除');
      delete item.archived;
      delete item.archivedAt;
      this.save();
      return item;
    },

    listArchived: function () {
      return this._data.todo
        .filter(function (t) { return !!t.archived; })
        .sort(function (a, b) { return String(b.archivedAt || '').localeCompare(String(a.archivedAt || '')); })
        .map(function (t) {
          var copy = {};
          for (var k in t) if (Object.prototype.hasOwnProperty.call(t, k)) copy[k] = t[k];
          return copy;
        });
    },

    /* 列表（filter: all | open | done），排序：未完成在前 → 截止近的在前 → 优先级高在前 → 新建在前 */
    listTodos: function (filter) {
      var list = this._data.todo.filter(function (t) { return !t.archived; });
      if (filter === 'open') list = list.filter(function (t) { return !t.done; });
      else if (filter === 'done') list = list.filter(function (t) { return !!t.done; });
      var pri = { high: 0, normal: 1, low: 2 };
      var today = toDateStr(new Date());
      list.sort(function (a, b) {
        if (!!a.done !== !!b.done) return a.done ? 1 : -1;
        var da = a.due || '9999-99-99', db = b.due || '9999-99-99';
        if (da !== db) return da < db ? -1 : 1;
        var pa = pri[a.priority] || 1, pb = pri[b.priority] || 1;
        if (pa !== pb) return pa - pb;
        return String(b.createdAt).localeCompare(String(a.createdAt));
      });
      /* 过期标记：仅写在返回副本上，绝不污染持久化/云端原始对象 */
      return list.map(function (t) {
        var copy = {};
        for (var k in t) if (Object.prototype.hasOwnProperty.call(t, k)) copy[k] = t[k];
        copy.overdue = !t.done && !!t.due && t.due < today;
        return copy;
      });
    },

    /* ---------------- 待办分类 category ---------------- */
    listCategories: function () {
      return this._data.categories.slice();
    },

    getCategory: function (id) {
      return this._find(this._data.categories, id);
    },

    addCategory: function (input) {
      input = input || {};
      var name = normCatName(input.name);
      if (!name) throw new ValidationError('分类名称不能为空');
      var item = {
        id: nextId('c'),
        name: name,
        color: normColor(input.color)
      };
      this._data.categories.push(item);
      this.save();
      return item;
    },

    updateCategory: function (id, patch) {
      var item = this._find(this._data.categories, id);
      if (!item) throw new ValidationError('分类不存在');
      patch = patch || {};
      if ('name' in patch) {
        var name = normCatName(patch.name);
        if (!name) throw new ValidationError('分类名称不能为空');
        item.name = name;
      }
      if ('color' in patch) item.color = normColor(patch.color);
      this.save();
      return item;
    },

    /* 删除分类；其下待办一并移回「未分类」 */
    removeCategory: function (id) {
      var list = this._data.categories;
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].id === id) {
          list.splice(i, 1);
          this._markDead('categories', id, true);
          var now = new Date().toISOString();
          this._data.todo.forEach(function (t) {
            if (t && t.category === id) {
              t.category = '';
              t.updatedAt = now; /* 解除引用也要刷新时间戳，否则合并时会被对端的旧值反吞 */
            }
          });
          this.save();
          return true;
        }
      }
      return false;
    },

    /* ---------------- 自定义事件类型 event_types ---------------- */
    listEventTypes: function () {
      return this._data.event_types.slice();
    },

    getEventType: function (id) {
      return this._find(this._data.event_types, id);
    },

    addEventType: function (input) {
      input = input || {};
      var name = normCatName(input.name);
      if (!name) throw new ValidationError('类型名称不能为空');
      var now = new Date().toISOString();
      var item = {
        id: nextId('e'),
        name: name,
        color: normColor(input.color),
        createdAt: now,
        updatedAt: now
      };
      this._data.event_types.push(item);
      this.save();
      return item;
    },

    updateEventType: function (id, patch) {
      var item = this._find(this._data.event_types, id);
      if (!item) throw new ValidationError('类型不存在');
      patch = patch || {};
      if ('name' in patch) {
        var name = normCatName(patch.name);
        if (!name) throw new ValidationError('类型名称不能为空');
        item.name = name;
      }
      if ('color' in patch) item.color = normColor(patch.color);
      if (['name', 'color'].some(function (k) { return k in patch; })) {
        item.updatedAt = new Date().toISOString();
      }
      this.save();
      return item;
    },

    /* 删除自定义类型；使用它的事件不改类型，渲染时回落为中性「自定义事件」 */
    removeEventType: function (id) {
      var list = this._data.event_types;
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].id === id) {
          list.splice(i, 1);
          this._markDead('event_types', id, true);
          this.save();
          return true;
        }
      }
      return false;
    },

    /* 各类型下的事件数量（供筛选弹窗计数与删除确认提示） */
    countByEventType: function () {
      var map = {};
      this._data.special_date.forEach(function (d) {
        if (!d || d.archived) return;
        var t = d.type;
        if (t === 'birthday' || t === 'anniversary') return;
        map[t] = (map[t] || 0) + 1;
      });
      return map;
    },

    /* ---------------- 备忘 memo ---------------- */
    addMemo: function (input) {
      input = input || {};
      var title = str(input.title).trim();
      if (!title) throw new ValidationError('备忘标题不能为空');
      var now = new Date().toISOString();
      var item = {
        id: nextId('m'),
        title: title.slice(0, 200),
        content: str(input.content).slice(0, 20000),
        tags: normTags(input.tags),
        pinned: !!input.pinned,
        createdAt: now,
        updatedAt: now
      };
      this._data.memo.unshift(item);
      this.save();
      return item;
    },

    updateMemo: function (id, patch) {
      var item = this._find(this._data.memo, id);
      if (!item) throw new ValidationError('备忘不存在或已被删除');
      patch = patch || {};
      if ('title' in patch) {
        var title = str(patch.title).trim();
        if (!title) throw new ValidationError('备忘标题不能为空');
        item.title = title.slice(0, 200);
      }
      if ('content' in patch) item.content = str(patch.content).slice(0, 20000);
      if ('tags' in patch) item.tags = normTags(patch.tags);
      if ('pinned' in patch) item.pinned = !!patch.pinned;
      item.updatedAt = new Date().toISOString();
      this.save();
      return item;
    },

    toggleMemoPin: function (id) {
      var item = this._find(this._data.memo, id);
      if (!item) throw new ValidationError('备忘不存在或已被删除');
      item.pinned = !item.pinned;
      item.updatedAt = new Date().toISOString();
      this.save();
      return item;
    },

    deleteMemo: function (id) {
      var ok = this._softDelete('memo', id);
      if (ok) this.save();
      return ok;
    },

    /* 列表：置顶优先 → 更新时间倒序 */
    listMemos: function () {
      return this._data.memo.slice().sort(function (a, b) {
        if (!!a.pinned !== !!b.pinned) return a.pinned ? -1 : 1;
        return String(b.updatedAt).localeCompare(String(a.updatedAt));
      });
    },

    /* 全部标签及计数（按数量降序） */
    memoTags: function () {
      var map = {};
      this._data.memo.forEach(function (m) {
        (m.tags || []).forEach(function (t) {
          map[t] = (map[t] || 0) + 1;
        });
      });
      return Object.keys(map)
        .map(function (t) { return { name: t, count: map[t] }; })
        .sort(function (a, b) { return b.count - a.count || a.name.localeCompare(b.name, 'zh'); });
    },

    /* 标签重命名；目标名已存在时自动合并（去重） */
    renameTag: function (from, to) {
      from = str(from).trim();
      to = str(to).trim();
      if (!from || !to) throw new ValidationError('标签名不能为空');
      if (from === to) return;
      this._data.memo.forEach(function (m) {
        var tags = m.tags || [];
        var i = tags.indexOf(from);
        if (i === -1) return;
        tags.splice(i, 1);
        if (tags.indexOf(to) === -1) tags.push(to);
        m.tags = tags;
      });
      this.save();
    },

    /* 删除标签：从所有备忘移除 */
    deleteTag: function (name) {
      name = str(name).trim();
      if (!name) return;
      this._data.memo.forEach(function (m) {
        var tags = m.tags || [];
        var i = tags.indexOf(name);
        if (i !== -1) { tags.splice(i, 1); m.tags = tags; }
      });
      this.save();
    },

    /* ---------------- 习惯打卡 habit ---------------- */
    listHabits: function () {
      return this._data.habits.slice();
    },

    getHabit: function (id) { return this._find(this._data.habits, id); },

    addHabit: function (input) {
      input = input || {};
      var name = str(input.name).trim().slice(0, 20);
      if (!name) throw new ValidationError('习惯名称不能为空');
      var item = {
        id: nextId('h'),
        name: name,
        color: normColor(input.color) === '#888780' ? '#378ADD' : normColor(input.color),
        createdAt: new Date().toISOString()
      };
      this._data.habits.push(item);
      this.save();
      return item;
    },

    updateHabit: function (id, patch) {
      var item = this._find(this._data.habits, id);
      if (!item) throw new ValidationError('习惯不存在');
      patch = patch || {};
      if ('name' in patch) {
        var name = str(patch.name).trim().slice(0, 20);
        if (!name) throw new ValidationError('习惯名称不能为空');
        item.name = name;
      }
      if ('color' in patch) item.color = normColor(patch.color);
      this.save();
      return item;
    },

    /* 删除习惯（软删，打卡记录随恢复一并还原） */
    removeHabit: function (id) {
      var logs = this._data.habit_log.filter(function (l) { return l.h === id; });
      var ok = this._softDelete('habit', id, logs);
      if (ok) {
        this._data.habit_log = this._data.habit_log.filter(function (l) { return l.h !== id; });
        this.save();
      }
      return ok;
    },

    /* ---- 打卡记录行：同一 (习惯, 日期) 只存一行，行内 n = 当日打卡次数 ---- */
    _habitLog: function (id, date) {
      var logs = this._data.habit_log;
      for (var i = 0; i < logs.length; i++) {
        if (logs[i] && logs[i].h === id && logs[i].d === date) return logs[i];
      }
      return null;
    },

    /* 指定习惯某日打卡次数（旧数据无 n 字段 ⇒ 按 1 次计） */
    habitCount: function (id, date) {
      var l = this._habitLog(id, date);
      return l ? normTimes(l.n) : 0;
    },

    /* 某习惯的「日期 → 次数」表：热力图整月/整年按表取数，不逐日扫日志。
       n=0 的墓碑行不写进表（取不到即为 0），保持与旧行为一致 */
    habitCountMap: function (id) {
      var map = {}, logs = this._data.habit_log;
      for (var i = 0; i < logs.length; i++) {
        var l = logs[i];
        if (!l || !l.d || (id != null && l.h !== id)) continue;
        var n = normTimes(l.n);
        if (n > 0) map[l.d] = n;
      }
      return map;
    },

    /* 指定习惯某日是否已打卡（次数 > 0） */
    isHabitDone: function (id, date) {
      return this.habitCount(id, date) > 0;
    },

    /* 打卡一次（单日可累计多次），返回打卡后的次数 */
    checkInHabit: function (id, date) {
      var stamp = new Date().toISOString();
      var l = this._habitLog(id, date);
      if (l) { l.n = normTimes(l.n) + 1; l.updatedAt = stamp; }
      else this._data.habit_log.push({ h: id, d: date, n: 1, updatedAt: stamp });
      this.save();
      return this.habitCount(id, date);
    },

    /* 撤销一次打卡，返回剩余次数。
       归零时【不删行】，留一条 n=0 的墓碑：云端同步是「拉取 → 并集合并 → 推送」，
       删掉的行会被云端那一份原样并回来，表现就是「取消后数据回弹」；
       只有带着更新的 updatedAt 写一条 0 次，这次取消才能在合并里胜出 */
    undoCheckIn: function (id, date) {
      var l = this._habitLog(id, date);
      if (!l) return 0;
      var left = normTimes(l.n) - 1;
      if (left < 0) left = 0;
      l.n = left;
      l.updatedAt = new Date().toISOString();
      this.save();
      return left;
    },

    /* 兼容旧调用点：未打卡则打一次，已打卡则减一次；返回操作后是否仍处于已打卡 */
    toggleHabit: function (id, date) {
      if (this.isHabitDone(id, date)) return this.undoCheckIn(id, date) > 0;
      this.checkInHabit(id, date);
      return true;
    },

    /* 连续打卡天数：今天已打则从今天回数；否则从昨天回数（今天未打不断连击） */
    habitStreak: function (id) {
      var done = function (d) { return this.isHabitDone(id, d); }.bind(this);
      var now = new Date();
      var day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      if (!done(toDateStr(day))) day.setDate(day.getDate() - 1);
      var n = 0;
      while (done(toDateStr(day))) {
        n++;
        day.setDate(day.getDate() - 1);
      }
      return n;
    },

    /* 本月完成率：已打卡天数 / 截至今天的自然日数 */
    habitMonthRate: function (id) {
      var now = new Date();
      var y = now.getFullYear(), m = now.getMonth();
      var elapsed = now.getDate();
      var done = 0;
      for (var d = 1; d <= elapsed; d++) {
        var key = y + '-' + this._pad(m + 1) + '-' + this._pad(d);
        if (this.isHabitDone(id, key)) done++;
      }
      return elapsed ? Math.round(done / elapsed * 100) : 0;
    },

    _pad: function (n) { return (n < 10 ? '0' : '') + n; },

    /* ---------------- 纪念日 / 生日 special_date ---------------- */
    addSpecial: function (input) {
      input = input || {};
      var name = str(input.name).trim();
      if (!name) throw new ValidationError('事件名称不能为空');
      var date = normDate(input.date);
      if (!date) throw new ValidationError('请填写有效的日期（YYYY-MM-DD）');
      var item = {
        id: nextId('d'),
        name: name.slice(0, 100),
        type: normType(input.type),
        date: date,
        repeat: !!input.repeat,
        lunar: !!input.lunar,
        showSince: !!input.showSince,
        note: str(input.note).trim().slice(0, 500),
        createdAt: new Date().toISOString()
      };
      this._data.special_date.unshift(item);
      this.save();
      return item;
    },

    updateSpecial: function (id, patch) {
      var item = this._find(this._data.special_date, id);
      if (!item) throw new ValidationError('事件不存在或已被删除');
      patch = patch || {};
      if ('name' in patch) {
        var name = str(patch.name).trim();
        if (!name) throw new ValidationError('事件名称不能为空');
        item.name = name.slice(0, 100);
      }
      if ('type' in patch) item.type = normType(patch.type);
      if ('date' in patch) {
        var date = normDate(patch.date);
        if (!date) throw new ValidationError('请填写有效的日期（YYYY-MM-DD）');
        item.date = date;
      }
      if ('repeat' in patch) item.repeat = !!patch.repeat;
      if ('lunar' in patch) item.lunar = !!patch.lunar;
      if ('showSince' in patch) item.showSince = !!patch.showSince;
      if ('note' in patch) item.note = str(patch.note).trim().slice(0, 500);
      if (['name', 'type', 'date', 'repeat', 'lunar', 'showSince', 'note'].some(function (k) { return k in patch; })) {
        item.updatedAt = new Date().toISOString();
      }
      this.save();
      return item;
    },

    deleteSpecial: function (id) {
      var ok = this._softDelete('special_date', id);
      if (ok) this.save();
      return ok;
    },

    /* ---------------- 小票（打印历史，定格快照） ---------------- */
    saveReceipt: function (rec) {
      if (!rec || typeof rec.id !== 'string' || !rec.id) return null;
      rec = Object.assign({}, rec);
      rec.createdAt = rec.createdAt || new Date().toISOString();
      var list = this._data.receipts;
      for (var i = 0; i < list.length; i++) {
        if (list[i] && list[i].id === rec.id) { list[i] = rec; this.save(); return rec; }
      }
      list.unshift(rec);
      /* 长期保存兜底：上限只防病态膨胀，非功能限制（每日打 3 张也够存 5 年以上）。
         合并侧 mergeStates 对 receipts 无截断，历史小票不会被同步回合悄悄吃掉。 */
      if (list.length > 2000) list.length = 2000;
      this.save();
      return rec;
    },
    listReceipts: function () {
      return this._data.receipts.slice().sort(function (a, b) {
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      });
    },
    getReceipt: function (id) {
      return this._data.receipts.find(function (r) { return r && r.id === id; }) || null;
    },
    deleteReceipt: function (id) {
      var before = this._data.receipts.length;
      this._data.receipts = this._data.receipts.filter(function (r) { return r && r.id !== id; });
      var changed = this._data.receipts.length !== before;
      if (changed) { this._markDead('receipts', id, true); this.save(); }
      return changed;
    },

    /* 列表（附倒计时计算）：
       排序：未来事件按剩余天数升序 → 已过期的一次性事件沉底（按日期倒序） */
    listSpecial: function () {
      var items = this._data.special_date.map(function (ev) {
        var next = nextOccur(ev);
        var days = daysFromToday(next);
        var d0 = daysFromToday(ev.date);
        return Object.assign({}, ev, {
          nextDate: next, days: days,
          since: (d0 !== null && d0 <= 0) ? -d0 : null /* 起始日距今已过天数；未来日期为 null */
        });
      });
      items.sort(function (a, b) {
        var aFuture = a.days !== null && a.days >= 0;
        var bFuture = b.days !== null && b.days >= 0;
        if (aFuture !== bFuture) return aFuture ? -1 : 1;
        if (a.days !== b.days) return a.days - b.days;
        return String(b.createdAt).localeCompare(String(a.createdAt));
      });
      return items;
    },

    /* 获取临近事件（未来 daysWithin 天内，含今天） */
    upcoming: function (daysWithin) {
      return this.listSpecial().filter(function (ev) {
        return ev.days !== null && ev.days >= 0 && ev.days <= daysWithin;
      });
    },

    /* 本地存储方式标签（个人中心显示用） */
    storageLabel: function () {
      return storageMode === 'idb' ? 'IndexedDB（大容量）' : '浏览器标准存储';
    }
  };

  /* ---------------- 导出 ---------------- */
  global.WorkbenchDB = WorkbenchDB;
  global.DBErrors = {
    DBError: DBError,
    CorruptError: CorruptError,
    QuotaError: QuotaError,
    ValidationError: ValidationError
  };

  /* 网络恢复 / 页面重新可见时主动回同步：把离线期间的本地变更推上云（登录态） */
  global.addEventListener('online', function () {
    var db = global.WorkbenchDB;
    if (db && db.CLOUD_ENABLED && db.REMOTE.failed) db.REMOTE.flush();
  });
  document.addEventListener('visibilitychange', function () {
    var db = global.WorkbenchDB;
    if (db && db.CLOUD_ENABLED && db.REMOTE.failed && document.visibilityState === 'visible') db.REMOTE.flush();
  });
  /* 兜底心跳：防抖失败后若用户不再操作，也能在 45s 内自动回同步 */
  setInterval(function () {
    var db = global.WorkbenchDB;
    if (db && db.CLOUD_ENABLED && db.REMOTE.failed) db.REMOTE.flush();
  }, 45000);

  /* 页面关闭前：存在待同步变更时用 sendBeacon 兜底推送，避免 400ms 防抖丢尾 */
  global.addEventListener('beforeunload', function () {
    var db = global.WorkbenchDB;
    if (!db || !db.CLOUD_ENABLED || !db._data || !db.REMOTE || db.REMOTE.timer === null) return;
    try {
      var blob = new Blob([JSON.stringify(db._data)], { type: 'application/json' });
      navigator.sendBeacon(db.REMOTE.url + '?action=save', blob);
      clearTimeout(db.REMOTE.timer);
      db.REMOTE.timer = null;
    } catch (e) { /* 忽略：下次变更仍会同步 */ }
  });
})(window);
